const applicationdomain = "https://api.ragenaizer.com/";
const applicationdomain1 = "https://localhost:7139/";
const loginendpoint = applicationdomain + "api/login"

