
let chathistory = {}
const speechHandler = new SpeechHandler();
let chatcompletion = []
let querylock = false;
let isconnected = false;
let iconnection;
let isspeachquery = false;
let UserRoles;
let UserIntials;
let UserObject;
let faceAnalysis;
const meshVideo = document.getElementById('meshVideo');
let sentimentChart = null;
let InCallTranscription = [];
let sentimentCounts = {
    happy: 0,
    surprised: 0,
    sad: 0,
    angry: 0,
    fearful: 0,
    disgusted: 0
};
let sentimentCounts2 = {
    happy: 0,
    surprised: 0,
    sad: 0,
    neutral: 0,
    angry: 0,
    fearful: 0,
    disgusted: 0
};
let OngoingCall= false;
var inspeachquerymode = false;
var isCaller=false;
$(document).ready(async function () {
    
    try {
        loadScript('theme2/assets/js/app-chat.js');
        
        UserObject =  GetStoredUserData();
        if (UserObject != null){
            UserRoles = UserObject.role;
            if(UserRoles.length===1 &&  UserRoles.includes('SUBUSER')){
                $('#create-new-project-btn').html('')
            }

            UserIntials = getInitial(UserObject.name,UserObject.lastname);
  
            await initializeSignalRAsync(UserObject.email);
            GetUserDocumets();
            PerfectScrollInitiate('list-of-chats')
            PerfectScrollInitiate('list-of-docs')
            PerfectScrollInitiate('in-call-transcription')
            
           

            
            faceAnalysis = new FaceAnalysis();
            await faceAnalysis.initialize();
      
        }
        else{
            LogoutUser();
        }

    } catch (err) {
        console.error("Error initializing SignalR:", err);
    }
    
});


async function initializeSignalRAsync(emaiID) {
    const hubconsstring = applicationdomain + 'applicationhub?token=&appcode=chatwindow&param=' + emaiID;
    iconnection = new signalR.HubConnectionBuilder()
        .withUrl(hubconsstring)
        .withAutomaticReconnect({
            nextRetryDelayInMilliseconds: retryContext => {
                if (retryContext.elapsedMilliseconds < 60000) {
                    return 2000;
                }
            }
        })
        .configureLogging(signalR.LogLevel.Information)
        .build();

    iconnection.onclose(() => {
        isconnected = false;
        $('#signal-connection-1').removeClass('avatar-online');
        $('#signal-connection-2').removeClass('avatar-online');
    });

    iconnection.onreconnecting(() => {
        isconnected = false;
        $('#signal-connection-1').removeClass('avatar-online');
        $('#signal-connection-2').removeClass('avatar-online');
    });

    iconnection.onreconnected(() => {
        isconnected = true;
        GetOnlineTeams()
        $('#signal-connection-1').addClass('avatar-online');
        $('#signal-connection-2').addClass('avatar-online');
    });

    try {
        await iconnection.start();
        isconnected = true;
        $('#signal-connection-1').addClass('avatar-online');
        $('#signal-connection-2').addClass('avatar-online');

        try {
            const clientID = GetSignalRclientID();
            console.log('Client ID:', clientID);
            GetOnlineTeams()
            sessionStorage.setItem('connectionId', clientID);
        } catch (err) {
            console.error('Error getting SignalR client ID:', err);
        }
    } catch (err) {
        isconnected = false;
        console.error('Connection failed:', err);
    }

    iconnection.on("triggeraction", function (ActionName, ActionMessage, ActionContainer, ActionDataPointType) {
        if (ActionName === 'CHATRECEIVED') {
            if (ActionMessage.trim().length > 0) {
                HideSpinner();

                chatcompletion.push(ActionMessage);
                const boxid = `${ActionContainer}-box`;
                const gpts = `${ActionContainer}-gpt`;
                const tabls = `${gpts}-tables`;

                if (ActionDataPointType === 'text') {
                    $('#' + boxid).removeClass('hidechat').addClass('showchat');
                    const joinedText = chatcompletion.join("").replace(/\n/g, '<br>');
                    $('#' + gpts).html(`${joinedText}`);
                } else {
                    ShowFooterStatus('Generating tables');
                    var tabs = JSON.parse(ActionMessage);
                    

                    var ctr = 0;
                    $.each(tabs.tables, function(index, item) {
                        ctr++;
                        var cancharted = analyzeDataTypes(item);
                        
                        var tables = generateHtmlTableString(item);
                        $('#' + tabls).append(tables);
                        var chartid = `${tabls}-charts-${ctr}`;

                        try {
                            if (item.visualization === "bar_chart" && cancharted.canCreateChart === true) {
                                var testchart = `<div class="card mt-2 mb-3 w-full" style="width: 100%;"><div class="w-full"> <div id="${chartid}" class="ps h-px-400"></div> </div></div>`;
                                $('#' + tabls).append(testchart);
                                createBarChart(item, chartid);
                            } else if (item.visualization === "column_chart" && cancharted.canCreateChart === true) {
                                var testchart = `<div class="card mt-2 mb-3 w-full" style="width: 100%;"><div class="w-full"> <div id="${chartid}"></div> </div></div>`;
                                $('#' + tabls).append(testchart);
                                createColumnChart(item, chartid);
                            } else if (item.visualization === "line_chart" && cancharted.canCreateChart === true) {
                                var testchart = `<div class="card mt-2 mb-3 w-full" style="width: 100%;"><div class="w-full"> <div id="${chartid}"></div> </div></div>`;
                                $('#' + tabls).append(testchart);
                                createLineChart(item, chartid);
                            } else if (item.visualization === "pie_chart" && cancharted.canCreateChart === true) {
                                var testchart = `<div class="card mt-2 mb-3 w-full" style="width: 100%;"><div class="w-full"> <div id="${chartid}"></div> </div></div>`;
                                $('#' + tabls).append(testchart);
                                createPieChart(item, chartid);
                            } else if (item.visualization === "donut_chart" && cancharted.canCreateChart === true) {
                                var testchart = `<div class="card mt-2 mb-3 w-full" style="width: 100%;"><div class="w-full"> <div id="${chartid}"></div> </div></div>`;
                                $('#' + tabls).append(testchart);
                                createDonutChart(item, chartid);
                            }
                        } catch (error) {
                            $('#' + chartid).html(``);
                        }

                        // Global resize handler for all charts
                        let globalResizeTimeout;
                        window.addEventListener('resize', function() {
                            clearTimeout(globalResizeTimeout);
                            globalResizeTimeout = setTimeout(function() {
                                chartInstances.forEach(chart => {
                                    if (chart && typeof chart.updateOptions === 'function') {
                                        chart.updateOptions({
                                            chart: {
                                                width: '100%'
                                            }
                                        });
                                    }
                                });
                            }, 250);
                        });
                    });
                }

                const chatBox = document.getElementById('list-of-chats');
                chatBox.scrollTop = chatBox.scrollHeight;
                ShowFooterStatus('Streaming results');
            }
        } else if (ActionName === 'STATUSRECEIVED') {
            ShowFooterStatus(ActionMessage);
        } else if (ActionName === 'USAGEUPDATE') {
            CheckTokenUsage();
        } else if (ActionName === 'WEBRTCUSERADD') {
            console.log(`RTC: ${ActionMessage}`);
        } else if (ActionName === 'WEBRTCUSERREMOVED') {
            console.log(`RTC REM: ${ActionMessage}`);
        }
        else if (ActionName === 'USERDEACTIVATED') {
            LogoutUser();
        }
    });

    iconnection.on("TeamMemberConnectivity", function(status,email) {
        GetOnlineTeams()
    });

    iconnection.on("ChatReceived", function(from,message,additionalInfo) {
        var remoteTrans = JSON.parse(message);
        InCallTranscription.push(remoteTrans);
        ShowTranscription(remoteTrans.user,remoteTrans.uinitialet,remoteTrans.name,remoteTrans.text,remoteTrans.time)
    });
    
    iconnection.on("ReceiveOffer", async (callerEmail, offer, additionalInfo) => {
        //console.log(`Receiving call from ${callerEmail}`);
        //console.log(`Receiving call for type ${additionalInfo}`);
        
        ResetVisionAIparams()
        showIncomingCallToast(callerEmail, offer, additionalInfo);
    });

    iconnection.on("ReceiveAnswer", async (callerEmail, answer) => {
        //console.log("ANSWER RECEIVED from:", callerEmail);
        await webRTCHandler.handleAnswer(answer);
    });

    iconnection.on("ReceiveIceCandidate", async (callerEmail, iceCandidate) => {
        //console.log("ICE CANDIDATE RECEIVED from:", callerEmail);
        await webRTCHandler.handleIceCandidate(iceCandidate);
    });

    iconnection.on("CallRejected", (rejectorEmail) => {
        // First close the video call modal
        webRTCHandler.endCall();
        HideRightOffCanvas()
        ResetVisionAIparams()
        showNotificationToast(
            'Call Rejected',
            `${rejectorEmail} rejected your call`,
            'danger',
            3000
        );
    });

    iconnection.on("CallEnded", (callerEmail) => {
        //console.log(`Call ended by ${callerEmail}`);

        // Set flag to prevent echo notifications
        webRTCHandler.isResponseToEndCall = true;

        // End the call on this side
        webRTCHandler.endCall();
        ResetVisionAIparams();
        // Show notification
        showNotificationToast(
            'Call Ended',
            `${callerEmail} has left the meeting`,
            'info',
            3000
        );
    });


    iconnection.on("InCallStatusReceived", async (callerEmail, message, mtype) => {
        debugger
        console.log(`status call from ${callerEmail}`);
        console.log(`status call for message ${message}`);
        console.log(`status call for type ${mtype}`);
       
    });
    
    return iconnection;
}
function TransferMessageToChatUser(sender,receiver,message,container) {
    
    if (iconnection && isconnected) {
        // Send data to the server
        iconnection.invoke("ChatSend",sender , receiver, message,container)
            .then(() => {
                //console.log("Data sent to server successfully.");
            })
            .catch(err => {
                console.error("Error sending data to server:", err);
            });
    } else {
        console.log("SignalR not connected. Checking again...");
        setTimeout(checkConnectionAndSend, retryInterval); // Retry after the interval
    }
}
function sendDataToServer() {
    if (iconnection && isconnected) {
        // Send data to the server
        iconnection.invoke("ReceiveClientData", "ABHISHEKANAND.KO@GMAIL.COM", 'chatmodule', "cdc")
            .then(() => {
                console.log("Data sent to server successfully.");
            })
            .catch(err => {
                console.error("Error sending data to server:", err);
            });
    } else {
        console.log("SignalR not connected. Checking again...");
        setTimeout(checkConnectionAndSend, retryInterval); // Retry after the interval
    }
}




// Speach Handlers
speechHandler.setOnPartialResult(result => {
   // console.log('Partial transcription:', result.text,'Local', result.local);
    if(result.local==='user-query-box'){
        $('#' + result.local).val(result.text);
    }
    
});

speechHandler.setOnFinalResult(result => {
   // console.log('Final transcription:', result.text,'Local', result.local);
    if(result.local==='user-query-box'){
        $('#user-query-box').val(result.text);
        if(result.text.trim().length > 0){
            //speechHandler.stop()
            StopSpeachRagQuery()
            sendMessage()
        }

        // const micIcon = document.getElementById('mic-icon');
        // micIcon.classList.remove('bx-microphone-off', 'mic-listening');
        // micIcon.classList.add('bx-microphone');
        
    }
    else {


        //const user = Userteam.find(member => member.email === result.local);

        var transcript = {
            user: result.local,
            text: result.text,
            time: Date.now(),
            uinitialet: UserIntials,
            name: `${UserObject.name} ${UserObject.lastname}`,
        };
        
        InCallTranscription.push(transcript);
        //console.log(InCallTranscription);
        TransferMessageToChatUser(result.local, result.remote, JSON.stringify(transcript), '')
        ShowTranscription(transcript.user, transcript.uinitialet, transcript.name, transcript.text, transcript.time)
    }

});

speechHandler.setOnError(error => {
    //console.error('Speech error:', error.message);
});




// Face Handlers
window.addEventListener('faceMeshStreams', (event) => {
    const { originalStream, meshStream, modelStream } = event.detail;
    meshVideo.srcObject = meshStream;
}, false);

window.addEventListener('faceAnalysisError', (event) => {
    console.error('Face analysis error:', event.detail);
}, false);

window.addEventListener('faceAnalysis', (event) => {
    //console.log('Face analysis event received:', event.detail);
    const analysis = event.detail;

    if (analysis.faceDetected) {

        if (analysis.metrics.sentiment in sentimentCounts) {
            sentimentCounts[analysis.metrics.sentiment]++;
        }
        var senti = transformVisionSentimentData(sentimentCounts)
        //console.log(senti);

        updateSentimentChart(sentimentCounts, 'visionaisentiments');


        // Handle face detected case
        // console.log('Face metrics:', analysis.metrics);
        // console.log('Sentiment:', analysis.metrics.sentiment);
        // console.log('Attention:', analysis.metrics.attention);

        // $('#cv_distance').text(analysis.metrics.distance)
        // $('#cv_sentiment').text(analysis.metrics.sentiment)

        const distanceInfo = getDistanceInfo(analysis.metrics.distance);
        $('#cv_distance')
            .text(`${distanceInfo.text} (${analysis.metrics.distance.toFixed(2)})`)
            .removeClass('bg-danger bg-warning bg-success bg-info bg-secondary')
            .addClass(distanceInfo.class);

        $('#cv_looking')
            .text(analysis.metrics.attention.looking === true ? 'Looking' : 'Not Looking')
            .removeClass('bg-primary bg-danger')
            .addClass(analysis.metrics.attention.looking === true ? 'bg-primary' : 'bg-danger');
    } else {
        //console.log('No face detected in frame');
    }
}, false);




// WEBRTC Handlers
webRTCHandler.addEventListener('localStream', (data) => {
     //console.log('target:', data.callReceiver);
     //console.log('call type:', data.callType);
     //console.log('Local user:', data.localEmail);
     //console.log('Remote user:', data.remoteEmail);
    // console.log('Reading from Mic');
    //speechRecognition.start(data.stream, data.localEmail);
    
    //faceAnalysis.startAnalysis(data.stream, data.localEmail, data.remoteEmail, { width: 1280, height: 720 });
    //faceAnalysis.startAnalysis(data.stream, data.localEmail, data.remoteEmail, 2.0);
    
    //speechHandler.startMicRecognition(data.localEmail, data.remoteEmail);
    speechHandler.startStreamRecognition(data.stream,data.localEmail, data.remoteEmail);

});

webRTCHandler.addEventListener('remoteStream', (data) => {
    //console.log('target:', data.callReceiver);
     console.log('call type:', data.callType);
     console.log('Is caller user:', isCaller);
    //speechRecognition.start(data.stream, data.remoteEmail);
    OngoingCall = true;
    
    if(isCaller===false && data.callType==='interview'){
        faceAnalysis.stopAnalysis()
        meshVideo.srcObject = null;
        $('#facetrackandsentiments').hide();
    }
    else {
        $('#facetrackandsentiments').show();
        faceAnalysis.startAnalysis(data.stream, data.localEmail, data.remoteEmail, 2.0);
    }
   
    //speechHandler.startStreamRecognition(data.stream,data.localEmail, data.remoteEmail);
});

webRTCHandler.addEventListener('audioStateChange', (data) => {
    console.log('Audio state changed:', data.muted);
    console.log('Changed by:', data.localEmail);
    console.log('Other participant:', data.remoteEmail);
    iconnection.invoke("InCallStatus", this.remoteEmail, data.localEmail, "Audio Muted","audio");
});

webRTCHandler.addEventListener('videoStateChange', (data) => {
    console.log('Video state changed:', data.disabled);
    console.log('Changed by:', data.localEmail);
    console.log('Other participant:', data.remoteEmail);
});

webRTCHandler.addEventListener('screenShareChange', (data) => {
    console.log('Screen sharing state changed:', data.isScreenSharing);
    console.log('Shared by:', data.localEmail);
    console.log('Shared with:', data.remoteEmail);
});

webRTCHandler.addEventListener('callEnd', (data) => {
   // console.log('Call ended');
  //  console.log('Local participant:', data.localEmail);
  //  console.log('Remote participant:', data.remoteEmail);
  //  console.log('Call duration:', Math.floor(data.duration / 1000), 'seconds');
   // console.log('Call start time:', new Date(data.startTime).toLocaleString());
  //  console.log('Call end time:', new Date(data.timestamp).toLocaleString());
    speechHandler.stop()
    ResetVisionAIparams()
});

webRTCHandler.addEventListener('visioncontrols', (data) => {
    //console.log('Local participant:', data.local);
    //console.log('Remote participant:', data.remote);
    const offcanvasBottom = document.getElementById('offcanvasBottom');
    const bsOffcanvas = new bootstrap.Offcanvas(offcanvasBottom);
    bsOffcanvas.show();
});



function updateSentimentChart(sentimentCounts,containerId) {
    // Calculate total for percentage calculation
    const total = Object.values(sentimentCounts).reduce((sum, count) => sum + count, 0);
    

    
    // Update each progress bar
    Object.entries(sentimentCounts).forEach(([sentiment, count]) => {
        // Calculate percentage (avoid division by zero)
        const percentage = total === 0 ? 0 : Math.round((count / total) * 100);

        // Get the progress bar and percentage text elements
        const progressBar = document.querySelector(`[data-sentiment="${sentiment}"] .progress-bar`);
        const percentageText = document.querySelector(`[data-sentiment="${sentiment}"] .percentage-text`);

        if (progressBar && percentageText) {
            // Update progress bar width and aria values
            progressBar.style.width = `${percentage}%`;
            progressBar.setAttribute('aria-valuenow', percentage);

            // Update percentage text
            percentageText.textContent = `${percentage}%`;
        }
    });
}
function getDistanceInfo(distance) {
    if (distance <= 0.6) {
        return { text: 'Too Close', class: 'bg-danger' };
    } else if (distance <= 0.8) {
        return { text: 'Near', class: 'bg-warning' };
    } else if (distance <= 1.2) {
        return { text: 'Perfect', class: 'bg-success' };
    } else if (distance <= 1.6) {
        return { text: 'Far', class: 'bg-info' };
    } else {
        return { text: 'Too Far', class: 'bg-secondary' };
    }
}

function showIncomingCallToast(callerEmail, offerData, calltype) {
    HideRightOffCanvas()
    // Create toast ID
    const toastId = 'incomingCallToast';

    // Remove existing toast if any
    const existingToast = document.getElementById(toastId);
    if (existingToast) {
        existingToast.remove();
    }

    const toastHtml = `
        <div id="${toastId}" class="toast position-fixed top-0 end-0 m-4" role="alert" style="z-index: 9999;">
            <div class="toast-header bg-primary text-white">
                <strong class="me-auto">Incoming Video Call</strong>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="toast"></button>
            </div>
            <div class="toast-body">
                <p class="mb-2">${callerEmail} is calling you...</p>
                <div class="d-flex justify-content-end gap-2">
                    <button type="button" class="btn btn-danger btn-sm" onclick="rejectCall('${callerEmail}')">
                        Reject
                    </button>
                    <button type="button" class="btn btn-success btn-sm" onclick="acceptCall('${callerEmail}', '${encodeURIComponent(offerData)}','${calltype}')">
                        Accept
                    </button>
                </div>
            </div>
        </div>`;

    document.body.insertAdjacentHTML('beforeend', toastHtml);

    // Show toast
    const toastElement = document.getElementById(toastId);
    const toast = new bootstrap.Toast(toastElement, {
        autohide: false
    });
    toast.show();
}
function showNotificationToast(title, message, type = 'primary', duration = 3000) {
    
    const toastId = `notification-${Date.now()}`;

    // Remove any existing toast with same ID
    const existingToast = document.getElementById(toastId);
    if (existingToast) {
        existingToast.remove();
    }

    const toastHtml = `
        <div id="${toastId}" class="toast position-fixed top-0 end-0 m-4" role="alert" style="z-index: 9999;">
            <div class="toast-header bg-${type} text-white">
                <strong class="me-auto">${title}</strong>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="toast"></button>
            </div>
            <div class="toast-body">
                ${message}
            </div>
        </div>`;

    document.body.insertAdjacentHTML('beforeend', toastHtml);

    const toastElement = document.getElementById(toastId);
    const toast = new bootstrap.Toast(toastElement, {
        autohide: duration > 0,
        delay: duration
    });
    toast.show();

    // Cleanup after hiding
    if (duration > 0) {
        toastElement.addEventListener('hidden.bs.toast', () => {
            toastElement.remove();
        });
    }
}
function showConfirmationToastNoParam(title, message, onConfirm, type = 'primary', duration = 0) {
    const toastId = `confirmation-${Date.now()}`;

    // Remove any existing toast with same ID
    const existingToast = document.getElementById(toastId);
    if (existingToast) {
        existingToast.remove();
    }

    const toastHtml = `
        <div id="${toastId}" class="toast position-fixed top-0 end-0 m-4" role="alert" style="z-index: 9999;">
            <div class="toast-header bg-${type} text-white">
                <strong class="me-auto">${title}</strong>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="toast"></button>
            </div>
            <div class="toast-body">
                <p class="mb-3">${message}</p>
                <div class="d-flex justify-content-end gap-2">
                    <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="toast">No</button>
                    <button type="button" class="btn btn-${type} btn-sm confirm-btn">Yes</button>
                </div>
            </div>
        </div>`;

    document.body.insertAdjacentHTML('beforeend', toastHtml);

    const toastElement = document.getElementById(toastId);
    const toast = new bootstrap.Toast(toastElement, {
        autohide: duration > 0,
        delay: duration
    });

    // Add click handler for confirm button
    const confirmBtn = toastElement.querySelector('.confirm-btn');
    confirmBtn.addEventListener('click', () => {
        if (typeof onConfirm === 'function') {
            onConfirm();
        } else if (typeof onConfirm === 'string') {
            // If a function name is passed as string, try to execute it
            try {
                const fn = window[onConfirm];
                if (typeof fn === 'function') {
                    fn();
                }
            } catch (error) {
                console.error(`Error executing function ${onConfirm}:`, error);
            }
        }
        toast.hide();
    });

    // Cleanup after hiding
    toastElement.addEventListener('hidden.bs.toast', () => {
        toastElement.remove();
    });

    toast.show();
}
function showConfirmationToastWithParam(title, message, onConfirm, params = [], type = 'primary', duration = 0) {
    const toastId = `confirmation-${Date.now()}`;

    // Remove any existing toast with same ID
    const existingToast = document.getElementById(toastId);
    if (existingToast) {
        existingToast.remove();
    }

    const toastHtml = `
        <div id="${toastId}" class="toast position-fixed top-0 end-0 m-4" role="alert" style="z-index: 9999;">
            <div class="toast-header bg-${type} text-white">
                <strong class="me-auto">${title}</strong>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="toast"></button>
            </div>
            <div class="toast-body">
                <p class="mb-3">${message}</p>
                <div class="d-flex justify-content-end gap-2">
                    <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="toast">No</button>
                    <button type="button" class="btn btn-${type} btn-sm confirm-btn">Yes</button>
                </div>
            </div>
        </div>`;

    document.body.insertAdjacentHTML('beforeend', toastHtml);

    const toastElement = document.getElementById(toastId);
    const toast = new bootstrap.Toast(toastElement, {
        autohide: duration > 0,
        delay: duration
    });

    // Add click handler for confirm button
    const confirmBtn = toastElement.querySelector('.confirm-btn');
    confirmBtn.addEventListener('click', () => {
        if (typeof onConfirm === 'function') {
            onConfirm(...params);
        } else if (typeof onConfirm === 'string') {
            // If a function name is passed as string, try to execute it
            try {
                const fn = window[onConfirm];
                if (typeof fn === 'function') {
                    fn(...params);
                }
            } catch (error) {
                console.error(`Error executing function ${onConfirm} with params:`, params, error);
            }
        }
        toast.hide();
    });

    // Cleanup after hiding
    toastElement.addEventListener('hidden.bs.toast', () => {
        toastElement.remove();
    });

    toast.show();
}
function acceptCall(callerEmail, encodedOffer, calltype) {
    HideRightOffCanvas()
    // Hide and remove toast
    const toastElement = document.getElementById('incomingCallToast');
    if (toastElement) {
        const toast = bootstrap.Toast.getInstance(toastElement);
        if (toast) toast.hide();
        toastElement.remove();
    }

    isCaller = false;
    const offer = decodeURIComponent(encodedOffer);
    webRTCHandler.handleOffer(callerEmail, offer,calltype);
}
function rejectCall(callerEmail) {
    isCaller = false;
    const toastElement = document.getElementById('incomingCallToast');
    if (toastElement) {
        const toast = bootstrap.Toast.getInstance(toastElement);
        if (toast) toast.hide();
        toastElement.remove();
    }

    // Notify caller of rejection
    iconnection.invoke("SendCallRejected", callerEmail, UserObject.username)
        .catch(error => console.error("Error sending call rejection:", error));
}
function startMeeting(targetuser){


    if(OngoingCall === false){
        ResetVisionAIparams()
        if (!OnleineTeam.includes(targetuser)) {
            showNotificationToast(
                'User Offline',
                'The user you are trying to call is currently offline',
                'warning',
                3000
            );
            return;
        }
        isCaller = true;
        webRTCHandler.initiateVideoCall(targetuser, 'team');
    }
    else{
        showNotificationToast('Ongoing Call','A call is ongoing','warning');
    }

}
function startGuestMeeting(targetuser, hideprop){

    
    if(OngoingCall === false){
        ResetVisionAIparams()
        isCaller = true;
        webRTCHandler.initiateVideoCall(targetuser, hideprop===false? 'guest':'interview');
    }
    else{
        showNotificationToast('Ongoing Call','A call is ongoing','warning');
    }

}
function ResetVisionAIparams(){
    isCaller = false;
    faceAnalysis.stopAnalysis()
    meshVideo.srcObject = null;
    InCallTranscription = []; // Clear the transcription array
    sentimentCounts = {       // Reset sentiment counts to initial values
        happy: 0,
        surprised: 0,
        sad: 0,
        angry: 0,
        fearful: 0,
        disgusted: 0
    };
    $('#cv-teanscriptions').html('')
    HideBottomOffCanvas()
    OngoingCall = false;
}
function ShowTranscription(from, initials, name, text, time){
    var htm = `<li class="mb-1"><div class="card">
                    <div class="card-body p-1">
                      <div class="d-flex align-items-center mb-1">
                        <a href="javascript:;" class="d-flex align-items-center">
                          <div class="avatar avatar-xs me-2">
                           <span class="avatar-initial rounded-circle bg-label-primary">${initials}</span>
                          </div>
                          <div class="me-2 text-body text-xs mb-0">${name}</div>
                        </a>
                      </div>
                      <p class="text-xs text-info">
                       ${text}
                      </p>
                      <span class="text-xs">${formatTimestamp(time)}</span>
                    </div>
                  </div></li>`
    $('#cv-teanscriptions').prepend(htm);
}

//Example usage with email information WEBRTC


// function initializeSpeechRecognition() {
//     try {
//         const speachAvailable = SpeechToText.isSpeechRecognitionSupported();
//         if (speachAvailable) {
//             $('#speach-recog-button').show();
//
//             // Automatically start speech recognition
//             try {
//                 SpeechToText.startListening().catch((error) => {
//                     console.error('Failed to start automatic recording:', error);
//                     $('#speach-recog-button').find('i')
//                         .removeClass('bx-microphone-off')
//                         .addClass('bx-microphone');
//                 });
//             } catch (err) {
//                 console.error('Error starting SpeechToText automatically:', err);
//             }
//
//             // Event Listeners
//             SpeechToText.addEventListener('onSpeechStart', function (data) {
//                 console.log('🎤 Recording started:', data.timestamp);
//             });
//
//             SpeechToText.addEventListener('onInterimPhrase', function (data) {
//                 console.log('🗣️ Interim phrase:', data.phrase);
//                 $('#user-query-input-box').val(data.phrase);
//             });
//
//             SpeechToText.addEventListener('onNewWord', function (data) {
//                 console.log('📝 Word detected:', {
//                     word: data.word,
//                     isFinal: data.isFinal,
//                     timestamp: data.timestamp
//                 });
//             });
//
//             SpeechToText.addEventListener('onFinalPhrase', function (data) {
//                 console.log('✅ Final phrase:', {
//                     text: data.phrase,
//                     confidence: data.confidence,
//                     timestamp: data.timestamp
//                 });
//
//                 if (data.phrase && data.phrase.trim()) {
//                     $('#user-query-input-box').val('');
//                     $('#user-query-input-box').val((i, val) => val + data.phrase.trim() + ' ');
//                 }
//             });
//
//             SpeechToText.addEventListener('onSilence', function (data) {
//                 console.log('🔇 Silence detected:', data.timestamp);
//                 isspeachquery = true;
//                 sendMessage();
//                 console.log(isspeachquery)
//             });
//
//             SpeechToText.addEventListener('onSpeechEnd', function (data) {
//                 console.log('⏹️ Recording ended:', data.timestamp);
//                 $('#speach-recog-button').find('i')
//                     .removeClass('bx-microphone-off')
//                     .addClass('bx-microphone');
//             });
//
//             SpeechToText.addEventListener('onError', function (data) {
//                 console.error('❌ Speech error:', {
//                     error: data.error,
//                     message: data.message,
//                     timestamp: data.timestamp
//                 });
//                 $('#speach-recog-button').find('i')
//                     .removeClass('bx-microphone-off')
//                     .addClass('bx-microphone');
//             });
//         } else {
//             $('#speach-recog-button').hide();
//         }
//     } catch (err) {
//         console.error("Error initializing speech recognition:", err);
//     }
// }
// function handleSpeechRecognition(button) {event.preventDefault();
//
//     if (!SpeechToText.isRecording) {
//         // Start recording
//         SpeechToText.startListening().catch(error => {
//             console.error('Failed to start recording:', error);
//         });
//
//         // Update button UI
//         $(button).find('i').removeClass('bx-microphone').addClass('bx-microphone-off');
//     } else {
//         // Stop recording
//         SpeechToText.stopListening();
//
//         // Update button UI
//         $(button).find('i').removeClass('bx-microphone-off').addClass('bx-microphone');
//     }
// }
function speakText(text, lang = 'en-US', rate = 1, pitch = 1, onEnd) {
    if (!window.speechSynthesis) {
        console.error('SpeechSynthesis not supported in this browser.');
        return;
    }

    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = lang;
    utterance.rate = rate;
    utterance.pitch = pitch;

    if (onEnd && typeof onEnd === 'function') {
        utterance.onend = onEnd;
    }

    window.speechSynthesis.speak(utterance);
}



function StartSpeachRagQuery(){
    if(OngoingCall===false){
        
        if(inspeachquerymode ===false){
            inspeachquerymode = true;
            const micIcon = document.getElementById('mic-icon');
            speechHandler.startMicRecognition("user-query-box", "user-query-box");
            micIcon.classList.remove('bx-microphone');
            micIcon.classList.add('bx-microphone-off', 'mic-listening');
        }
        else{
            StopSpeachRagQuery();
        }
        
    }
    else{
        showNotificationToast('Speach Query','Speach queries are disabled while Hyper Vision call is in progress.','info')
    }
   
}
function StopSpeachRagQuery(){
    speechHandler.stop()
    inspeachquerymode = false;
    const micIcon = document.getElementById('mic-icon');
    micIcon.classList.remove('bx-microphone-off', 'mic-listening');
    micIcon.classList.add('bx-microphone');
}
function ClearChat(){
    $('#main-chat-board').html('')
    chathistory = {};
}

function initializeSignalR(emaiID) {
    const hubconsstring = applicationdomain + 'applicationhub?token=&appcode=chatwindow&param=' + emaiID;
    iconnection = new signalR.HubConnectionBuilder()
        .withUrl(hubconsstring)
        .withAutomaticReconnect({
            nextRetryDelayInMilliseconds: retryContext => {
                if (retryContext.elapsedMilliseconds < 60000) {
                    return 2000;
                }
            }
        })
        .configureLogging(signalR.LogLevel.Information)
        .build();

    iconnection.onclose(() => {
        isconnected = false;
        $('#signal-connection-1').removeClass('avatar-online');
        $('#signal-connection-2').removeClass('avatar-online');
        //console.error('SignalR connection closed.');
    });

    iconnection.onreconnecting(() => {
        isconnected = false;
        //console.warn('SignalR reconnecting...');
        $('#signal-connection-1').removeClass('avatar-online');
        $('#signal-connection-2').removeClass('avatar-online');
    });

    iconnection.onreconnected(() => {
        isconnected = true;
        //console.log('SignalR reconnected.');
        $('#signal-connection-1').addClass('avatar-online');
        $('#signal-connection-2').addClass('avatar-online');
    });

    iconnection.start()
        .then(() => {
            //console.log('SignalR connection established.');
            isconnected = true;

            $('#signal-connection-1').addClass('avatar-online');
            $('#signal-connection-2').addClass('avatar-online');

            // Safely get the client ID
            try {
                const clientID = GetSignalRclientID();
                console.log('Client ID:', clientID);
                sessionStorage.setItem('connectionId', clientID);
            } catch (err) {
                console.error('Error getting SignalR client ID:', err);
            }
        })
        .catch(err => {
            isconnected = false;
            //console.error('Connection failed:', err);
        });

    iconnection.on("triggeraction", function (ActionName, ActionMessage, ActionContainer,ActionDataPointType) {
        
        if (ActionName === 'CHATRECEIVED') {
            if(ActionMessage.trim().length > 0) {
                HideSpinner();
                
                chatcompletion.push(ActionMessage);
                const boxid = `${ActionContainer}-box`;
                const gpts = `${ActionContainer}-gpt`;
                const tabls = `${gpts}-tables`
                if (ActionDataPointType === 'text') {
                    $('#' + boxid).removeClass('hidechat').addClass('showchat');
                    const joinedText = chatcompletion.join("").replace(/\n/g, '<br>');
                    $('#' + gpts).html(`${joinedText}`);
                   
                } else {
                    ShowFooterStatus('Generating tables')
                    var tabs = JSON.parse(ActionMessage);
                    console.log(tabs);

                    var ctr=0;
                    $.each(tabs.tables, function(index, item){
                        ctr++;
                        var cancharted = analyzeDataTypes(item);
                        console.log(cancharted)
                        var tables = generateHtmlTableString(item);
                        $('#' + tabls).append(tables);
                        var chartid =`${tabls}-charts-${ctr}`
                        try{
                            // var testchart = `<div class="card mt-2 mb-3 w-full" style="width: 100%;"><div class="w-full"> <div id="${chartid}"></div> </div></div>`
                            // $('#' + tabls).append(testchart);
                            if(item.visualization==="bar_chart" && cancharted.canCreateChart===true){
                                var testchart = `<div class="card mt-2 mb-3 w-full" style="width: 100%;"><div class="w-full"> <div id="${chartid}" class="ps h-px-400"></div> </div></div>`
                                $('#' + tabls).append(testchart);
                                createBarChart(item,chartid);
                            }
                            else if(item.visualization==="column_chart" && cancharted.canCreateChart===true){
                                var testchart = `<div class="card mt-2 mb-3 w-full" style="width: 100%;"><div class="w-full"> <div id="${chartid}"></div> </div></div>`
                                $('#' + tabls).append(testchart);
                                createColumnChart(item,chartid);
                            }
                            else if(item.visualization==="line_chart" && cancharted.canCreateChart===true){
                                var testchart = `<div class="card mt-2 mb-3 w-full" style="width: 100%;"><div class="w-full"> <div id="${chartid}"></div> </div></div>`
                                $('#' + tabls).append(testchart);
                                createLineChart(item,chartid)
                            }
                            else if(item.visualization==="pie_chart" && cancharted.canCreateChart===true){
                                var testchart = `<div class="card mt-2 mb-3 w-full" style="width: 100%;"><div class="w-full"> <div id="${chartid}"></div> </div></div>`
                                $('#' + tabls).append(testchart);
                                createPieChart(item,chartid)
                            }
                            else if(item.visualization==="donut_chart" && cancharted.canCreateChart===true){
                                var testchart = `<div class="card mt-2 mb-3 w-full" style="width: 100%;"><div class="w-full"> <div id="${chartid}"></div> </div></div>`
                                $('#' + tabls).append(testchart);
                                createDonutChart(item,chartid)
                            }
                        }
                        catch {
                            $('#' + chartid).html(``)
                        }

                        
                        let globalResizeTimeout;
                        window.addEventListener('resize', function() {
                            clearTimeout(globalResizeTimeout);
                            globalResizeTimeout = setTimeout(function() {
                                try {
                                    chartInstances.forEach(chart => {
                                        if (chart && typeof chart.updateOptions === 'function') {
                                            chart.updateOptions({
                                                chart: {
                                                    width: '100%'
                                                }
                                            });
                                        }
                                    });
                                } catch (error) {
                                    console.warn('Error updating charts during resize:', error);
                                }
                            }, 250);
                        });
                        
                    });
                    
                }
                
                const chatBox = document.getElementById('list-of-chats');
                chatBox.scrollTop = chatBox.scrollHeight;
                ShowFooterStatus('Streaming results')
            }
        } else if (ActionName === 'STATUSRECEIVED') {
           
            ShowFooterStatus(ActionMessage)
        }
        else if (ActionName === 'USAGEUPDATE') {
            CheckTokenUsage()
        }
        else if (ActionName === 'WEBRTCUSERADD') {
            console.log(`RTC: ${ActionMessage}`)
            
        }
        else if (ActionName === 'WEBRTCUSERREMOVED') {
            console.log(`RTC REM: ${ActionMessage}`)
        }
    });




    this.connection.on("ReceiveOffer", async (emaiID, offer) => {
        console.log(`Receiving call from ${callerEmail}`);
        await this.handleOffer(callerEmail, offer);
    });

    this.connection.on("ReceiveAnswer", async (emaiID, answer) => {
        console.log(`Receiving answer from ${callerEmail}`);
        await this.handleAnswer(callerEmail, answer);
    });

    this.connection.on("ReceiveIceCandidate", async (emaiID, iceCandidate) => {
        console.log(`Receiving ICE candidate from ${callerEmail}`);
        await this.handleIceCandidate(callerEmail, iceCandidate);
    });




}
function GetSignalRclientID()  {

    if (iconnection && iconnection.connection && iconnection.connection.connectionId) {
        return iconnection.connection.connectionId;
    } else {
        throw new Error('SignalR connection is not established.');
    }
};




const sendButton = document.querySelector(".send-msg-btn");
const messageInput = document.querySelector(".message-input");
sendButton.addEventListener("click", sendMessage);
messageInput.addEventListener("keypress", (event) => {
    if (event.key === "Enter") {
        event.preventDefault(); // Prevent newline in the input field
        sendMessage();
    }
});



function ssinitializeChatToggle() {
    const $logoContainer = $('.flex-shrink-0');
    const $chatContacts = $('#app-chat-contacts');

    // Initialize a state variable to track sidebar visibility
    let isSidebarVisible = true;

    // Function to toggle sidebar visibility
    function toggleChatContacts() {
        if (isSidebarVisible) {
            $chatContacts.addClass('hidden');
        } else {
            $chatContacts.removeClass('hidden');
        }
        isSidebarVisible = !isSidebarVisible;

        // Reinitialize PerfectScroll after toggle
        PerfectScrollInitiate('list-of-docs');
    }

    // Add click event listener to the logo
    $logoContainer.on('click', function(e) {
        e.preventDefault();
        toggleChatContacts();
    });

    // Optional: Add responsive behavior
    $(window).on('resize', function() {
        if ($(window).width() > 992) { // lg breakpoint
            $chatContacts.removeClass('hidden');
            isSidebarVisible = true;
            // Reinitialize PerfectScroll after responsive change
            PerfectScrollInitiate('list-of-docs');
        }
    });
}

function generateHtmlTableString(data) {
    // Verify data structure is correct
    if (!data || !data.title || !data.columns || !data.rows) {
        console.log('Invalid data structure:', data);
        return '<div class="card card-body mt-1"><div class="alert alert-warning">Invalid data structure</div></div>';
    }

    // Start with a card wrapper
    let html = '<div class="card card-body mt-1">';

    // Add the title
    html += `<h6 class="card-title">${data.title}</h6>`;

    // Start the table
    html += '<div class="table-responsive"><table class="dynamic-table table table-bordered" style="width: 100%;font-size: 12px;">';

    // Add headers
    html += '<thead class="thead-light"><tr>';
    data.columns.forEach(column => {
        html += `<th scope="col">${column}</th>`;
    });
    html += '</tr></thead>';

    // Add data rows
    html += '<tbody>';
    if (data.rows && data.rows.length > 0) {
        data.rows.forEach(row => {
            html += '<tr>';
            row.forEach(cell => {
                html += `<td>${cell}</td>`;
            });
            html += '</tr>';
        });
    } else {
        html += `<tr><td colspan="${data.columns.length}">No data available</td></tr>`;
    }
    html += '</tbody>';

    // Close table and card
    html += '</table></div></div>';

    return html;
}
function sendMessage() {
    
    if(TokenConsumption.available> 0 && !querylock && isconnected){
        const message = messageInput.value.trim(); // Get the input value
        var selecteddocs = getSelectedCheckboxIds();
        if (message && selecteddocs.length > 0) {

            var uuid =`gp-${generateUniqueID()}-l1k` ;
            var newuserchat=`<li class="chat-message chat-message-right">
                                <div class="d-flex overflow-hidden">
                                    <div class="chat-message-wrapper flex-grow-1">
                                        <div class="chat-message-text">
                                            <p class="mb-0">${message}</p>
                                            
                                        </div>
                                        <div class="text-end">
                                            <a href="#" onclick="askagainMessage('${message}')"><span class="text-xs">ask again</span></a>
                                        </div>
                                        
                                    </div>
                                    <div class="user-avatar flex-shrink-0 ms-3">
                                        <div class="avatar">
                                            <span class="avatar-initial bg-label-primary rounded-circle" >${UserIntials}</span>
                                        </div>
                                    </div>
                                </div>
                        </li>`

            var boxid = `${uuid}-box`
            var inferid = `${uuid}-infer`
            var citid = `${uuid}-cit`
            var gpts  = `${uuid}-gpt`
            var docit  = `${uuid}-docit`
            var newsystemchat = `
                                      <li class="chat-message hidechat" id="${boxid}">
                            <div class="d-flex overflow-hidden">
                                <div class="user-avatar flex-shrink-0 me-3">
                                     <div class="avatar avatar-sm">
                                        <img src="theme2/assets/logo/logo-icon-blue.png" alt="Avatar" style="width: 35px">
                                    </div>
                                </div>
                                <div class="chat-message-wrapper flex-grow-1">
                                    <div class="chat-message-text">

                                        <div class="">
                                            <div class="nav-align-top navbar-detached">
                                                <ul class="nav nav-tabs nav-sm" role="tablist">
                                                    <li class="nav-item nav-pills" role="presentation">
                                                        <button type="button" class="nav-link active" role="tab" data-bs-toggle="tab" data-bs-target="#${inferid}" aria-controls="${inferid}" aria-selected="true">
                                                            Inference
                                                        </button>
                                                    </li>
                                                    
                                                </ul>
                                                <div class="tab-content">
                                                    <div class="tab-pane fade active show" id="${inferid}" role="tabpanel">
                                                       <div ><span id="${gpts}"></span><span id="${gpts}-tables"></span></div>
                                                       <div class="d-flex justify-content-between">
                                                            <div style="text-align: start;"><a href="#" onclick="showCitations('${uuid}')"><span class="text-xs">Citations</span></a></div>
                                                            <div style="text-align: end;"><a href="#" onclick="copyToClipboard('${gpts}')"><span class="text-xs">Copy</span></a></div>
                                                        </div>
                                                    </div>
                                                    
                                                </div>
                                            </div>
                                        </div>
                                        
                                    </div>
                                </div>
                            </div>
                        </li>
                                    `
            $('#main-chat-board').append(newuserchat);
            $('#main-chat-board').append(newsystemchat);

            messageInput.value = ""; // Clear the input field
            ExecuteChat(message,uuid)
        } else {
            if(selecteddocs.length===0){
                showNotificationToast('Error!','Please select atleast one document to continue','danger');
               //console.log(selecteddocs);
            }
        }
    }
    else{
        if(!isconnected){
            showNotificationToast('Error!','Connection to server is lost. Please try again later','danger');
        }
        else if(querylock){
            showNotificationToast('Error!','Chat locked to execute previous query','danger');
        }
        else{
            showNotificationToast('Error!','Please buy credits to continue','danger');
        }
       
    }

}
function askagainMessage(smessage) {
    if(TokenConsumption.available>0 && !querylock && isconnected) {
        const message = smessage.trim(); // Get the input value
        var selecteddocs = getSelectedCheckboxIds();
        if (message && selecteddocs.length > 0) {

            var uuid = `gp-${generateUniqueID()}-l1k`;
            var newuserchat = `<li class="chat-message chat-message-right">
                                <div class="d-flex overflow-hidden">
                                    <div class="chat-message-wrapper flex-grow-1">
                                        <div class="chat-message-text">
                                            <p class="mb-0">${message}</p>
                                            
                                        </div>
                                       <div class="text-end">
                                            <a href="#" onclick="askagainMessage('${message}')"><span class="text-xs">ask again</span></a>
                                        </div>
                                    </div>
                                    <div class="user-avatar flex-shrink-0 ms-3">
                                        <div class="avatar">
                                            <span class="avatar-initial bg-label-primary rounded-circle" >${UserIntials}</span>
                                        </div>
                                    </div>
                                </div>
                        </li>`

            var boxid = `${uuid}-box`
            var inferid = `${uuid}-infer`
            var citid = `${uuid}-cit`
            var gpts = `${uuid}-gpt`
            var docit = `${uuid}-docit`
            var newsystemchat = `
                                      <li class="chat-message hidechat" id="${boxid}">
                            <div class="d-flex overflow-hidden">
                                <div class="user-avatar flex-shrink-0 me-3">
                                    <div class="avatar avatar-sm">
                                        <img src="theme2/assets/logo/logo-icon-blue.png" alt="Avatar" style="width: 35px">
                                    </div>
                                </div>
                                <div class="chat-message-wrapper flex-grow-1">
                                    <div class="chat-message-text">

                                        <div class="">
                                            <div class="nav-align-top navbar-detached">
                                                <ul class="nav nav-tabs nav-sm" role="tablist">
                                                    <li class="nav-item nav-pills" role="presentation">
                                                        <button type="button" class="nav-link active" role="tab" data-bs-toggle="tab" data-bs-target="#${inferid}" aria-controls="${inferid}" aria-selected="true">
                                                            Inference
                                                        </button>
                                                    </li>
                                                </ul>
                                                <div class="tab-content">
                                                    <div class="tab-pane fade active show" id="${inferid}" role="tabpanel">
                                                       <div><span id="${gpts}"></span><span id="${gpts}-tables"></span></div>
                                                        <div class="d-flex justify-content-between">
                                                            <div style="text-align: start;"><a href="#" onclick="showCitations('${uuid}')"><span class="text-xs">Citations</span></a></div>
                                                            <div style="text-align: end;"><a href="#" onclick="copyToClipboard('${gpts}')"><span class="text-xs">Copy</span></a></div>
                                                        </div>
                                                       
                                                    </div>
                                                    <div class="tab-pane fade h-px-300" id="${citid}" role="tabpanel">
                                                        <ul id ="${docit}" class="list-inline"></ul>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        
                                    </div>
                                </div>
                            </div>
                        </li>
                                    `
            $('#main-chat-board').append(newuserchat);
            $('#main-chat-board').append(newsystemchat);

            messageInput.value = ""; // Clear the input field
            ExecuteChat(message, uuid)
        } else {
            if (selecteddocs.length === 0) {
                showNotificationToast('Error!', 'Please select atleast one document to continue', 'danger');
            }

        }
    }
    else{
        if(!isconnected){
            showNotificationToast('Error!','Connection to server is lost. Please try again later','danger');
        }
        else if(querylock){
            showNotificationToast('Error!','Chat locked to execute previous query','danger');
        }
        else{
            showNotificationToast('Error!','Please buy credits to continue','danger');
        }
    }
}
function copyToClipboard(spanId) {
   
    var textToCopy = document.getElementById(spanId).textContent;
    navigator.clipboard.writeText(textToCopy)
    
}
function ExecuteChat(message, container) {

    let isTabularQuery = $('#tabular_query_switch').is(':checked');
    
    var selecteddocs = getSelectedCheckboxIds();
    if(selecteddocs.length > 0 && TokenConsumption.available>0 && isconnected){
        var form = new FormData();
        form.append("query", message);
        form.append("chatid", container);
        form.append("semanticweight", $('#semweights').val());
        form.append("semanticqual", $('#semthreshold').val());
        form.append("inferencedoc", $('#inferencedocs').val());
        $.each(selecteddocs, function (index, label) {
            form.append('document', label);
        });

        var ep = `${applicationdomain}api/privaterag/ragquery`;
        if(isTabularQuery===true){
            ep = `${applicationdomain}api/privaterag/crosstabquery`;
        }
        //var cp = `${applicationdomain}api/privaterag/crosstabquery`;
        var jwt = GetStoredJwt();
        chatcompletion = []
        querylock = true;
        ShowFooterStatus('Executing RAG')

        $('#send-message-btn').removeClass('showsendbutton');
        $('#send-message-btn').addClass('hidesendbutton');
        
        $('#send-message-btn-disabled').removeClass('hidesendbutton');
        $('#send-message-btn-disabled').addClass('showsendbutton');
        
        $.ajax({
            url: ep,
            type: 'POST',
            dataType: 'json',
            data: form,
            processData: false,
            contentType: false,
            headers: {
                "Authorization": "Bearer " + jwt
            },
            success: function (Response) {
                HideFooterStatus();
                querylock = false;

                chathistory[container] = {
                    userquery: message,
                    answer: Response.message,
                    referances: Response.referances,
                    sql: Response.hasOwnProperty('sql') ? Response.sql : null
                };
                
                
                $('#send-message-btn-disabled').removeClass('showsendbutton');
                $('#send-message-btn-disabled').addClass('hidesendbutton');

                $('#send-message-btn').removeClass('hidesendbutton');
                $('#send-message-btn').addClass('showsendbutton');
                
                
                
                if (Response) {
    
                    UserUsage(Response.usage);
                    var boxid = `${container}-box`
                    var inferid = `${container}-infer`
                    var citid = `${container}-cit`
                    var gpts  = `${container}-gpt`
                    var docit  = `${container}-docit`

                    $('#'+ boxid).removeClass('hidechat')
                    $('#'+ boxid).addClass('showchat')

                    let joinedText = Response.message.replace(/\n/g, '<br>');
                    $('#' + gpts).html(`${joinedText}`);
                   

                    const chatBox = document.getElementById('list-of-chats');
                    chatBox.scrollTop = chatBox.scrollHeight;
                    
                    if(isspeachquery==true){
                        isspeachquery = false;
                        speakText(Response.message, 'en-US', 1.2, 0.5, () => {});
                    }
                    
                }
            },
            error: function (XMLHttpRequest, textStatus, errorThrown) {
                querylock = false;
                $('#send-message-btn-disabled').removeClass('showsendbutton');
                $('#send-message-btn-disabled').addClass('hidesendbutton');

                $('#send-message-btn').removeClass('hidesendbutton');
                $('#send-message-btn').addClass('showsendbutton');
                if (XMLHttpRequest.status === 401) {
                    LogoutUser()
                }
                else if (XMLHttpRequest.status === 400) {
                    unblockUI('#section-block');
                    var errorResponse = XMLHttpRequest.responseText;
                    NotifyToast('error', errorResponse)

                } else {
                    console.log("An error occurred:", errorThrown);
                    unblockUI('#section-block');
                }
            }
        });
    }
    else{
        
        if(TokenConsumption.available<=0){
            showNotificationToast('Error!','Please buy credits to continue','danger');
        }
        else if(!isconnected){
            showNotificationToast('Error!','Connection to server is lost. Please try again later','danger');
        }
        else {
            showNotificationToast('Error!','Please select atleast one document to continue','danger');
        }
        
    }

}

function showCitations(container) {
    try {
        var Citations = getChatHistory(container);
        if (Citations !== null) {
            showCitationsPopup(Citations);
        }
    } catch (error) {
        console.error('Error in showCitations:', error);
    }
}


function showCitationsPopup(container) {
    const data = typeof container === 'string' ? JSON.parse(container) : container;
    
    let citationModal = document.getElementById('citationModal');
    if (!citationModal) {
        citationModal = document.createElement('div');
        citationModal.id = 'citationModal';
    }
    
    
    
    const styleId = 'citationModalStyles';
    let styleElement = document.getElementById(styleId);
    if (!styleElement) {
        styleElement = document.createElement('style');
        styleElement.id = styleId;
        styleElement.textContent = `
            #citationModal .header-elements {
                display: flex;
                justify-content: space-between;
                align-items: center;
                padding-bottom: 12px;
                border-bottom: 1px solid #e9ecef;
                margin-bottom: 15px;
            }
            
            #citationModal .card {
                box-shadow: 0 2px 6px 0 rgba(67, 89, 113, 0.12);
                border: 0;
            }
            
            #citationModal .bg-label-primary {
                background-color: #e7e7ff !important;
                color: #696cff !important;
                font-size: 12px;
                padding: 5px 12px;
            }
            
            #citationModal .citation-list {
                list-style: none;
                padding: 0;
                margin: 0;
            }
            
            #citationModal .citation-container {
                max-height: 60vh;
                overflow-y: auto;
                padding-right: 10px;
            }
            
            #citationModal .citation-container::-webkit-scrollbar {
                width: 6px;
            }
            
            #citationModal .citation-container::-webkit-scrollbar-track {
                background: #f1f1f1;
            }
            
            #citationModal .citation-container::-webkit-scrollbar-thumb {
                background: #888;
                border-radius: 3px;
            }

            #citationModal .doc-info {
                color: #697a8d;
                font-size: 11px;
                margin-top: 10px;
                padding-top: 10px;
                border-top: 1px solid #4c4dbc;
            }

            #citationModal .card-title h6 {
                color: #e0e0e5;
                font-weight: 500;
            }

            #citationModal .content-section {
                padding-top: 10px;
                color: #a0a0a0;
                line-height: 1;
                font-size: 12px;
            }
        `;
        document.head.appendChild(styleElement);
    }

    citationModal.innerHTML = `
    <div id="citationModalBox" class="modal" tabindex="-1" aria-hidden="true" data-bs-backdrop="static">
        <div class="modal-dialog modal-dialog-centered modal-xxl">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Citations</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <!-- Query Card -->
                    <div class="card mb-4">
                        <div class="card-body">
                            <div class="card-title header-elements">
                                <h6 class="m-0 me-2">Query</h6>
                            </div>
                            <p class="card-text" style="font-size: 15px;">${data.userquery?.trim() || ''}</p>
                        </div>
                    </div>

                    <!-- References Section -->
                    <div class="citation-container">
                        <ul class="citation-list">
                            ${data.referances.map((ref, index) => `
                                <li class="p-2 pb-1">
                                    <div class="card mb-4">
                                        <div class="card-body">
                                            <div class="card-title header-elements">
                                                
                                                
                                               <h6 class="m-0 me-2 ${ref.doctype >= 2 ? 'cursor-pointer' : ''}" 
                                                    ${ref.doctype >= 2 ? `onclick='showResumePopup(${JSON.stringify(ref).replace(/'/g, "&apos;")});'` : ''}>
                                                    <i class="fas fa-file-alt me-2"></i>
                                                    ${index + 1}: ${ref.docname.trim()}
                                               </h6>
                                                
                                                <div class="card-title-elements ms-auto">
                                                    <span class="badge bg-label-primary rounded-pill">
                                                        Match Score: ${(ref.score * 100).toFixed(2)}%
                                                    </span>
                                                </div>
                                            </div>
                                            <div class="content-section">
                                                ${ref.content.trim()}
                                            </div>
                                            <div class="doc-info">
                                                <i class="fas fa-info-circle me-1"></i>
                                                Doc ID: ${ref.docid} | Content ID: ${ref.contentid}
                                            </div>
                                        </div>
                                    </div>
                                </li>
                            `).join('')}
                            
                            ${data.sql ? `
                                <li class="p-2 pb-1">
                                    <div class="card mb-4">
                                        <div class="card-body">
                                            <div class="card-title header-elements">
                                                <h6 class="m-0 me-2">
                                                    <i class="fas fa-database me-2"></i>
                                                    Ragenaizer Query
                                                </h6>
                                            </div>
                                            <div class="content-section">
                                                <code>${data.sql.trim()}</code>
                                            </div>
                                        </div>
                                    </div>
                                </li>
                            ` : ''}
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    `;

    if (!document.getElementById('citationModal')) {
        document.body.appendChild(citationModal);
    }

    const modalElement = document.getElementById('citationModalBox');
    const bsModal = new bootstrap.Modal(modalElement);
    bsModal.show();

    modalElement.addEventListener('hidden.bs.modal', function () {
        if (styleElement) {
            styleElement.remove();
        }
        citationModal.remove();
    });
}

function showResumePopup(container) {
    const data = typeof container === 'string' ? JSON.parse(container) : container;
    const resumeData = typeof data.content === 'string' ? JSON.parse(data.content) : data.content;

    // Format functions
    const formatDate = (dateStr, isCurrent) => {
        if (isCurrent) return 'Present';
        if (!dateStr) return 'N/A';
        const date = new Date(dateStr);
        return date.toLocaleDateString('en-US', { month: 'short', year: 'numeric' });
    };

    const formatExperience = (years) => {
        if (!years) return '';
        const wholeYears = Math.floor(years);
        const months = Math.round((years - wholeYears) * 12);
        return `${wholeYears} years${months ? ` ${months} months` : ''}`;
    };

    // Create or get the modal container
    let resumeModal = document.getElementById('resumeModal');
    if (!resumeModal) {
        resumeModal = document.createElement('div');
        resumeModal.id = 'resumeModal';
    }

    // Style initialization
    const styleId = 'resumeModalStyles';
    let styleElement = document.getElementById(styleId);
    if (!styleElement) {
        styleElement = document.createElement('style');
        styleElement.id = styleId;
        styleElement.textContent = `
            .resume-content {
                color: #cbcbe2;
            }
            
            .resume-header-title {
                color: #fff;
                font-size: 1.5rem;
                font-weight: 600;
                display: flex;
                align-items: center;
                gap: 10px;
            }
            
            .resume-container {
                max-height: 80vh;
                overflow-y: auto;
                padding-right: 15px;
            }
            
            .resume-container::-webkit-scrollbar {
                width: 6px;
            }
            
            .resume-container::-webkit-scrollbar-track {
                background: #383851;
                border-radius: 3px;
            }
            
            .resume-container::-webkit-scrollbar-thumb {
                background: #696cff;
                border-radius: 3px;
            }

            .resume-contact-info {
                display: flex;
                gap: 24px;
                flex-wrap: wrap;
                margin-bottom: 30px;
                background: rgba(105, 108, 255, 0.08);
                padding: 20px;
                border-radius: 10px;
            }

            .resume-contact-item {
                display: flex;
                align-items: center;
                gap: 10px;
                color: #cbcbe2;
                font-size: 0.95rem;
            }

            .resume-contact-item i {
                color: #696cff;
                font-size: 1.1rem;
            }

            .resume-total-experience {
                background: rgb(14 173 31 / 78%);
                padding: 10px 20px;
                border-radius: 6px;
                color: #fff;
                font-size: 0.9rem;
                display: inline-flex;
                align-items: center;
                gap: 8px;
            }

            .resume-summary {
                background: rgba(105, 108, 255, 0.05);
                padding: 20px;
                border-radius: 10px;
                margin: 20px 0;
                line-height: 1.6;
            }

            .resume-section-title {
                font-size: 1.25rem;
                font-weight: 600;
                color: #fff;
                margin: 35px 0 20px;
                display: flex;
                align-items: center;
                gap: 12px;
                border-bottom: 2px solid #444564;
                padding-bottom: 10px;
            }

            .resume-section-title i {
                color: #696cff;
            }

            .resume-exp-item {
                border-left: 2px solid #444564;
                padding-left: 25px;
                margin-bottom: 25px;
                position: relative;
                padding-bottom: 15px;
            }

            .resume-exp-item::before {
                content: '';
                position: absolute;
                left: -7px;
                top: 0;
                width: 12px;
                height: 12px;
                border-radius: 50%;
                background: #696cff;
                box-shadow: 0 0 0 3px rgba(105, 108, 255, 0.2);
            }

            .resume-job-title {
                font-weight: 600;
                color: #fff;
                margin-bottom: 8px;
                font-size: 1.1rem;
                display: flex;
                align-items: center;
                flex-wrap: wrap;
                gap: 10px;
            }

            .resume-current-badge {
                background: #28c76f1f;
                color: #28c76f;
                padding: 4px 12px;
                border-radius: 15px;
                font-size: 0.75rem;
                font-weight: 500;
                display: inline-flex;
                align-items: center;
                gap: 4px;
            }

            .resume-company-name {
                color: #cbcbe2;
                font-size: 1rem;
                display: flex;
                align-items: center;
                gap: 8px;
            }

            .resume-date-range {
                color: #7c7ca8;
                font-size: 0.9rem;
                margin: 8px 0 12px;
                display: flex;
                align-items: center;
                gap: 6px;
            }

            .resume-responsibilities {
                list-style-type: none;
                padding-left: 5px;
                color: #cbcbe2;
                font-size: 0.95rem;
                margin-top: 12px;
            }

            .resume-responsibilities li {
                margin-bottom: 8px;
                position: relative;
                padding-left: 20px;
                line-height: 1.5;
            }

            .resume-responsibilities li::before {
                content: '•';
                color: #696cff;
                position: absolute;
                left: 0;
                font-size: 1.2rem;
            }

            .resume-skills-section {
                background: rgba(105, 108, 255, 0.05);
                padding: 20px;
                border-radius: 10px;
                margin-top: 20px;
            }

            .resume-skills-container {
                display: flex;
                flex-wrap: wrap;
                gap: 12px;
                margin-top: 12px;
            }

            .resume-skill-category {
                margin-bottom: 25px;
                width: 100%;
            }

            .resume-skill-category h6 {
                color: #fff;
                font-size: 1.05rem;
                margin-bottom: 15px;
                display: flex;
                align-items: center;
                gap: 8px;
            }

            .resume-skill-tag {
                background: rgba(105, 108, 255, 0.15);
                color: #fff;
                padding: 12px 16px;
                border-radius: 10px;
                font-size: 0.9rem;
                transition: all 0.3s ease;
                border: 1px solid rgba(105, 108, 255, 0.2);
            }

            .resume-skill-description {
                color: #a5a5c5;
                font-size: 0.85rem;
                margin-top: 4px;
            }

            .resume-other-details {
                background: rgba(105, 108, 255, 0.05);
                padding: 20px;
                border-radius: 10px;
                margin-top: 20px;
                white-space: pre-line;
                line-height: 1.6;
            }

            .resume-languages-grid {
                display: grid;
                grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
                gap: 15px;
                margin-top: 20px;
            }

            .resume-language-item {
                background: rgba(105, 108, 255, 0.15);
                padding: 15px;
                border-radius: 10px;
                display: flex;
                align-items: center;
                justify-content: space-between;
                border: 1px solid rgba(105, 108, 255, 0.2);
            }

            .resume-keywords {
                display: flex;
                flex-wrap: wrap;
                gap: 8px;
                margin-top: 10px;
            }

            .resume-keyword-tag {
                background: rgba(105, 108, 255, 0.1);
                color: #fff;
                padding: 4px 12px;
                border-radius: 15px;
                font-size: 0.85rem;
            }

            .resume-personal-profiles {
                display: flex;
                flex-wrap: wrap;
                gap: 15px;
                margin-top: 15px;
            }

            .resume-profile-link {
                color: #696cff;
                text-decoration: none;
                display: flex;
                align-items: center;
                gap: 8px;
                font-size: 0.9rem;
            }

            .resume-profile-link:hover {
                text-decoration: underline;
            }
            
            .resume-other-details-list {
                display: flex;
                flex-direction: column;
                gap: 10px;
                margin-top: 15px;
            }

            .resume-other-detail-item {
                display: flex;
                align-items: center;
                padding: 8px 12px;
                background: rgba(105, 108, 255, 0.05);
                border-radius: 6px;
                font-size: 0.95rem;
                line-height: 1.5;
            }
        `;
        document.head.appendChild(styleElement);
    }

    const safeArray = (arr) => Array.isArray(arr) ? arr : [];

    resumeModal.innerHTML = `
    <div id="resumeModalBox" class="modal" tabindex="-1" aria-hidden="true" data-bs-backdrop="static">
        <div class="modal-dialog modal-dialog-centered modal-xxl">
            <div class="modal-content">
                <div class="modal-header">
                    <div>
                        <h5 class="modal-title resume-header-title">
                            <i class="fas fa-user-circle"></i>
                            ${resumeData?.personal_info?.full_name || 'N/A'}
                        </h5>
                    </div>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body resume-content">
                    <div class="resume-container">
                        <!-- Personal Information Section -->
                        <div class="resume-contact-info">
                            ${resumeData?.total_experience_years ? `
                                <div class="resume-total-experience">
                                    <i class="fas fa-business-time"></i>
                                    Total Experience: ${formatExperience(resumeData.total_experience_years)}
                                </div>
                            ` : ''}
                            ${resumeData?.personal_info?.email ? `
                                <div class="resume-contact-item">
                                    <i class="fas fa-envelope"></i>
                                    ${resumeData.personal_info.email}
                                </div>
                            ` : ''}
                            ${resumeData?.personal_info?.phone ? `
                                <div class="resume-contact-item">
                                    <i class="fas fa-phone"></i>
                                    ${resumeData.personal_info.phone}
                                </div>
                            ` : ''}
                            ${resumeData?.personal_info?.date_of_birth ? `
                                <div class="resume-contact-item">
                                    <i class="fas fa-birthday-cake"></i>
                                    ${new Date(resumeData.personal_info.date_of_birth).toLocaleDateString()}
                                </div>
                            ` : ''}
                            ${resumeData?.personal_info?.gender ? `
                                <div class="resume-contact-item">
                                    <i class="fas fa-user"></i>
                                    ${resumeData.personal_info.gender}
                                </div>
                            ` : ''}
                            ${resumeData?.personal_info?.marital_status ? `
                                <div class="resume-contact-item">
                                    <i class="fas fa-ring"></i>
                                    ${resumeData.personal_info.marital_status}
                                </div>
                            ` : ''}
                            ${resumeData?.personal_info?.current_location ? `
                                <div class="resume-contact-item">
                                    <i class="fas fa-map-marker-alt"></i>
                                    ${resumeData.personal_info.current_location?.city || ''}, 
                                    ${resumeData.personal_info.current_location?.state || ''}, 
                                    ${resumeData.personal_info.current_location?.country || ''}
                                </div>
                            ` : ''}
                            ${resumeData?.personal_info?.address ? `
                                <div class="resume-contact-item">
                                    <i class="fas fa-home"></i>
                                    ${resumeData.personal_info.address.street || ''}, 
                                    ${resumeData.personal_info.address.city || ''}, 
                                    ${resumeData.personal_info.address.state || ''} 
                                    ${resumeData.personal_info.address.zip_code || ''}
                                </div>
                            ` : ''}
                            ${resumeData?.personal_info?.website ? `
                                <div class="resume-contact-item">
                                    <i class="fas fa-globe"></i>
                                    <a href="${resumeData.personal_info.website}" target="_blank">${resumeData.personal_info.website}</a>
                                </div>
                            ` : ''}
                            ${resumeData?.personal_info?.linkedin ? `
                                <div class="resume-contact-item">
                                    <i class="fab fa-linkedin"></i>
                                    <a href="${resumeData.personal_info.linkedin}" target="_blank">LinkedIn Profile</a>
                                </div>
                            ` : ''}
                            ${resumeData?.personal_info?.other_profiles ? `
                                <div class="resume-contact-item">
                                    <i class="fas fa-link"></i>
                                    ${safeArray(resumeData.personal_info.other_profiles).join(', ')}
                                </div>
                            ` : ''}
                        </div>

                        <!-- Keywords Section -->
                        ${resumeData?.keywords ? `
                            <div class="resume-skills-section mt-3">
                                <div class="resume-skills-container">
                                    ${safeArray(resumeData.keywords).map(keyword => `
                                        <span class="resume-skill-tag">
                                            <i class="fas fa-tag"></i>
                                            ${keyword || ''}
                                        </span>
                                    `).join('')}
                                </div>
                            </div>
                        ` : ''}

                        <!-- Summary Section -->
                        ${resumeData?.summary ? `
                            <div class="resume-section-title">
                                <i class="fas fa-file-alt"></i>
                                Summary
                            </div>
                            <p>${resumeData.summary}</p>
                        ` : ''}

                        <!-- Experience Section -->
                        ${resumeData?.experience ? `
                            <div class="resume-section-title">
                                <i class="fas fa-briefcase"></i>
                                Professional Experience
                            </div>
                            ${safeArray(resumeData.experience).map(exp => `
                                <div class="resume-exp-item">
                                    <div class="resume-job-title">
                                        ${exp?.job_title || ''}
                                        ${exp?.is_current ? `
                                            <span class="resume-current-badge">
                                                <i class="fas fa-check-circle"></i>
                                                Current
                                            </span>
                                        ` : ''}
                                    </div>
                                    <div class="resume-company-name">
                                        <i class="fas fa-building" style="color: #696cff;"></i>
                                        ${exp?.company?.name || ''}
                                        ${exp?.company?.location ? ` • ${exp.company.location}` : ''}
                                    </div>
                                    <div class="resume-date-range">
                                        <i class="fas fa-calendar-alt"></i>
                                        ${formatDate(exp?.start_date)} - ${formatDate(exp?.end_date, exp?.is_current)}
                                    </div>
                                    <ul class="resume-responsibilities">
                                        ${safeArray(exp?.responsibilities).map(resp => `
                                            <li>${resp || ''}</li>
                                        `).join('')}
                                        ${exp?.achievements ? safeArray(exp.achievements).map(achievement => `
                                            <li class="achievement">
                                                <i class="fas fa-trophy" style="color: #ffd700;"></i> ${achievement || ''}
                                            </li>
                                        `).join('') : ''}
                                    </ul>
                                </div>
                            `).join('')}
                        ` : ''}

                        <!-- Education Section -->
                        ${resumeData?.education ? `
                            <div class="resume-section-title">
                                <i class="fas fa-graduation-cap"></i>
                                Education
                            </div>
                            ${safeArray(resumeData.education).map(edu => `
                                <div class="resume-exp-item">
                                    <div class="resume-job-title">
                                        ${edu?.degree || ''}${edu?.field_of_study ? ` in ${edu.field_of_study}` : ''}
                                        ${edu?.is_current ? `
                                            <span class="resume-current-badge">
                                                <i class="fas fa-check-circle"></i>
                                                Current
                                            </span>
                                        ` : ''}
                                    </div>
                                    <div class="resume-company-name">
                                        <i class="fas fa-university" style="color: #696cff;"></i>
                                        ${edu?.school?.name || ''}
                                        ${edu?.school?.location ? ` • ${edu.school.location}` : ''}
                                    </div>
                                    ${edu?.start_date ? `
                                        <div class="resume-date-range">
                                            <i class="fas fa-calendar-alt"></i>
                                            ${formatDate(edu.start_date)} - ${formatDate(edu.end_date, edu.is_current)}
                                        </div>
                                    ` : ''}
                                    ${edu?.achievements ? `
                                        <ul class="resume-responsibilities">
                                            ${safeArray(edu.achievements).map(achievement => `
                                                <li class="achievement">
                                                    <i class="fas fa-award" style="color: #ffd700;"></i> ${achievement || ''}
                                                </li>
                                            `).join('')}
                                        </ul>
                                    ` : ''}
                                </div>
                            `).join('')}
                        ` : ''}

                        <!-- Skills Section -->
                        ${resumeData?.skills ? `
                            <div class="resume-section-title">
                                <i class="fas fa-star"></i>
                                Skills
                            </div>
                            <div class="resume-skills-section">
                                ${safeArray(resumeData.skills).map(skillCategory => `
                                    <div class="resume-skill-category">
                                        <h6>
                                            <i class="fas fa-check-circle" style="color: #696cff;"></i>
                                            ${skillCategory?.category || ''}
                                        </h6>
                                        <div class="resume-skills-container">
                                            ${safeArray(skillCategory?.skills_list).map(skill => `
                                                <div class="resume-skill-tag" title="${skill?.description || ''}">
                                                    <span>${skill?.skill_name || ''}</span>
                                                    ${skill?.description ? `
                                                        <span class="resume-skill-description">- ${skill.description}</span>
                                                    ` : ''}
                                                </div>
                                            `).join('')}
                                        </div>
                                    </div>
                                `).join('')}
                            </div>
                        ` : ''}

                        <!-- Certifications Section -->
                        ${resumeData?.certifications ? `
                            <div class="resume-section-title">
                                <i class="fas fa-certificate"></i>
                                Certifications
                            </div>
                            ${safeArray(resumeData.certifications).map(cert => `
                                <div class="resume-exp-item">
                                    <div class="resume-job-title">
                                        ${cert?.name || ''}
                                    </div>
                                    <div class="resume-company-name">
                                        <i class="fas fa-award" style="color: #696cff;"></i>
                                        ${cert?.issuing_organization || ''}
                                    </div>
                                    <div class="resume-date-range">
                                        <i class="fas fa-calendar-alt"></i>
                                        Issued: ${formatDate(cert?.issue_date)}
                                        ${cert?.expiration_date ? ` - Expires: ${formatDate(cert.expiration_date)}` : ''}
                                    </div>
                                </div>
                            `).join('')}
                        ` : ''}

                        <!-- Projects Section -->
                        ${resumeData?.projects ? `
                            <div class="resume-section-title">
                                <i class="fas fa-project-diagram"></i>
                                Projects
                            </div>
                            ${safeArray(resumeData.projects).map(project => `
                                <div class="resume-exp-item">
                                    <div class="resume-job-title">
                                        ${project?.name || ''}
                                        ${project?.is_current ? `
                                            <span class="resume-current-badge">
                                                <i class="fas fa-check-circle"></i>
                                                Current
                                            </span>
                                        ` : ''}
                                    </div>
                                    ${project?.role ? `
                                        <div class="resume-company-name">
                                            <i class="fas fa-user-tag" style="color: #696cff;"></i>
                                            Role: ${project.role}
                                        </div>
                                    ` : ''}
                                    <div class="resume-date-range">
                                        <i class="fas fa-calendar-alt"></i>
                                        ${formatDate(project?.start_date)} - ${formatDate(project?.end_date, project?.is_current)}
                                    </div>
                                    ${project?.description ? `<p>${project.description}</p>` : ''}
                                    ${project?.technologies_used ? `
                                        <div class="resume-skills-container">
                                            ${safeArray(project.technologies_used).map(tech => `
                                                <span class="resume-skill-tag">
                                                    <i class="fas fa-code"></i>
                                                    ${tech || ''}
                                                </span>
                                            `).join('')}
                                        </div>
                                    ` : ''}
                                </div>
                            `).join('')}
                        ` : ''}

                        <!-- Languages Section -->
                        ${resumeData?.languages ? `
                            <div class="resume-section-title">
                                <i class="fas fa-language"></i>
                                Languages
                            </div>
                            <div class="resume-skills-section">
                                <div class="resume-skills-container">
                                    ${safeArray(resumeData.languages).map(lang => `
                                        <span class="resume-skill-tag">
                                            <i class="fas fa-comment"></i>
                                            ${lang?.language || ''} - ${lang?.proficiency || ''}
                                        </span>
                                    `).join('')}
                                </div>
                            </div>
                        ` : ''}

                        <!-- Publications Section -->
                        ${resumeData?.publications ? `
                            <div class="resume-section-title">
                                <i class="fas fa-book"></i>
                                Publications
                            </div>
                            ${safeArray(resumeData.publications).map(pub => `
                                <div class="resume-exp-item">
                                    <div class="resume-job-title">${pub?.title || ''}</div>
                                    <div class="resume-company-name">
                                        <i class="fas fa-newspaper" style="color: #696cff;"></i>
                                        ${pub?.publication_name || ''}
                                    </div>
                                    <div class="resume-date-range">
                                        <i class="fas fa-calendar-alt"></i>
                                        ${formatDate(pub?.date)}
                                    </div>
                                    ${pub?.url ? `
                                        <a href="${pub.url}" target="_blank" class="resume-skill-tag">
                                            <i class="fas fa-external-link-alt"></i>
                                            View Publication
                                        </a>
                                    ` : ''}
                                </div>
                            `).join('')}
                        ` : ''}

                        <!-- Volunteer Experience Section -->
                        ${resumeData?.volunteer_experience ? `
                            <div class="resume-section-title">
                                <i class="fas fa-hands-helping"></i>
                                Volunteer Experience
                            </div>
                            ${safeArray(resumeData.volunteer_experience).map(vol => `
                                <div class="resume-exp-item">
                                    <div class="resume-job-title">
                                        ${vol?.role || ''}
                                        ${vol?.is_current ? `
                                            <span class="resume-current-badge">
                                                <i class="fas fa-check-circle"></i>
                                                Current
                                            </span>
                                        ` : ''}
                                    </div>
                                    <div class="resume-company-name">
                                        <i class="fas fa-building" style="color: #696cff;"></i>
                                        ${vol?.organization?.name || ''}
                                        ${vol?.organization?.location ? ` • ${vol.organization.location}` : ''}
                                    </div>
                                    <div class="resume-date-range">
                                        <i class="fas fa-calendar-alt"></i>
                                        ${formatDate(vol?.start_date)} - ${formatDate(vol?.end_date, vol?.is_current)}
                                    </div>
                                    ${vol?.description ? `<p>${vol.description}</p>` : ''}
                                </div>
                            `).join('')}
                        ` : ''}

                        <!-- References Section -->
                        ${resumeData?.references ? `
                            <div class="resume-section-title">
                                <i class="fas fa-user-friends"></i>
                                References
                            </div>
                            <div class="resume-skills-section">
                                ${safeArray(resumeData.references).map(ref => `
                                    <div class="resume-exp-item">
                                        <div class="resume-job-title">${ref?.name || ''}</div>
                                        <div class="resume-company-name">
                                            <i class="fas fa-user-tie" style="color: #696cff;"></i>
                                            ${ref?.relationship || ''}
                                        </div>
                                        ${ref?.contact_info ? `
                                            <div class="resume-contact-item mt-2">
                                                ${ref.contact_info.email ? `
                                                    <div class="mb-1">
                                                        <i class="fas fa-envelope"></i> ${ref.contact_info.email}
                                                    </div>
                                                ` : ''}
                                                ${ref.contact_info.phone ? `
                                                    <div>
                                                        <i class="fas fa-phone"></i> ${ref.contact_info.phone}
                                                    </div>
                                                ` : ''}
                                            </div>
                                        ` : ''}
                                    </div>
                                `).join('')}
                            </div>
                        ` : ''}

                        <!-- Interests Section -->
                        ${resumeData?.interests ? `
                            <div class="resume-section-title">
                                <i class="fas fa-heart"></i>
                                Interests
                            </div>
                            <div class="resume-skills-section">
                                <div class="resume-skills-container">
                                    ${safeArray(resumeData.interests).map(interest => `
                                        <span class="resume-skill-tag">
                                            <i class="fas fa-star"></i>
                                            ${interest || ''}
                                        </span>
                                    `).join('')}
                                </div>
                            </div>
                        ` : ''}

                        <!-- Additional Information Section -->
                        ${resumeData?.additional_info ? `
                            <div class="resume-section-title">
                                <i class="fas fa-info-circle"></i>
                                Additional Information
                            </div>
                            <div class="resume-skills-section">
                                ${resumeData.additional_info?.hobbies ? `
                                    <div class="resume-skill-category">
                                        <h6>
                                            <i class="fas fa-heart" style="color: #696cff;"></i>
                                            Hobbies
                                        </h6>
                                        <div class="resume-skills-container">
                                            ${safeArray(resumeData.additional_info.hobbies).map(hobby => `
                                                <span class="resume-skill-tag">
                                                    <i class="fas fa-star"></i>
                                                    ${hobby || ''}
                                                </span>
                                            `).join('')}
                                        </div>
                                    </div>
                                ` : ''}
                                
                                ${resumeData.additional_info?.extracurricular_activities ? `
                                    <div class="resume-skill-category">
                                        <h6>
                                            <i class="fas fa-running" style="color: #696cff;"></i>
                                            Extracurricular Activities
                                        </h6>
                                        <div class="resume-skills-container">
                                            ${safeArray(resumeData.additional_info.extracurricular_activities).map(activity => `
                                                <span class="resume-skill-tag">
                                                    <i class="fas fa-check"></i>
                                                    ${activity || ''}
                                                </span>
                                            `).join('')}
                                        </div>
                                    </div>
                                ` : ''}
                                
                                ${resumeData.additional_info?.awards ? `
                                    <div class="resume-skill-category">
                                        <h6>
                                            <i class="fas fa-trophy" style="color: #696cff;"></i>
                                            Awards
                                        </h6>
                                        ${safeArray(resumeData.additional_info.awards).map(award => `
                                            <div class="resume-exp-item">
                                                <div class="resume-job-title">${award?.title || ''}</div>
                                                <div class="resume-company-name">
                                                    <i class="fas fa-award" style="color: #696cff;"></i>
                                                    ${award?.issuer || ''}
                                                </div>
                                                <div class="resume-date-range">
                                                    <i class="fas fa-calendar-alt"></i>
                                                    ${formatDate(award?.date)}
                                                </div>
                                                ${award?.description ? `<p>${award.description}</p>` : ''}
                                            </div>
                                        `).join('')}
                                    </div>
                                ` : ''}

                                ${resumeData.additional_info?.other_details ? `
                                    <div class="resume-skill-category">
                                        <h6>
                                            <i class="fas fa-plus-circle" style="color: #696cff;"></i>
                                            Other Details
                                        </h6>
                                        <div class="resume-other-details-list">
                                            ${resumeData.additional_info.other_details.split('\n').map(detail => `
                                                <div class="resume-other-detail-item">
                                                    <i class="fas fa-circle" style="color: #696cff; font-size: 8px; margin-right: 10px;"></i>
                                                    ${detail.trim()}
                                                </div>
                                            `).join('')}
                                        </div>
                                    </div>
                                ` : ''}
                            </div>
                        ` : ''}
                    </div>
                </div>
            </div>
        </div>
    </div>
`;

    // Append modal to body if it doesn't exist
    if (!document.getElementById('resumeModal')) {
        document.body.appendChild(resumeModal);
    }

    // Initialize and show Bootstrap modal
    const modalElement = document.getElementById('resumeModalBox');
    const bsModal = new bootstrap.Modal(modalElement);
    bsModal.show();

    // Cleanup on close
    modalElement.addEventListener('hidden.bs.modal', function () {
        if (styleElement) {
            styleElement.remove();
        }
        resumeModal.remove();
    });
}


function sanitizeText(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}


function getChatHistory(containerId) {
    // Check if container ID exists in chathistory
    if (chathistory.hasOwnProperty(containerId)) {
        return chathistory[containerId];
    }
    return null;
}

function getSelectedCheckboxIds() {

    const selectedCheckboxes = document.querySelectorAll("#contact-list input.doc-embeds[type='checkbox']:checked");
    const selectedIds = Array.from(selectedCheckboxes).map(checkbox => checkbox.id);
    return selectedIds;
}
function unselectAllCheckboxes() {
    const checkboxes = document.querySelectorAll("#contact-list input.doc-embeds[type='checkbox']");
    const selectedIds = [];
    checkboxes.forEach(checkbox => {
        if (checkbox.checked) {
            selectedIds.push(checkbox.id);
            checkbox.checked = false;
            $(`#${checkbox.id}-span`).removeClass("text-success");
            $('#total-selected-doc-span').text('')
        }
    });
    return selectedIds;
}
function GetUserDocumets() {
    ShowSpinner();
    var ep = `${applicationdomain}api/privaterag/getdocuments`;
    var jwt = GetStoredJwt();
    $.ajax({
        url: ep,
        type: 'GET',
        dataType: 'json',
        processData: false,
        contentType: false,
        headers: {
            "Authorization": "Bearer " + jwt
        },
        success: function (Response) {
            HideSpinner();
            if (Response) {
                UserUsage(Response.usages);
                PopulateUserDocumnet(Response.documents);
            }
        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {
            HideSpinner();
            if (XMLHttpRequest.status === 401) {
                LogoutUser()
            }
            else if (XMLHttpRequest.status === 400) {
                unblockUI('#section-block');
                var errorResponse = XMLHttpRequest.responseText;
                NotifyToast('error', errorResponse)

            } else {
                console.log("An error occurred:", errorThrown);
                unblockUI('#section-block');
            }
        }
    });
}



function ChatBotStatusChange(folderid){
    var inp=`#${folderid}-cbstatus`;
    var controls = $(inp);
    controls.prop('disabled',true);
    var current = $(inp).prop('checked');
    ShowFooterStatus('Changing Status')
    var form = new FormData();
    form.append('docid', folderid);
    form.append('mode', current===false?'private':'public');
    var ep = `${applicationdomain}api/privaterag/privatepublicmode`;
    var jwt = GetStoredJwt();
    $.ajax({
        url: ep,
        type: 'POST',
        dataType: 'json',
        data: form,
        processData: false,
        contentType: false,
        headers: {
            "Authorization": "Bearer " + jwt
        },
        success: function (Response) {
            HideFooterStatus();
            if (Response) {
                UserUsage(Response.usages);
                PopulateUserDocumnet(Response.documents);
                showNotificationToast('ChatBot!', 'ChatBot status changed successfully', 'success');
            }
        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {
            HideFooterStatus();
            if (XMLHttpRequest.status === 401) {
                LogoutUser()
            }
            else if (XMLHttpRequest.status === 400) {
                var errorResponse = XMLHttpRequest.responseJSON;
                ErrorMessage()
            } else {
                console.log("An error occurred:", errorThrown);
            }
        }
    });
    
    
}
function UploadUserDocumentPrompt(folder) {
    
    var datatopass = folder!==null?`'${folder}'`:null;
    const labels = getFolderName(folder);
    var HeaderLine = 'Add New Project';
    if(datatopass!==null){
        HeaderLine =`Add File To Project: ${labels}`;
    }

    // First, remove any existing modal container
    const existingModal = document.getElementById('modaldivholder');
    if (existingModal) {
        existingModal.remove();
    }

    // Also remove any lingering modal elements
    const existingModalElement = document.getElementById('uploadpdfdocmodal');
    if (existingModalElement) {
        existingModalElement.remove();
    }

    // Clean up any existing bootstrap modal backdrop
    const existingBackdrop = document.querySelector('.modal-backdrop');
    if (existingBackdrop) {
        existingBackdrop.remove();
    }

    // Remove modal-open class from body if present
    document.body.classList.remove('modal-open');
    document.body.style.removeProperty('padding-right');

    // Create new modal container
    const modalContainer = document.createElement('div');
    modalContainer.id = 'modaldivholder';

    modalContainer.innerHTML = `
        <div id="uploadpdfdocmodal" class="modal fade" tabindex="-1" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered modal-xl" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel4"><span class="text-primary"> ${HeaderLine}</span></h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                            <div class="row">
                                  <div class="col mb-3">
                                    <label for="docselector" class="form-label">File</label>
                                    <input type="file" id="docselector" class="form-control" placeholder="Select a pdf file" onChange="validateFileInput('docselector', ['.pdf', '.docx', '.xlsx', '.pptx', '.txt','.json','.sav'])">
                                  </div>
                            </div>
                            <div class="row">
                                  <div class="col mb-3">
                                    <label for="docdescription" class="form-label">Description</label>
                                    <input type="text" id="docdescription" class="form-control" placeholder="Enter a short description">
                                  </div>
                            </div>
                            
                            <div class="row">
                                <div class="col-md mb-md-0 mb-2">
                                  <div class="form-check custom-option custom-option-icon">
                                    <label class="form-check-label custom-option-content" for="gp-doc">
                                      <span class="custom-option-body">
                                        <i class="bx bx-rocket"></i>
                                        <span class="custom-option-title">General Purpose Document</span>
                                        <small> The document contains non-specific content that applies to a wide range of fields.</small>
                                      </span>
                                      <input name="customRadioIcon" class="form-check-input" type="radio" value="" id="gp-doc" checked="true">
                                    </label>
                                  </div>
                                </div>
                                <div class="col-md mb-md-0 mb-2">
                                  <div class="form-check custom-option custom-option-icon">
                                    <label class="form-check-label custom-option-content" for="md-doc">
                                      <span class="custom-option-body">
                                        <i class="bx bx-dollar"></i>
                                        <span class="custom-option-title">Financial Document</span>
                                        <small> This document covers financial reports, investments, taxes, or accounting. </small>
                                      </span>
                                      <input name="customRadioIcon" class="form-check-input" type="radio" value="" id="fin-doc">
                                    </label>
                                  </div>
                                </div>
                                <div class="col-md">
                                  <div class="form-check custom-option custom-option-icon">
                                    <label class="form-check-label custom-option-content" for="leg-doc">
                                      <span class="custom-option-body">
                                        <i class="bx bx-cctv"></i>
                                        <span class="custom-option-title"> Legal Document </span>
                                        <small>The document contains content related to laws, legal agreements, or regulatory information.</small>
                                      </span>
                                      <input name="customRadioIcon" class="form-check-input" type="radio" value="" id="leg-doc">
                                    </label>
                                  </div>
                                </div>
                                 <div class="col-md">
                                  <div class="form-check custom-option custom-option-icon">
                                    <label class="form-check-label custom-option-content" for="resume-doc">
                                      <span class="custom-option-body">
                                        <i class="bx bx-user"></i>
                                        <span class="custom-option-title"> Candidate Resume </span>
                                        <small>Professional document containing work history, education and skills for job recruitment.</small>
                                      </span>
                                      <input name="customRadioIcon" class="form-check-input" type="radio" value="" id="resume-doc">
                                    </label>
                                  </div>
                                </div>
                            </div>
                    </div>
                    <div class="modal-footer">
                        <div class="d-flex justify-content-between w-100">
                           
                            
                            <div class="align-items-center d-inline-flex">
                             <span class="me-2 text-xs">Compatible File Formats</span>
                                <div class="d-flex align-items-center avatar-group">
                                    <div class="avatar avatar-xs pull-up" data-bs-toggle="tooltip" data-popup="tooltip-custom" data-bs-placement="top" aria-label="Word" data-bs-original-title="Word">
                                        <img src="theme2/assets/img/icons/misc/rg_word.png" alt="Avatar" class="rounded-circle">
                                    </div>
                                    <div class="avatar avatar-xs pull-up" data-bs-toggle="tooltip" data-popup="tooltip-custom" data-bs-placement="top" aria-label="Power Point" data-bs-original-title="Power Point">
                                        <img src="theme2/assets/img/icons/misc/rg_powerpoint.png" alt="Avatar" class="rounded-circle">
                                    </div>
                                    <div class="avatar avatar-xs pull-up" data-bs-toggle="tooltip" data-popup="tooltip-custom" data-bs-placement="top" aria-label="Excel" data-bs-original-title="Excel">
                                        <img src="theme2/assets/img/icons/misc/rg_excel.png" alt="Avatar" class="rounded-circle">
                                    </div>
                                    <div class="avatar avatar-xs pull-up" data-bs-toggle="tooltip" data-popup="tooltip-custom" data-bs-placement="top" aria-label="PDF" data-bs-original-title="PDF">
                                        <img src="theme2/assets/img/icons/misc/rg_pdf.png" alt="Avatar" class="rounded-circle">
                                    </div>
                                    <div class="avatar avatar-xs pull-up" data-bs-toggle="tooltip" data-popup="tooltip-custom" data-bs-placement="top" aria-label="Text" data-bs-original-title="Text">
                                        <img src="theme2/assets/img/icons/misc/rg_text.png" alt="Avatar" class="rounded-circle">
                                    </div>
                                    <div class="avatar avatar-xs pull-up" data-bs-toggle="tooltip" data-popup="tooltip-custom" data-bs-placement="top" aria-label="Text" data-bs-original-title="Text">
                                        <img src="theme2/assets/img/icons/misc/js.png" alt="Avatar" class="rounded-circle">
                                    </div>
                                    <div class="avatar avatar-xs pull-up" data-bs-toggle="tooltip" data-popup="tooltip-custom" data-bs-placement="top" aria-label="Text" data-bs-original-title="Text">
                                        <img src="theme2/assets/img/icons/misc/spss.png" alt="Avatar" class="rounded-circle">
                                    </div>
                                </div>
                            </div>
                            <div>
                                <button type="button" class="btn btn-label-secondary" data-bs-dismiss="modal">Close</button>
                                <button type="button" class="btn btn-primary" onclick="SubmitDocumentUpload(${datatopass})">Upload</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>`;

    document.body.appendChild(modalContainer);

    // Reset any form inputs
    setTimeout(() => {
        const docSelector = document.getElementById('docselector');
        const docDescription = document.getElementById('docdescription');
        if (docSelector) docSelector.value = '';
        if (docDescription) docDescription.value = '';

        // Reset radio buttons
        document.getElementById('gp-doc').checked = true;
        document.getElementById('fin-doc').checked = false;
        document.getElementById('leg-doc').checked = false;
    }, 100);

    ShowPopupModal('uploadpdfdocmodal');
}
function SubmitDocumentUpload(folder){
        
    
    var input = document.getElementById('docselector');
    var descriptions = $('#docdescription').val();
    var doctype = getSelectedDocumentUploadType();
    var file = input.files[0];
    if (file && descriptions){

        if (doctype === 'resume-doc') {
            if (file.type !== 'application/pdf') {
                showNotificationToast('Document!', 'Please upload resume in PDF format only', 'danger');
                return;
            }
        }

        if (file.size > 25 * 1024 * 1024) { // 10MB limit example
            showNotificationToast('Document!', 'File size should be less than 25MB', 'danger');
            return;
        }
        
        HidePopupModal('uploadpdfdocmodal');
        
        
        var form = new FormData();
        form.append('document', file, file.name);
        form.append('description', descriptions);
        form.append('moduleid', 'chat');
        form.append('content', doctype);
        if(folder!==null){
            form.append('folder', folder);
        }
        
        var ep = `${applicationdomain}api/privaterag/docupload`;
        var jwt = GetStoredJwt();
        ShowFooterStatus('Started uploading your document')
        $.ajax({
            url: ep,
            type: 'POST',
            dataType: 'json',
            data: form,
            processData: false,
            contentType: false,
            headers: {
                "Authorization": "Bearer " + jwt
            },
            success: function (Response) {
                HideFooterStatus()
                if(Response.success){
                    PopulateUserDocumnet(Response.documents);
                    UserUsage(Response.usages);
                    showNotificationToast('Document!','File transformed successfully','success');
                }
                else{
                    showNotificationToast('Document!','An error occured while transforming pdf. Please try again after sometime','danger');
                }
            },
            error: function (XMLHttpRequest, textStatus, errorThrown) {
                if (XMLHttpRequest.status === 401) {
                    LogoutUser()
                }
                else if (XMLHttpRequest.status === 400) {
                    var errorResponse = XMLHttpRequest.responseJSON;
                    ErrorMessage()
                } else {
                    console.log("An error occurred:", errorThrown);
                }
            }
        });
       
    }
    else{
        if(descriptions.trim().length===0)
        {
            showNotificationToast('Document!','Please write a description about the document to continue','danger');
        }
        else {
            showNotificationToast('Document!','Please select a file to continue','danger');
        }
       
    }
}
function getSelectedDocumentUploadType(){
    const radioButtons = document.getElementsByName('customRadioIcon');

    // Find the checked radio button
    for (const radio of radioButtons) {
        if (radio.checked) {
            return radio.id;
        }
    }

    // Return default value if none selected (though one should always be selected)
    return 'gp-doc';
}

function renameFolder(docid) {


    // Check if modal already exists and remove it to avoid stale data
    let existingModal = document.getElementById('modalDocRename');
    if (existingModal) {
        existingModal.remove();
    }

    // Create a new modal
    let modalDocRename = document.createElement('div');
    modalDocRename.id = 'modalDocRename';
    modalDocRename.innerHTML = `
        <div id="modalDocRenamebox" class="modal" tabindex="-1" aria-hidden="true" data-bs-backdrop="static">
            <div class="modal-dialog modal-lg modal-simple modal-dialog-centered">
                <div class="modal-content p-3 p-md-5">
                    <div class="modal-body">
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        <div class="text-center mb-4">
                            <h3>${getFolderName(docid)}</h3>
                            <p>Rename this project</p>
                        </div>
                        <form id="renameForm" class="row g-3" onsubmit="return false">
                            <div class="col-12">
                                <label class="form-label w-100" for="renamedfoldervalue">New name</label>
                                <div class="input-group input-group-merge">
                                    <input
                                        id="renamedfoldervalue"
                                        name="renamedfoldervalue"
                                        class="form-control"
                                        type="text"
                                        placeholder="Enter the name"
                                        aria-describedby="renamedfoldervalue"
                                    />
                                    <span class="input-group-text cursor-pointer p-1" id="modalAddCard2"></span>
                                </div>
                            </div>
                            <div class="col-12 text-center">
                                <div class="d-flex justify-content-around">
                                    <button id="save-renameproj-button" type="submit" class="btn btn-primary me-sm-3 me-1 mt-3">Submit</button>
                                    <button class="btn btn-primary me-sm-3 me-1 mt-3 hidesendbutton" type="button" disabled="" id="save-renameproj-button-disabled">
                                        <span class="spinner-border me-1" role="status" aria-hidden="true"></span>
                                            Please wait...
                                    </button>
                                </div>
                                
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    `;

    document.body.appendChild(modalDocRename);
    ShowPopupModal('modalDocRenamebox');

    function SaveRenameProj(){

        var renamed = $('#renamedfoldervalue').val().trim();
        if(renamed){
            $('#save-renameproj-button').addClass('hidesendbutton');
            $('#save-renameproj-button-disabled').removeClass('hidesendbutton');
            $('#save-renameproj-button-disabled').addClass('showsendbutton');

            var form = new FormData();
            form.append('folderid', docid);
            form.append('rename', renamed);
            var ep = `${applicationdomain}api/privaterag/renameproj`;
            var jwt = GetStoredJwt();
            $.ajax({
                url: ep,
                type: 'POST',
                dataType: 'json',
                data: form,
                processData: false,
                contentType: false,
                headers: {
                    "Authorization": "Bearer " + jwt
                },
                success: function (Response) {
                    HideFooterStatus();
                    HidePopupModal('modalDocRenamebox');
                    if (Response) {
                        UserUsage(Response.usages);
                        PopulateUserDocumnet(Response.documents);
                        showNotificationToast('Project!', 'Project renamed successfully', 'success');
                    }
                },
                error: function (XMLHttpRequest, textStatus, errorThrown) {
                    HideFooterStatus();
                    HidePopupModal('modalDocRenamebox');
                    if (XMLHttpRequest.status === 401) {
                        LogoutUser()
                    }
                    else if (XMLHttpRequest.status === 400) {
                        var errorResponse = XMLHttpRequest.responseJSON;
                        ErrorMessage()
                    } else {
                        console.log("An error occurred:", errorThrown);
                    }
                }
            });
        }

    }

    $('#save-renameproj-button').on('click', SaveRenameProj);

}
function renameDocument(docid) {
    

    // Check if modal already exists and remove it to avoid stale data
    let existingModal = document.getElementById('modalDocRename');
    if (existingModal) {
        existingModal.remove();
    }

    // Create a new modal
    let modalDocRename = document.createElement('div');
    modalDocRename.id = 'modalDocRename';
    modalDocRename.innerHTML = `
        <div id="modalDocRenamebox" class="modal" tabindex="-1" aria-hidden="true" data-bs-backdrop="static">
            <div class="modal-dialog modal-lg modal-simple modal-dialog-centered">
                <div class="modal-content p-3 p-md-5">
                    <div class="modal-body">
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        <div class="text-center mb-4">
                            <h3>${getFileName(docid)}</h3>
                            <p>Rename this document</p>
                        </div>
                        <form id="renameForm" class="row g-3" onsubmit="return false">
                            <div class="col-12">
                                <label class="form-label w-100" for="renamedvalue">New name</label>
                                <div class="input-group input-group-merge">
                                    <input
                                        id="renamedvalue"
                                        name="renamedvalue"
                                        class="form-control"
                                        type="text"
                                        placeholder="Enter the name"
                                        aria-describedby="renamedvalue"
                                    />
                                    <span class="input-group-text cursor-pointer p-1" id="modalAddCard2"></span>
                                </div>
                            </div>
                            <div class="col-12 text-center">
                                <div class="d-flex justify-content-around">
                                    <button id="save-rename-button" type="submit" class="btn btn-primary me-sm-3 me-1 mt-3">Submit</button>
                                    <button class="btn btn-primary me-sm-3 me-1 mt-3 hidesendbutton" type="button" disabled="" id="save-rename-button-disabled">
                                        <span class="spinner-border me-1" role="status" aria-hidden="true"></span>
                                            Please wait...
                                    </button>
                                </div>
                                
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    `;
    
    document.body.appendChild(modalDocRename);
    ShowPopupModal('modalDocRenamebox');
    
    function SaveRename(){
        
        var renamed = $('#renamedvalue').val().trim();
        
        
        if(renamed){
            $('#save-rename-button').addClass('hidesendbutton');
            $('#save-rename-button-disabled').removeClass('hidesendbutton');
            $('#save-rename-button-disabled').addClass('showsendbutton');

            var form = new FormData();
            form.append('docid', docid);
            form.append('rename', renamed);
            var ep = `${applicationdomain}api/privaterag/renamedoc`;
            var jwt = GetStoredJwt();
            $.ajax({
                url: ep,
                type: 'POST',
                dataType: 'json',
                data: form,
                processData: false,
                contentType: false,
                headers: {
                    "Authorization": "Bearer " + jwt
                },
                success: function (Response) {
                    HideFooterStatus();
                    HidePopupModal('modalDocRenamebox');
                    if (Response) {
                        UserUsage(Response.usages);
                        PopulateUserDocumnet(Response.documents);
                        showNotificationToast('Document!', 'Document renamed successfully', 'success');
                    }
                },
                error: function (XMLHttpRequest, textStatus, errorThrown) {
                    HideFooterStatus();
                    HidePopupModal('modalDocRenamebox');
                    if (XMLHttpRequest.status === 401) {
                        LogoutUser()
                    }
                    else if (XMLHttpRequest.status === 400) {
                        var errorResponse = XMLHttpRequest.responseJSON;
                        ErrorMessage()
                    } else {
                        console.log("An error occurred:", errorThrown);
                    }
                }
            });
        }
      
    }
    
    $('#save-rename-button').on('click', SaveRename);
    
}
function archiveDocument(docid) {


    // Check if modal already exists and remove it to avoid stale data
    let existingModal = document.getElementById('modalDocArchive');
    if (existingModal) {
        existingModal.remove();
    }

    // Create a new modal
    let modalDocArchive = document.createElement('div');
    modalDocArchive.id = 'modalDocArchive';
    modalDocArchive.innerHTML = `
        <div id="modalDocArchivebox" class="modal" tabindex="-1" aria-hidden="true" data-bs-backdrop="static">
            <div class="modal-dialog modal-lg modal-simple modal-dialog-centered">
                <div class="modal-content p-3 p-md-5">
                    <div class="modal-body">
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        <div class="text-center mb-4">
                            <h3>${getFileName(docid)}</h3>
                            <p>Archive this document</p>
                        </div>
                        <div  class="row g-3" onsubmit="return false">
                            <div class="col-12 text-center">
                                <label class="form-label w-100" for="">Are you sure you want to archive this documnet?</label>
                            </div>
                            <div class="col-12 text-center">
                                <div class="d-flex justify-content-around">
                                    <button id="save-archive-button" type="submit" class="btn btn-primary me-sm-3 me-1 mt-3">Archive</button>
                                    <button class="btn btn-primary me-sm-3 me-1 mt-3 hidesendbutton" type="button" disabled="" id="save-archive-button-disabled">
                                        <span class="spinner-border me-1" role="status" aria-hidden="true"></span>
                                            Please wait...
                                    </button>
                                </div>
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    `;

    document.body.appendChild(modalDocArchive);
    ShowPopupModal('modalDocArchivebox');

    function SaveArchive(){

        $('#save-archive-button').addClass('hidesendbutton');
        $('#save-archive-button-disabled').removeClass('hidesendbutton');
        $('#save-archive-button-disabled').addClass('showsendbutton');

        var form = new FormData();
        form.append('docid', docid);
        var ep = `${applicationdomain}api/privaterag/archivedoc`;
        var jwt = GetStoredJwt();
        $.ajax({
            url: ep,
            type: 'POST',
            dataType: 'json',
            data: form,
            processData: false,
            contentType: false,
            headers: {
                "Authorization": "Bearer " + jwt
            },
            success: function (Response) {
                HideFooterStatus();
                HidePopupModal('modalDocArchivebox');
                if (Response) {
                    UserUsage(Response.usages);
                    PopulateUserDocumnet(Response.documents);
                    showNotificationToast('Document!', 'Document archived successfully', 'success');
                }
            },
            error: function (XMLHttpRequest, textStatus, errorThrown) {
                HideFooterStatus();
                HidePopupModal('modalDocArchivebox');
                if (XMLHttpRequest.status === 401) {
                    LogoutUser()
                }
                else if (XMLHttpRequest.status === 400) {
                    var errorResponse = XMLHttpRequest.responseJSON;
                    ErrorMessage()
                } else {
                    console.log("An error occurred:", errorThrown);
                }
            }
        });

    }

    $('#save-archive-button').on('click', SaveArchive);

}
function privatePublicDocument(docid, docname,currenttype) {


    // Check if modal already exists and remove it to avoid stale data
    let existingModal = document.getElementById('modalDocMode');
    if (existingModal) {
        existingModal.remove();
    }

    // Create a new modal
    let modalDocMode = document.createElement('div');
    modalDocMode.id = 'modalDocMode';
    modalDocMode.innerHTML = `
        <div id="modalDocModebox" class="modal" tabindex="-1" aria-hidden="true" data-bs-backdrop="static">
            <div class="modal-dialog modal-lg modal-simple modal-dialog-centered">
                <div class="modal-content p-3 p-md-5">
                    <div class="modal-body">
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        <div class="text-center mb-4">
                            <h3>${docname}</h3>
                            <p>${currenttype==='private'?'Make this document public':'Make this document private'}</p>
                        </div>
                        <div  class="row g-3" onsubmit="return false">
                            <div class="col-12 text-center">
                                <label class="form-label w-100" for="">Are you sure you want to change the access mode for this documnet?</label>
                            </div>
                            <div class="col-12 text-center">
                                <div class="d-flex justify-content-around">
                                    <button id="save-modes-button" type="submit" class="btn btn-primary me-sm-3 me-1 mt-3">${currenttype==='private'?'Make Public':'Make Private'}</button>
                                    <button class="btn btn-primary me-sm-3 me-1 mt-3 hidesendbutton" type="button" disabled="" id="save-modes-button-disabled">
                                        <span class="spinner-border me-1" role="status" aria-hidden="true"></span>
                                            Please wait...
                                    </button>
                                </div>
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    `;

    document.body.appendChild(modalDocMode);
    ShowPopupModal('modalDocModebox');

    function SaveModes(){

        $('#save-modes-button').addClass('hidesendbutton');
        $('#save-modes-button-disabled').removeClass('hidesendbutton');
        $('#save-modes-button-disabled').addClass('showsendbutton');

        var form = new FormData();
        form.append('docid', docid);
        form.append('mode', currenttype==='private'?'public':'private');
        var ep = `${applicationdomain}api/privaterag/privatepublicmode`;
        var jwt = GetStoredJwt();
        $.ajax({
            url: ep,
            type: 'POST',
            dataType: 'json',
            data: form,
            processData: false,
            contentType: false,
            headers: {
                "Authorization": "Bearer " + jwt
            },
            success: function (Response) {
                HideFooterStatus();
                HidePopupModal('modalDocModebox');
                if (Response) {
                    UserUsage(Response.usages);
                    PopulateUserDocumnet(Response.documents);
                }
            },
            error: function (XMLHttpRequest, textStatus, errorThrown) {
                HideFooterStatus();
                HidePopupModal('modalDocModebox');
                if (XMLHttpRequest.status === 401) {
                    LogoutUser()
                }
                else if (XMLHttpRequest.status === 400) {
                    var errorResponse = XMLHttpRequest.responseJSON;
                    ErrorMessage()
                } else {
                    console.log("An error occurred:", errorThrown);
                }
            }
        });

    }

    $('#save-modes-button').on('click', SaveModes);

}
function removeDocumentContent(docid) {


    // Check if modal already exists and remove it to avoid stale data
    let existingModal = document.getElementById('modalDocDelete');
    if (existingModal) {
        existingModal.remove();
    }

    // Create a new modal
    let modalDocDelete = document.createElement('div');
    modalDocDelete.id = 'modalDocDelete';
    modalDocDelete.innerHTML = `
        <div id="modalDocDeletebox" class="modal" tabindex="-1" aria-hidden="true" data-bs-backdrop="static">
            <div class="modal-dialog modal-lg modal-simple modal-dialog-centered">
                <div class="modal-content p-3 p-md-5">
                    <div class="modal-body">
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        <div class="text-center mb-4">
                            <h3>${getFileName(docid)}</h3>
                            <p>Delete document</p>
                        </div>
                        <div  class="row g-3" onsubmit="return false">
                            <div class="col-12 text-center">
                                <label class="form-label w-100 text-danger" for="">Are you sure you want to delete all content from this document? This action is irreversible.</label>
                            </div>
                            <div class="col-12 text-center">
                                <div class="d-flex justify-content-around">
                                    <button id="save-delete-button" type="submit" class="btn btn-primary me-sm-3 me-1 mt-3">Delete Document</button>
                                    <button class="btn btn-primary me-sm-3 me-1 mt-3 hidesendbutton" type="button" disabled="" id="save-delete-button-disabled">
                                        <span class="spinner-border me-1" role="status" aria-hidden="true"></span>
                                            Please wait...
                                    </button>
                                </div>
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    `;

    document.body.appendChild(modalDocDelete);
    ShowPopupModal('modalDocDeletebox');

    function SaveDelete(){

        $('#save-delete-button').addClass('hidesendbutton');
        $('#save-delete-button-disabled').removeClass('hidesendbutton');
        $('#save-delete-button-disabled').addClass('showsendbutton');

        var form = new FormData();
        form.append('docid', docid);
        var ep = `${applicationdomain}api/privaterag/removedocitems`;
        var jwt = GetStoredJwt();
        $.ajax({
            url: ep,
            type: 'POST',
            dataType: 'json',
            data: form,
            processData: false,
            contentType: false,
            headers: {
                "Authorization": "Bearer " + jwt
            },
            success: function (Response) {
                HideFooterStatus();
                HidePopupModal('modalDocDeletebox');
                if (Response) {
                    UserUsage(Response.usages);
                    PopulateUserDocumnet(Response.documents);
                    showNotificationToast('Document!', 'Document deleted successfully', 'success');
                }
            },
            error: function (XMLHttpRequest, textStatus, errorThrown) {
                HidePopupModal('modalDocDeletebox');
                if (XMLHttpRequest.status === 401) {
                    LogoutUser()
                }
                else if (XMLHttpRequest.status === 400) {
                    var errorResponse = XMLHttpRequest.responseJSON;
                    ErrorMessage()
                } else {
                    console.log("An error occurred:", errorThrown);
                }
            }
        });

    }

    $('#save-delete-button').on('click', SaveDelete);

}



function GenerateThemes(docid){
    if(TokenConsumption.available> 0  && isconnected){
        var file = getFileObject(docid);
        if(file.themes.length>0){
            var form = new FormData();
            form.append('docid', docid);
            form.append('themeid', file.themes[0]);
            var ep = `${applicationdomain}api/privaterag/getthemes`;
            var jwt = GetStoredJwt();
            $.ajax({
                url: ep,
                type: 'POST',
                dataType: 'json',
                data: form,
                processData: false,
                contentType: false,
                headers: {
                    "Authorization": "Bearer " + jwt
                },
                success: function (Response) {
                    HideFooterStatus();
                    if (Response) {
                        UserUsage(Response.usages);
                        PopulateUserDocumnet(Response.documents);
                        ShowThemes(docid,Response.theme);
                    }
                },
                error: function (XMLHttpRequest, textStatus, errorThrown) {
                    HidePopupModal('modalDocDeletebox');
                    if (XMLHttpRequest.status === 401) {
                        LogoutUser()
                    }
                    else if (XMLHttpRequest.status === 400) {
                        var errorResponse = XMLHttpRequest.responseJSON;
                        ErrorMessage()
                    } else {
                        console.log("An error occurred:", errorThrown);
                    }
                }
            });
        }
        else{
            GenerateNewThemes(docid);
        }
    }
    else{
        if(!isconnected){
            showNotificationToast('Error!','Connection to server is lost. Please try again later','danger');
        }
        else{
            showNotificationToast('Error!','Please buy credits to continue','danger');
        }
    }

}
function GenerateNewThemes(docid){

    if(TokenConsumption.available> 0  && isconnected){
        var form = new FormData();
        form.append('docid', docid);
        var ep = `${applicationdomain}api/privaterag/generatethemes`;
        var jwt = GetStoredJwt();
        $.ajax({
            url: ep,
            type: 'POST',
            dataType: 'json',
            data: form,
            processData: false,
            contentType: false,
            headers: {
                "Authorization": "Bearer " + jwt
            },
            success: function (Response) {
                HideFooterStatus();
                if (Response) {
                    UserUsage(Response.usages);
                    PopulateUserDocumnet(Response.documents);
                    ShowThemes(docid,Response.theme);
                }
            },
            error: function (XMLHttpRequest, textStatus, errorThrown) {
                HidePopupModal('modalDocDeletebox');
                if (XMLHttpRequest.status === 401) {
                    LogoutUser()
                }
                else if (XMLHttpRequest.status === 400) {
                    var errorResponse = XMLHttpRequest.responseJSON;
                    ErrorMessage()
                } else {
                    console.log("An error occurred:", errorThrown);
                }
            }
        });
    }
    else{
        if(!isconnected){
            showNotificationToast('Error!','Connection to server is lost. Please try again later','danger');
        }
        else{
            showNotificationToast('Error!','Please buy credits to continue','danger');
        }
    }

}
function ShowThemes(docid,themedata){
    var themeShowModal = null;
    if (!themeShowModal) {
        themeShowModal = document.createElement('div');
        themeShowModal.id = 'themeShowModal';
        document.body.appendChild(themeShowModal);
    }
    themeShowModal.innerHTML = `<div id="themeShowModalbox" class="modal"  tabindex="-1" aria-hidden="true" data-bs-backdrop="static">
    <div class="modal-dialog modal-dialog-centered modal-xl modal-simple">
        <div class="modal-content p-3 p-md-5" id="themeShowModalbox-content">
            
        </div>
    </div>
</div>

`
    document.body.appendChild(themeShowModal);
    
    var data = {
        theme : themedata,
        file:docid
    }
    
    LoadCustomControlWithRender('themeShowModalbox-content','views/chats/themedisplay.html',data,null)
    ShowPopupModal('themeShowModalbox')
}
function GetThematicData(docid){
    ShowFooterStatus('Finding document')
    var form = new FormData();
    form.append('docid', docid);
    var ep = `${applicationdomain}api/privaterag/getthematicanalysis`;
    var jwt = GetStoredJwt();
    $.ajax({
        url: ep,
        type: 'POST',
        dataType: 'json',
        data: form,
        processData: false,
        contentType: false,
        headers: {
            "Authorization": "Bearer " + jwt
        },
        success: function (Response) {
            HideFooterStatus();
            if (Response) {
                UserUsage(Response.usages);
                PopulateUserDocumnet(Response.documents);
                if(Response.theme.themes!==null){
                    ShowThematicCoding(docid,Response.theme);
                }
                else{
                    showNotificationToast('Theme!','You have not generated theme for this document. Please generate a theme to continue','danger');
                }
            }
        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {
            HidePopupModal('modalDocDeletebox');
            if (XMLHttpRequest.status === 401) {
                LogoutUser()
            }
            else if (XMLHttpRequest.status === 400) {
                var errorResponse = XMLHttpRequest.responseJSON;
                ErrorMessage()
            } else {
                console.log("An error occurred:", errorThrown);
            }
        }
    });
}
function ShowThematicCoding(docid,themedata){
    var themesShowModal = null;
    if (!themesShowModal) {
        themesShowModal = document.createElement('div');
        themesShowModal.id = 'themesShowModal';
        document.body.appendChild(themesShowModal);
    }
    themesShowModal.innerHTML = `<div id="themesShowModalbox" class="modal"  tabindex="-1" aria-hidden="true" data-bs-backdrop="static">
    <div class="modal-dialog modal-dialog-centered modal-xxl modal-simple">
        <div class="modal-content p-3 p-md-5" id="themesShowModalbox-content">
            
        </div>
    </div>
</div>

`
    document.body.appendChild(themesShowModal);

    var data = {
        theme : themedata,
        file:docid
    }

    LoadCustomControlWithRender('themesShowModalbox-content','views/chats/thematicanalysis.html',data,null)
    ShowPopupModal('themesShowModalbox')
}
function ExecuteThematicAnalysis(docid){
    if(TokenConsumption.available> 0  && isconnected){
        $('#btn-deletethematic-basic').removeClass('showaddbutton')
        $('#btn-generatethematic-basic').removeClass('showaddbutton')
        $('#btn-deletethematic-basic').addClass('hideaddbutton')
        $('#btn-generatethematic-basic').addClass('hideaddbutton')
        $('#btn-thematic-basic-load').removeClass('hideaddbutton')
        $('#btn-thematic-basic-load').addClass('showaddbutton')

        ShowFooterStatus('Finding document')
        var form = new FormData();
        form.append('docid', docid);
        var ep = `${applicationdomain}api/privaterag/exethematicoding`;
        var jwt = GetStoredJwt();
        $.ajax({
            url: ep,
            type: 'POST',
            dataType: 'json',
            data: form,
            processData: false,
            contentType: false,
            headers: {
                "Authorization": "Bearer " + jwt
            },
            success: function (Response) {
                HideFooterStatus();
                if (Response) {
                    UserUsage(Response.usages);
                    PopulateUserDocumnet(Response.documents);
                    ShowThematicCoding(docid,Response.theme);
                }
            },
            error: function (XMLHttpRequest, textStatus, errorThrown) {
                HidePopupModal('modalDocDeletebox');
                if (XMLHttpRequest.status === 401) {
                    LogoutUser()
                }
                else if (XMLHttpRequest.status === 400) {
                    var errorResponse = XMLHttpRequest.responseJSON;
                    ErrorMessage()
                } else {
                    console.log("An error occurred:", errorThrown);
                }
            }
        });
    }
    else{
        if(!isconnected){
            showNotificationToast('Error!','Connection to server is lost. Please try again later','danger');
        }
        else{
            showNotificationToast('Error!','Please buy credits to continue','danger');
        }
    }
    
    

}
function DownloadThematicFile(docid){
    $('#btn-deletesentiment-basic').removeClass('showaddbutton')
    $('#btn-generatesentiment-basic').removeClass('showaddbutton')
    $('#btn-deletesentiment-basic').addClass('hideaddbutton')
    $('#btn-generatesentiment-basic').addClass('hideaddbutton')
    $('#btn-sentiment-basic-load').removeClass('hideaddbutton')
    $('#btn-sentiment-basic-load').addClass('showaddbutton')
    ShowFooterStatus('Finding document')
    var form = new FormData();
    form.append('docid', docid);
    var ep = `${applicationdomain}api/privaterag/downloadthematics`;
    var jwt = GetStoredJwt();
    $.ajax({
        url: ep,
        type: 'POST',
        data: form,
        processData: false,
        contentType: false,
        headers: {
            "Authorization": "Bearer " + jwt
        },
        xhrFields: {
            responseType: 'blob' // Expect binary data (Blob) as a response
        },
        success: function (blob, status, xhr) {
            HideFooterStatus();
            // Check for Content-Disposition header to get filename
            var disposition = xhr.getResponseHeader('Content-Disposition');
            var fileName = "ragenaizer_thematics.xlsx"; // Default filename
            if (disposition && disposition.indexOf('attachment') !== -1) {
                var matches = /filename[^;=\n]*=((['"]).*?\2|[^;\n]*)/.exec(disposition);
                if (matches != null && matches[1]) {
                    fileName = matches[1].replace(/['"]/g, '');
                }
            }

            // Create a download link
            var url = window.URL.createObjectURL(blob);
            var a = document.createElement('a');
            a.href = url;
            a.download = fileName; // Set the filename
            document.body.appendChild(a); // Append anchor to the body
            a.click(); // Trigger the download
            window.URL.revokeObjectURL(url); // Revoke the object URL
            document.body.removeChild(a); // Remove anchor from the DOM


            $('#btn-deletesentiment-basic').removeClass('hideaddbutton')
            $('#btn-generatesentiment-basic').removeClass('hideaddbutton')
            $('#btn-deletesentiment-basic').addClass('showaddbutton')
            $('#btn-generatesentiment-basic').addClass('showaddbutton')
            $('#btn-sentiment-basic-load').removeClass('showaddbutton')
            $('#btn-sentiment-basic-load').addClass('hideaddbutton')



        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {
            HideFooterStatus();
            HidePopupModal('sentimentShowModalbox');
            if (XMLHttpRequest.status === 401) {
                LogoutUser();
            } else if (XMLHttpRequest.status === 400) {
                var errorResponse = XMLHttpRequest.responseJSON;
                ErrorMessage();
            } else {
                console.log("An error occurred:", errorThrown);
            }
        }
    });

}
function DeleteThematics(docid){
    $('#btn-deletethematic-basic').removeClass('showaddbutton')
    $('#btn-generatethematic-basic').removeClass('showaddbutton')
    $('#btn-deletethematic-basic').addClass('hideaddbutton')
    $('#btn-generatethematic-basic').addClass('hideaddbutton')
    $('#btn-thematic-basic-load').removeClass('hideaddbutton')
    $('#btn-thematic-basic-load').addClass('showaddbutton')
    ShowFooterStatus('Finding document')
    var form = new FormData();
    form.append('docid', docid);
    var ep = `${applicationdomain}api/privaterag/deletethematics`;
    var jwt = GetStoredJwt();
    $.ajax({
        url: ep,
        type: 'POST',
        dataType: 'json',
        data: form,
        processData: false,
        contentType: false,
        headers: {
            "Authorization": "Bearer " + jwt
        },
        success: function (Response) {
            HideFooterStatus();
            if (Response) {
                UserUsage(Response.usages);
                PopulateUserDocumnet(Response.documents);
                var data = {
                    theme : Response.thematics,
                    file:docid
                }
                LoadCustomControlWithRender('themeShowModalbox-content','views/chats/thematicanalysis.html',data,null)
            }
        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {
            HidePopupModal('modalDocDeletebox');
            if (XMLHttpRequest.status === 401) {
                LogoutUser()
            }
            else if (XMLHttpRequest.status === 400) {
                var errorResponse = XMLHttpRequest.responseJSON;
                ErrorMessage()
            } else {
                console.log("An error occurred:", errorThrown);
            }
        }
    });
}


function GetSentiment(docid){
    if(TokenConsumption.available> 0  && isconnected){
        ShowFooterStatus('Finding document')
        var form = new FormData();
        form.append('docid', docid);
        var ep = `${applicationdomain}api/privaterag/getsentiments`;
        var jwt = GetStoredJwt();
        $.ajax({
            url: ep,
            type: 'POST',
            dataType: 'json',
            data: form,
            processData: false,
            contentType: false,
            headers: {
                "Authorization": "Bearer " + jwt
            },
            success: function (Response) {
                HideFooterStatus();
                if (Response) {
                    UserUsage(Response.usages);
                    PopulateUserDocumnet(Response.documents);
                    DisplaySentiment(docid,Response.sentiments);
                }
            },
            error: function (XMLHttpRequest, textStatus, errorThrown) {
                HidePopupModal('modalDocDeletebox');
                if (XMLHttpRequest.status === 401) {
                    LogoutUser()
                }
                else if (XMLHttpRequest.status === 400) {
                    var errorResponse = XMLHttpRequest.responseJSON;
                    ErrorMessage()
                } else {
                    console.log("An error occurred:", errorThrown);
                }
            }
        });
    }
    else{
        if(!isconnected){
            showNotificationToast('Error!','Connection to server is lost. Please try again later','danger');
        }
        else{
            showNotificationToast('Error!','Please buy credits to continue','danger');
        }
    }
    
 
}
function DeleteSentiments(docid){
    $('#btn-deletesentiment-basic').removeClass('showaddbutton')
    $('#btn-generatesentiment-basic').removeClass('showaddbutton')
    $('#btn-deletesentiment-basic').addClass('hideaddbutton')
    $('#btn-generatesentiment-basic').addClass('hideaddbutton')
    $('#btn-sentiment-basic-load').removeClass('hideaddbutton')
    $('#btn-sentiment-basic-load').addClass('showaddbutton')
    ShowFooterStatus('Finding document')
    var form = new FormData();
    form.append('docid', docid);
    var ep = `${applicationdomain}api/privaterag/deletesentiments`;
    var jwt = GetStoredJwt();
    $.ajax({
        url: ep,
        type: 'POST',
        dataType: 'json',
        data: form,
        processData: false,
        contentType: false,
        headers: {
            "Authorization": "Bearer " + jwt
        },
        success: function (Response) {
            HideFooterStatus();
            if (Response) {
                UserUsage(Response.usages);
                PopulateUserDocumnet(Response.documents);
                var data = {
                    file:docid,
                    sentiments:Response.sentiments
                }
                LoadCustomControlWithRender('sentimentShowModalbox-content','views/chats/sentimentanaltics.html',data,null)
            }
        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {
            HidePopupModal('modalDocDeletebox');
            if (XMLHttpRequest.status === 401) {
                LogoutUser()
            }
            else if (XMLHttpRequest.status === 400) {
                var errorResponse = XMLHttpRequest.responseJSON;
                ErrorMessage()
            } else {
                console.log("An error occurred:", errorThrown);
            }
        }
    });
}
function GenerateSentiments(docid){
    if(TokenConsumption.available> 0  && isconnected){
        $('#btn-deletesentiment-basic').removeClass('showaddbutton')
        $('#btn-generatesentiment-basic').removeClass('showaddbutton')
        $('#btn-deletesentiment-basic').addClass('hideaddbutton')
        $('#btn-generatesentiment-basic').addClass('hideaddbutton')
        $('#btn-sentiment-basic-load').removeClass('hideaddbutton')
        $('#btn-sentiment-basic-load').addClass('showaddbutton')
        ShowFooterStatus('Finding document')
        var form = new FormData();
        form.append('docid', docid);
        var ep = `${applicationdomain}api/privaterag/generatesentiments`;
        var jwt = GetStoredJwt();
        $.ajax({
            url: ep,
            type: 'POST',
            dataType: 'json',
            data: form,
            processData: false,
            contentType: false,
            headers: {
                "Authorization": "Bearer " + jwt
            },
            success: function (Response) {
                HideFooterStatus();
                if (Response) {
                    UserUsage(Response.usages);
                    PopulateUserDocumnet(Response.documents);
                    // DisplaySentiment(docid,Response.sentiments);

                    var data = {
                        file:docid,
                        sentiments:Response.sentiments
                    }

                    LoadCustomControlWithRender('sentimentShowModalbox-content','views/chats/sentimentanaltics.html',data,null)
                }
            },
            error: function (XMLHttpRequest, textStatus, errorThrown) {
                HidePopupModal('modalDocDeletebox');
                if (XMLHttpRequest.status === 401) {
                    LogoutUser()
                }
                else if (XMLHttpRequest.status === 400) {
                    var errorResponse = XMLHttpRequest.responseJSON;
                    ErrorMessage()
                } else {
                    console.log("An error occurred:", errorThrown);
                }
            }
        });
    }
    else{
        if(!isconnected){
            showNotificationToast('Error!','Connection to server is lost. Please try again later','danger');
        }
        else{
            showNotificationToast('Error!','Please buy credits to continue','danger');
        }
    }
    
    
  
}
function DisplaySentiment(docid, sentiments){
    var sentimentShowModal = null;
    if (!sentimentShowModal) {
        sentimentShowModal = document.createElement('div');
        sentimentShowModal.id = 'sentimentShowModal';
        document.body.appendChild(sentimentShowModal);
    }
    sentimentShowModal.innerHTML = `<div id="sentimentShowModalbox" class="modal"  tabindex="-1" aria-hidden="true" data-bs-backdrop="static">
    <div class="modal-dialog modal-dialog-centered modal-xxl modal-simple">
        <div class="modal-content p-3 p-md-5" id="sentimentShowModalbox-content">
            
        </div>
    </div>
</div>

`
    document.body.appendChild(sentimentShowModal);

    var data = {
        file:docid,
        sentiments:sentiments
    }
    
    LoadCustomControlWithRender('sentimentShowModalbox-content','views/chats/sentimentanaltics.html',data,null)
    ShowPopupModal('sentimentShowModalbox')
}
function DownloadSentimentFile(docid){
    $('#btn-deletesentiment-basic').removeClass('showaddbutton')
    $('#btn-generatesentiment-basic').removeClass('showaddbutton')
    $('#btn-deletesentiment-basic').addClass('hideaddbutton')
    $('#btn-generatesentiment-basic').addClass('hideaddbutton')
    $('#btn-sentiment-basic-load').removeClass('hideaddbutton')
    $('#btn-sentiment-basic-load').addClass('showaddbutton')
    ShowFooterStatus('Finding document')
    var form = new FormData();
    form.append('docid', docid);
    var ep = `${applicationdomain}api/privaterag/downloadsentiments`;
    var jwt = GetStoredJwt();
    $.ajax({
        url: ep,
        type: 'POST',
        data: form,
        processData: false,
        contentType: false,
        headers: {
            "Authorization": "Bearer " + jwt
        },
        xhrFields: {
            responseType: 'blob' // Expect binary data (Blob) as a response
        },
        success: function (blob, status, xhr) {
            HideFooterStatus();
            // Check for Content-Disposition header to get filename
            var disposition = xhr.getResponseHeader('Content-Disposition');
            var fileName = "ragenaizer_sentiment.xlsx"; // Default filename
            if (disposition && disposition.indexOf('attachment') !== -1) {
                var matches = /filename[^;=\n]*=((['"]).*?\2|[^;\n]*)/.exec(disposition);
                if (matches != null && matches[1]) {
                    fileName = matches[1].replace(/['"]/g, '');
                }
            }

            // Create a download link
            var url = window.URL.createObjectURL(blob);
            var a = document.createElement('a');
            a.href = url;
            a.download = fileName; // Set the filename
            document.body.appendChild(a); // Append anchor to the body
            a.click(); // Trigger the download
            window.URL.revokeObjectURL(url); // Revoke the object URL
            document.body.removeChild(a); // Remove anchor from the DOM


            $('#btn-deletesentiment-basic').removeClass('hideaddbutton')
            $('#btn-generatesentiment-basic').removeClass('hideaddbutton')
            $('#btn-deletesentiment-basic').addClass('showaddbutton')
            $('#btn-generatesentiment-basic').addClass('showaddbutton')
            $('#btn-sentiment-basic-load').removeClass('showaddbutton')
            $('#btn-sentiment-basic-load').addClass('hideaddbutton')
            
            
            
        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {
            HideFooterStatus();
            HidePopupModal('sentimentShowModalbox');
            if (XMLHttpRequest.status === 401) {
                LogoutUser();
            } else if (XMLHttpRequest.status === 400) {
                var errorResponse = XMLHttpRequest.responseJSON;
                ErrorMessage();
            } else {
                console.log("An error occurred:", errorThrown);
            }
        }
    });

}
function transformSentimentData(sentiments) {
    // Define the data structure
    const data = {
        title: "Sentiment Analysis",
        columns: ["Category", "Count"],
        rows: []
    };

    // Loop through the sentiment object and populate rows
    for (const sentiment in sentiments) {
        data.rows.push([sentiment.charAt(0).toUpperCase() + sentiment.slice(1), sentiments[sentiment]]);
    }

    return data;
}
function TransformClassData(sentiments, Title, Metric) {
    // Define the data structure
    const data = {
        title: Title,
        columns: ["Category", Metric],
        rows: []
    };

    // Loop through the sentiment object and populate rows
    for (const sentiment in sentiments) {
        data.rows.push([sentiment.charAt(0).toUpperCase() + sentiment.slice(1), sentiments[sentiment]]);
    }

    return data;
}



function analyzeDataTypes(data) {
    const uniqueCategories = new Set();

    // Helper function to determine exact data type of a value
    function getValueType(value) {
        if (!value && value !== 0) return 'empty';

        const strValue = value.toString().trim();

        // Check for percentage
        if (strValue.endsWith('%')) {
            const withoutPercent = strValue.replace('%', '');
            const parsed = parseFloat(withoutPercent);
            return !isNaN(parsed) && isFinite(parsed) ? 'percentage' : 'string';
        }

        // Check for clean number
        const parsed = parseFloat(strValue);
        if (!isNaN(parsed) && isFinite(parsed) && /^[+-]?\d*\.?\d+$/.test(strValue)) {
            return 'number';
        }

        return 'string';
    }

    // Validate basic data structure
    if (!data?.rows?.length || !Array.isArray(data.rows)) {
        return {
            canCreateChart: false,
            dataTypes: [],
            recommendedChart: null
        };
    }

    // Initialize analysis arrays
    const columnTypes = new Array(data.columns.length).fill(null);

    // Analyze first row to establish initial column types (skip first column - categories)
    for (let i = 1; i < data.rows[0].length; i++) {
        columnTypes[i] = getValueType(data.rows[0][i]);
    }

    // Check all rows have consistent types
    for (const row of data.rows) {
        // Add category
        if (row[0]) uniqueCategories.add(row[0].toString().trim());

        // Check each value column
        for (let i = 1; i < row.length; i++) {
            const currentType = getValueType(row[i]);

            // If type doesn't match initial type for this column, we can't create a chart
            if (currentType !== columnTypes[i]) {
                return {
                    canCreateChart: false,
                    dataTypes: [],
                    recommendedChart: null
                };
            }
        }
    }

    // Remove first (category) column type
    const dataTypes = columnTypes.slice(1).filter(type => type !== null);

    // Check if we can create a chart:
    // 1. Must have categories
    // 2. All value columns must be same type (all numbers or all percentages)
    // 3. No string or empty types in value columns
    const hasValidCategories = uniqueCategories.size > 0;
    const hasValidTypes = dataTypes.length > 0 &&
        !dataTypes.includes('string') &&
        !dataTypes.includes('empty');
    const allSameType = dataTypes.every(type => type === dataTypes[0]);

    if (!hasValidCategories || !hasValidTypes || !allSameType) {
        return {
            canCreateChart: false,
            dataTypes: dataTypes,
            recommendedChart: null
        };
    }

    // Determine chart type
    let recommendedChart = 'column';
    const categoryCount = uniqueCategories.size;

    if (categoryCount > 10) {
        recommendedChart = 'bar';
    } else if (data.columns.length > 3) {
        recommendedChart = 'line';
    } else if (categoryCount <= 6 && data.columns.length === 2) {
        recommendedChart = 'pie';
    }

    return {
        canCreateChart: true,
        dataTypes: dataTypes,
        recommendedChart: recommendedChart
    };
}

function createBarChart(data, controlholder) {
    // Extract categories (use cases) from the first column
    const categories = data.rows.map(row => row[0].toString());

    // Create series array for all numeric columns
    const series = [];
    for (let i = 1; i < data.columns.length; i++) {
        series.push({
            name: data.columns[i],
            data: data.rows.map((row, index) => {
                const value = row[i].toString()
                    .replace(/^[+]/, ''); // Remove leading + but keep -
                return {
                    x: categories[index],
                    y: parseFloat(value) || 0
                };
            })
        });
    }

    const colors = [
        '#696cff', '#ff4c4c', '#4CAF50',
        '#FFA500', '#9C27B0', '#00BCD4'
    ];

    // Get the container and ensure it exists
    const container = document.querySelector("#" + controlholder);
    if (!container) return;

    // Ensure the container has proper height
    container.style.minHeight = '400px';

    const options = {
        series: series,
        chart: {
            parentHeightOffset: 0,
            height: '100%',
            type: 'bar',
            background: 'transparent',
            toolbar: {
                show: true
            },
            foreColor: '#ffffff',
            width: '100%',
            redrawOnWindowResize: true,
            redrawOnParentResize: true,
            animations: {
                enabled: false
            }
        },
        title: {
            text: data.title,
            align: 'left',
            margin: 20,
            offsetY: 20,
            style: {
                fontSize: '15px',
                fontWeight: 'bold',
                fontFamily: 'Public Sans',
                color: '#cbcbe2',
            }
        },
        plotOptions: {
            bar: {
                horizontal: true,
                borderRadius: 4,
                barHeight: '70%',
                track: {
                    background: 'rgba(255, 255, 255, 0.1)',
                    strokeWidth: '12%'
                },
                dataLabels: {
                    position: 'center',
                }
            }
        },
        dataLabels: {
            enabled: true,
            formatter: function(val) {
                return (val > 0 ? '+' : '') + Math.round(val);
            },
            style: {
                fontSize: '13px',
                fontFamily: 'Public Sans',
                colors: ['#ffffff']
            }
        },
        stroke: {
            dashArray: 5
        },
        colors: colors.slice(0, series.length),
        grid: {
            borderColor: 'rgba(255, 255, 255, 0.1)',
            strokeDashArray: 5,
            xaxis: {
                lines: {
                    show: true
                }
            }
        },
        xaxis: {
            type: 'category',
            labels: {
                style: {
                    colors: '#ffffff',
                    fontSize: '13px',
                    fontFamily: 'Public Sans'
                },
                formatter: function(val) {
                    return (val > 0 ? '+' : '') + Math.round(val);
                }
            }
        },
        yaxis: {
            labels: {
                style: {
                    colors: '#ffffff',
                    fontSize: '13px',
                    fontFamily: 'Public Sans'
                }
            }
        },
        legend: {
            position: 'top',
            labels: {
                colors: '#ffffff'
            },
            fontFamily: 'Public Sans',
            fontSize: '13px'
        }
    };

    // Create scroll container
    const scrollContainer = document.createElement('div');
    scrollContainer.style.cssText = `
        height: 400px;
        overflow-y: auto;
        overflow-x: hidden;
        position: relative;
    `;

    // Style scrollbar
    const styleId = `scrollbar-style-${controlholder}`;
    if (!document.getElementById(styleId)) {
        const style = document.createElement('style');
        style.id = styleId;
        style.textContent = `
            #${controlholder}-scroll::-webkit-scrollbar {
                width: 8px;
            }
            #${controlholder}-scroll::-webkit-scrollbar-track {
                background: rgba(255, 255, 255, 0.1);
            }
            #${controlholder}-scroll::-webkit-scrollbar-thumb {
                background: rgba(255, 255, 255, 0.2);
                border-radius: 4px;
            }
            #${controlholder}-scroll::-webkit-scrollbar-thumb:hover {
                background: rgba(255, 255, 255, 0.3);
            }
        `;
        document.head.appendChild(style);
    }

    // Set up scroll container
    scrollContainer.id = `${controlholder}-scroll`;
    const chartContent = document.createElement('div');
    chartContent.style.height = `${Math.max(400, data.rows.length * 50)}px`;

    // Rearrange DOM
    container.parentNode.insertBefore(scrollContainer, container);
    chartContent.appendChild(container);
    scrollContainer.appendChild(chartContent);

    const chart = new ApexCharts(container, options);
    chart.render();
    return chart;
}

function createColumnChart(data, controlholder) {
    const categories = data.rows.map(row => row[0]);

    // Improved data parsing
    const series = [];
    for (let i = 1; i < data.columns.length; i++) {
        series.push({
            name: data.columns[i],
            data: data.rows.map(row => {
                // Handle +/- signs properly
                const value = row[i].toString()
                    .replace(/^[+]/, ''); // Remove leading + but keep -
                return parseFloat(value) || 0;
            })
        });
    }

    const options = {
        series: series,
        chart: {
            height: 350,
            type: 'bar',
            background: 'transparent',
            toolbar: {
                show: true
            },
            foreColor: '#ffffff',
            width: '100%',
            redrawOnWindowResize: true,
            redrawOnParentResize: true
        },
        title: {
            text: data.title,
            align: 'left',
            margin: 20,
            offsetY: 20,
            style: {
                fontSize: '15px',
                fontWeight: 'bold',
                fontFamily: 'Public Sans',
                color: '#cbcbe2',
            }
        },
        plotOptions: {
            bar: {
                horizontal: false,
                columnWidth: '70%',
                borderRadius: 4,
                track: {
                    background: 'rgba(255, 255, 255, 0.1)',
                    strokeWidth: '12%'
                }
            }
        },
        dataLabels: {
            enabled: true,
            formatter: function(val) {
                // Add + for positive values
                return (val > 0 ? '+' : '') + Math.round(val);
            },
            style: {
                fontSize: '13px',
                fontFamily: 'Public Sans',
                colors: ['#ffffff']
            }
        },
        stroke: {
            dashArray: 5
        },
        colors: ['#696cff', '#ff4c4c'], // Blue for promoters, Red for detractors
        grid: {
            borderColor: 'rgba(255, 255, 255, 0.1)',
            strokeDashArray: 5
        },
        xaxis: {
            categories: categories,
            labels: {
                rotate: -45,
                style: {
                    colors: '#ffffff',
                    fontSize: '13px',
                    fontFamily: 'Public Sans'
                }
            }
        },
        yaxis: {
            labels: {
                formatter: function(val) {
                    // Add + for positive values
                    return (val > 0 ? '+' : '') + Math.round(val);
                },
                style: {
                    colors: '#ffffff',
                    fontSize: '13px',
                    fontFamily: 'Public Sans'
                }
            }
        },
        legend: {
            position: 'top',
            labels: {
                colors: '#ffffff'
            },
            fontFamily: 'Public Sans',
            fontSize: '13px'
        }
    };

    const chart = new ApexCharts(document.querySelector("#" + controlholder), options);
    chart.render();
    createResponsiveChart(chart);
    return chart;
}
function createPieChart(data, controlholder) {
    const categories = data.rows.map(row => row[0]);
    const values = data.rows.map(row => parseFloat(row[1].toString().replace('%', '')));
    const baseColor = '#696cff';
    const shades = generateShades(baseColor, data.rows.length);

    const options = {
        series: values,
        chart: {
            height: 350,
            type: 'pie',
            background: 'transparent',
            toolbar: {
                show: true
            },
            foreColor: '#ffffff',
            width: '100%',                    // Add this
            redrawOnWindowResize: true,       // Add this
            redrawOnParentResize: true

        },
        title: {
            text: data.columns[1],
            align: 'left',
            margin: 20,
            offsetY: 20,
            style: {
                fontSize: '15px',
                fontWeight: 'bold',
                fontFamily: 'Public Sans',
                color: '#cbcbe2',
            }
        },
        labels: categories,
        plotOptions: {
            pie: {
                startAngle: 0,
                endAngle: 360,
                donut: {
                    size: '60%'
                },
                track: {
                    background: 'rgba(255, 255, 255, 0.1)',
                    strokeWidth: '12%'
                }
            }
        },
        dataLabels: {
            enabled: true,
            formatter: function(val, opts) {
                return Math.round(opts.w.globals.seriesPercent[opts.seriesIndex]) + '%';
            },
            style: {
                fontSize: '13px',
                fontFamily: 'Public Sans',
                colors: ['#ffffff']
            }
        },
        stroke: {
            dashArray: 5
        },
        colors: shades,
        legend: {
            labels: {
                colors: '#ffffff'
            },
            fontFamily: 'Public Sans',
            fontSize: '13px'
        }
    };

    const chart = new ApexCharts(document.querySelector("#" + controlholder), options);
    chart.render();
    createResponsiveChart(chart);    // Add this
    return chart;
}
function createDonutChart(data, controlholder) {
    const categories = data.rows.map(row => row[0]);
    const values = data.rows.map(row => parseFloat(row[1].toString().replace('%', '')));
    const baseColor = '#696cff';
    const shades = generateShades(baseColor, data.rows.length);

    const options = {
        series: values,
        chart: {
            height: 350,
            type: 'donut',
            background: 'transparent',
            toolbar: {
                show: true
            },
            foreColor: '#ffffff',
            width: '100%',                    // Add this
            redrawOnWindowResize: true,       // Add this
            redrawOnParentResize: true

        },
        title: {
            text: data.columns[1],
            align: 'left',
            margin: 20,
            offsetY: 20,
            style: {
                fontSize: '15px',
                fontWeight: 'bold',
                fontFamily: 'Public Sans',
                color: '#cbcbe2',
            }
        },
        labels: categories,
        plotOptions: {
            pie: {
                startAngle: 0,
                endAngle: 360,
                donut: {
                    size: '70%'
                },
                track: {
                    background: 'rgba(255, 255, 255, 0.1)',
                    strokeWidth: '12%'
                }
            }
        },
        dataLabels: {
            enabled: true,
            formatter: function(val, opts) {
                return Math.round(opts.w.globals.seriesPercent[opts.seriesIndex]) + '%';
            },
            style: {
                fontSize: '13px',
                fontFamily: 'Public Sans',
                colors: ['#ffffff']
            }
        },
        stroke: {
            dashArray: 5
        },
        colors: shades,
        legend: {
            labels: {
                colors: '#ffffff'
            },
            fontFamily: 'Public Sans',
            fontSize: '13px'
        }
    };

    const chart = new ApexCharts(document.querySelector("#" + controlholder), options);
    chart.render();
    createResponsiveChart(chart);    // Add this
    return chart;
}

function createLineChart(data, controlholder) {
    const categories = data.rows.map(row => row[0]);

    // Create series for all numeric columns (skip first category column)
    const series = [];
    for (let i = 1; i < data.columns.length; i++) {
        series.push({
            name: data.columns[i],
            data: data.rows.map(row => {
                const value = row[i].toString()
                    .replace(/^[+]/, '')  // Remove leading + but keep -
                    .replace('%', '');    // Remove % if present
                return parseFloat(value) || 0;
            })
        });
    }

    const colors = [
        '#696cff',  // Blue
        '#ff4c4c',  // Red
        '#4CAF50',  // Green
        '#FFA500',  // Orange
        '#9C27B0',  // Purple
        '#00BCD4'   // Cyan
    ];

    const options = {
        series: series,
        chart: {
            height: 350,
            type: 'line',
            background: 'transparent',
            toolbar: {
                show: true
            },
            foreColor: '#ffffff',
            width: '100%',
            redrawOnWindowResize: true,
            redrawOnParentResize: true,
            offsetX: 0,
            offsetY: 0
        },
        title: {
            text: data.title,
            align: 'left',
            margin: 20,
            offsetY: 20,
            style: {
                fontSize: '15px',
                fontWeight: 'bold',
                fontFamily: 'Public Sans',
                color: '#cbcbe2',
            }
        },
        stroke: {
            curve: 'smooth',
            width: 2
        },
        markers: {
            size: 6,
            colors: colors.slice(0, series.length),
            strokeColors: '#1b1b1b',
            strokeWidth: 2,
            hover: {
                size: 8
            }
        },
        dataLabels: {
            enabled: true,
            offsetY: -10,  // Move labels up a bit
            style: {
                fontSize: '12px',
                fontFamily: 'Public Sans',
                fontWeight: 'bold',
                colors: ['#2b2c40']  // Black text for better contrast
            },
            background: {
                enabled: true,
                foreColor: '#ffffff',
                padding: 4,
                borderRadius: 4,
                borderWidth: 1,
                borderColor: '#303030',
                backgroundColor: ['#2b2c40'],
                opacity: 0.9,
                dropShadow: {
                    enabled: true,
                    top: 1,
                    left: 1,
                    blur: 1,
                    opacity: 0.5
                }
            },
            formatter: function(val) {
                return (val > 0 ? '+' : '') + Math.round(val);
            }
        },
        colors: colors.slice(0, series.length),
        grid: {
            borderColor: 'rgba(255, 255, 255, 0.1)',
            strokeDashArray: 5,
            xaxis: {
                lines: {
                    show: true
                }
            },
            padding: {
                left: 35,
                right: 35,
                top: 0,
                bottom: 0
            }
        },
        xaxis: {
            categories: categories,
            labels: {
                style: {
                    colors: '#ffffff',
                    fontSize: '13px',
                    fontFamily: 'Public Sans'
                },
                offsetX: 0,
                trim: false,
                maxHeight: 120,
                hideOverlappingLabels: true
            },
            axisBorder: {
                show: true,
                offsetX: 0,
                offsetY: 0
            },
            axisTicks: {
                show: true,
                borderType: 'solid',
                offsetX: 0,
                offsetY: 0
            }
        },
        yaxis: {
            labels: {
                formatter: function(val) {
                    return (val > 0 ? '+' : '') + Math.round(val);
                },
                style: {
                    colors: '#ffffff',
                    fontSize: '13px',
                    fontFamily: 'Public Sans'
                }
            }
        },
        legend: {
            position: 'top',
            labels: {
                colors: '#ffffff'
            },
            fontFamily: 'Public Sans',
            fontSize: '13px'
        },
        responsive: [{
            breakpoint: 576,
            options: {
                xaxis: {
                    labels: {
                        rotate: -45,
                        rotateAlways: true,
                        maxHeight: 80
                    }
                }
            }
        }]
    };

    const chart = new ApexCharts(document.querySelector("#" + controlholder), options);
    chart.render();
    createResponsiveChart(chart);
    return chart;
}
function createWordCloud(data, controlholder) {
    // Get container dimensions
    const container = document.getElementById(controlholder);

    // Set explicit height if not already set
    if (!container.style.height) {
        container.style.height = '400px';
    }

    const width = container.clientWidth;
    const height = container.clientHeight;

    // Ensure data exists and is not empty
    if (!data || Object.keys(data).length === 0) {
        container.innerHTML = '<div class="text-center p-3">No data available</div>';
        return;
    }

    const words = Object.entries(data).map(([text, size]) => ({
        text,
        size: Math.max(size * 15 + 10, 12)
    }));

    const colors = [
        '#696cff', '#ff4c4c', '#4CAF50',
        '#FFA500', '#9C27B0', '#00BCD4'
    ];

    // Clear container
    container.innerHTML = '';

    // Create canvas with willReadFrequently attribute
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d', { willReadFrequently: true });
    canvas.width = width;
    canvas.height = height;
    canvas.style.display = 'none';
    document.body.appendChild(canvas);

    const layout = d3.layout.cloud()
        .size([width, height])
        .canvas(() => {
            // Return a new canvas each time with willReadFrequently set
            const measureCanvas = document.createElement('canvas');
            measureCanvas.getContext('2d', { willReadFrequently: true });
            return measureCanvas;
        })
        .words(words)
        .padding(5)
        .rotate(() => ~~(Math.random() * 2) * 45)
        .fontSize(d => d.size)
        .on("end", draw);

    function draw(words) {
        // Clear previous SVG if exists
        const existingSvg = container.querySelector('svg');
        if (existingSvg) {
            existingSvg.remove();
        }

        d3.select(container)
            .append("svg")
            .attr("width", '100%')
            .attr("height", '100%')
            .attr("viewBox", `0 0 ${width} ${height}`)
            .append("g")
            .attr("transform", `translate(${width/2},${height/2})`)
            .selectAll("text")
            .data(words)
            .enter().append("text")
            .style("font-size", d => `${d.size}px`)
            .style("font-family", "Public Sans")
            .style("fill", () => colors[Math.floor(Math.random() * colors.length)])
            .style("cursor", "pointer")
            .attr("text-anchor", "middle")
            .attr("transform", d => `translate(${d.x},${d.y})rotate(${d.rotate})`)
            .text(d => d.text)
            .on("mouseover", function() {
                d3.select(this)
                    .transition()
                    .duration(200)
                    .style("font-size", d => `${d.size * 1.2}px`);
            })
            .on("mouseout", function() {
                d3.select(this)
                    .transition()
                    .duration(200)
                    .style("font-size", d => `${d.size}px`);
            });
    }

    try {
        layout.start();

        // Add buttons after the word cloud is created
        const buttonContainer = document.createElement('div');
        buttonContainer.style.position = 'absolute';
        buttonContainer.style.top = '10px';
        buttonContainer.style.right = '10px';
        buttonContainer.style.zIndex = '1000';

        // Download button
        const downloadBtn = document.createElement('button');
        downloadBtn.innerHTML = '<i class="bx bx-download me-1"></i>Download';
        downloadBtn.className = 'btn btn-outline-primary btn-xs me-2';
        downloadBtn.onclick = function() {
            const svg = container.querySelector('svg');
            if (!svg) return;

            const svgData = new XMLSerializer().serializeToString(svg);
            const blob = new Blob([svgData], { type: 'image/svg+xml' });
            const url = URL.createObjectURL(blob);

            const image = new Image();
            image.onload = function() {
                const canvas = document.createElement('canvas');
                canvas.width = width;
                canvas.height = height;
                const context = canvas.getContext('2d', { willReadFrequently: true });

                // Make background transparent
                context.clearRect(0, 0, width, height);
                context.drawImage(image, 0, 0);

                const link = document.createElement('a');
                link.download = 'wordcloud.png';
                link.href = canvas.toDataURL('image/png');
                link.click();
                URL.revokeObjectURL(url);
            };
            image.src = url;
        };

        // Copy button
        const copyBtn = document.createElement('button');
        copyBtn.innerHTML = '<i class="bx bx-copy me-1"></i>Copy';
        copyBtn.className = 'btn btn-outline-primary btn-xs';
        copyBtn.onclick = function() {
            const svg = container.querySelector('svg');
            if (!svg) return;

            const svgData = new XMLSerializer().serializeToString(svg);
            const blob = new Blob([svgData], { type: 'image/svg+xml' });
            const url = URL.createObjectURL(blob);

            const image = new Image();
            image.onload = function() {
                const canvas = document.createElement('canvas');
                canvas.width = width;
                canvas.height = height;
                const context = canvas.getContext('2d', { willReadFrequently: true });

                // Make background transparent
                context.clearRect(0, 0, width, height);
                context.drawImage(image, 0, 0);

                canvas.toBlob(function(blob) {
                    navigator.clipboard.write([
                        new ClipboardItem({ 'image/png': blob })
                    ]).then(() => {
                        // Show toast notification
                        const toast = document.createElement('div');
                        toast.className = 'toast align-items-center text-white bg-success border-0 position-fixed top-0 end-0 m-3';
                        toast.style.zIndex = '9999';
                        toast.innerHTML = `
                            <div class="d-flex">
                                <div class="toast-body">
                                    Copied to clipboard!
                                </div>
                                <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
                            </div>
                        `;
                        document.body.appendChild(toast);
                        new bootstrap.Toast(toast).show();
                        setTimeout(() => toast.remove(), 3000);
                    });
                }, 'image/png');
                URL.revokeObjectURL(url);
            };
            image.src = url;
        };

        buttonContainer.appendChild(downloadBtn);
        buttonContainer.appendChild(copyBtn);
        container.appendChild(buttonContainer);

    } catch (error) {
        console.error('Error generating word cloud:', error);
        container.innerHTML = '<div class="text-center p-3">Error generating word cloud</div>';
    }

    // Add resize observer
    const resizeObserver = new ResizeObserver(entries => {
        for (let entry of entries) {
            if (entry.contentRect.width !== width) {
                createWordCloud(data, controlholder);
                break;
            }
        }
    });


    resizeObserver.observe(container);

    // Cleanup
    canvas.remove();
    return () => {
        resizeObserver.disconnect();
    };
}




function generateShades(baseColor, count) {
    const shades = [];
    const baseRGB = hexToRGB(baseColor);

    for (let i = 0; i < count; i++) {
        const factor = 1 - (i / (count - 1)) * 0.5;
        const shade = rgbToHex(
            Math.round(baseRGB.r * factor),
            Math.round(baseRGB.g * factor),
            Math.round(baseRGB.b * factor)
        );
        shades.push(shade);
    }

    return shades;
}
function hexToRGB(hex) {
    const r = parseInt(hex.substring(1, 3), 16);
    const g = parseInt(hex.substring(3, 5), 16);
    const b = parseInt(hex.substring(5, 7), 16);
    return { r, g, b };
}
function rgbToHex(r, g, b) {
    return "#" + componentToHex(r) + componentToHex(g) + componentToHex(b);
}
function componentToHex(c) {
    const hex = c.toString(16);
    return hex.length === 1 ? "0" + hex : hex;
}

function createResponsiveChart(chartInstance) {
    let resizeTimeout;

    window.addEventListener('resize', function() {
        clearTimeout(resizeTimeout);
        resizeTimeout = setTimeout(function() {
            chartInstance.updateOptions({
                chart: {
                    width: '100%',
                    redrawOnWindowResize: true,
                    redrawOnParentResize: true
                }
            });
        }, 250);
    });
}

function transformVisionSentimentData(sentimentCounts) {
    // Create the data structure required by the chart function
    const chartData = {
        title: 'Sentiment Analysis Results',
        columns: ['Sentiment', 'Count'],
        rows: Object.entries(sentimentCounts).map(([sentiment, count]) => [
            // Capitalize first letter of sentiment
            sentiment.charAt(0).toUpperCase() + sentiment.slice(1),
            count
        ])
    };

    return chartData;
}


function PopulateUserDocumnet(userfolders) {
    userdocuments = userfolders;
    $('#total-selected-doc-span').text('')
    if(userdocuments.length > 0) {
        var folders = groupDocumentsByFolder(userdocuments);
        var folderhtml = ``;

        $.each(folders, function (index, folder) {
            var chatbotTag = folder.documents[0].doctype;
            var chatStatus = chatbotTag === 'public';
            var chatUrl = buildChatUrl(folder.documents[0].publickey);
            var folderitems = ``;
            
            var docbadge = ``;
            if(folder.documents[0].ownership==='shared'){
                docbadge = `<span class="badge bg-linkedin mx-1 p-1">Shared</span>`
            }
            else if(folder.documents[0].ownership==='own' && folder.documents[0].sharedto.length>0){
                docbadge = `<span class="badge bg-label-warning mx-1 p-1">Sharing</span>`
            }
            
            // Build document items
            $.each(folder.documents, function (index, docs) {
                var icon = getIconForDocType(docs.docext);
                folderitems += buildDocumentItem(docs, icon, docs.folderid);
            });

            // Each accordion gets its own li wrapper for better filtering control
            folderhtml += `<li class="p-2 pb-0 pt-0" data-folder-id="${folder.folderId}">
                <div class="accordion mt-3" id="${folder.folderId}">
                    <div class="card accordion-item">
                        <h2 class="accordion-header d-flex align-items-center">
                            <button type="button" class="accordion-button border collapsed" data-bs-toggle="collapse" data-bs-target="#${folder.folderId}-1" aria-expanded="false">
                                <i class="bx bx-data me-2"></i>
                                <span class="folder-name text-truncate">${getFolderName(folder.folderId)}</span> ${docbadge} 
                            </button>
                        </h2>
                        <div id="${folder.folderId}-1" class="accordion-collapse collapse">
                            <div class="accordion-body p-0">
                                ${buildFolderControls(folder.folderId, chatStatus, chatUrl)}
                                <div class="list-group">${folderitems}</div> 
                            </div>
                        </div>
                    </div>
                </div>
            </li>`;
        });

        $('#contact-list').html(folderhtml);
        
    }
    else{
        
        $('#contact-list').html(``);
    }
}
function buildChatUrl(publickey) {
    return `<div class="card shadow-none bg-transparent border border-primary">
        <span class="m-2 p-1 rounded-2 text-bg-light text-center text-xs">Header URL</span>
        <small class="text-center text-muted text-xs">Paste into the head section of your web page</small>
        <div class="p-2">
            <span class="text-xs" style="font-size: 11px;">
                ${publickey}
            </span>
        </div>
        <a href="#" class="px-3 pb-2">
            <span class="badge bg-label-primary text-xs" onclick="navigator.clipboard.writeText('${publickey}')">Copy</span>
        </a>
    </div>`;
}

function buildFolderControls(folderId, chatStatus, chatUrl) {
    function handleCollapseClick(targetId, otherId) {
        const otherElement = document.getElementById(otherId);
        if (otherElement.classList.contains('show')) {
            bootstrap.Collapse.getInstance(otherElement).hide();
        }
    }

    var folderfiles = getFilesByFolderId(userdocuments,folderId);
    var htm = `<div class="m-2"></div>`;
    if(UserRoles.length===1 &&  UserRoles.includes('SUBUSER')){
        return htm;
    }
    else {
        if(folderfiles[0].ownership==='shared'){
            return `<div class="border card mb-2 mt-2">
                        <div class="card-body p-0 rounded-2">
                            <div class="d-grid p-2">
                                <div class="btn-group" role="group" aria-label="Basic example">
                                    <button onclick="UploadUserDocumentPrompt('${folderId}')" type="button" class="btn btn-outline-primary btn-xs">Add File</button>
                                     <div class="btn-group" role="group">
                                        <button id="folderctrlbtnGroupDrop1" type="button" class="btn btn-outline-primary btn-xs bx bx-dots-vertical-rounded" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                        </button>
                                        <div class="dropdown-menu" aria-labelledby="folderctrlbtnGroupDrop1" style="">
                                          <a class="dropdown-item text-xs" href="javascript:void(0);" onclick="selectAllProjectFiles('${folderId}')">Select all project files</a>
                                        </div>
                                    </div>
                                
                                
                                </div>
                            </div>
                        </div>
                    </div>`;
        }
        else {
            return `<div class="border card mb-2 mt-2">
                    <div class="card-body p-0 rounded-2">
                        <div class="d-grid p-2">
                            <div class="btn-group" role="group" aria-label="Basic example">
                                <button onclick="renameFolder('${folderId}')" type="button" class="btn btn-outline-primary btn-xs">Rename</button>
                                <button onclick="UploadUserDocumentPrompt('${folderId}')" type="button" class="btn btn-outline-primary btn-xs">Add File</button>
                                <button onclick="buildFolderControls.handleCollapseClick('collapse-${folderId}', 'filetype-${folderId}')" data-bs-toggle="collapse" 
                                        data-bs-target="#collapse-${folderId}" aria-expanded="false" 
                                        aria-controls="collapse-${folderId}" type="button" class="btn btn-outline-primary btn-xs">Chat Bot</button>
                                <button onclick="shareFolder('${folderId}')" type="button" class="btn btn-outline-primary btn-xs">Share</button>
                                <div class="btn-group" role="group">
                                    <button id="folderctrlbtnGroupDrop1" type="button" class="btn btn-outline-primary btn-xs bx bx-dots-vertical-rounded" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    </button>
                                    <div class="dropdown-menu" aria-labelledby="folderctrlbtnGroupDrop1" style="">
                                      <a class="dropdown-item text-xs" href="javascript:void(0);" onclick="selectAllProjectFiles('${folderId}')">Select all project files</a>
                                    </div>
                                </div>
                                
                            </div>
                        </div>
                    </div>
                    <div class="collapse" id="collapse-${folderId}">
                        <div class="mb-2 p-3 rounded-2">
                            <div class="mt-2">
                                <div class="mb-2 text-center">
                                    <label class="switch switch-square">
                                        <input id="${folderId}-cbstatus" type="checkbox" ${chatStatus ? 'checked' : ''} 
                                               class="switch-input" onchange="ChatBotStatusChange('${folderId}')">
                                        <span class="switch-toggle-slider">
                                            <span class="switch-on"><i class="bx bx-check"></i></span>
                                            <span class="switch-off"><i class="bx bx-x"></i></span>
                                        </span>
                                        <span class="switch-label">${chatStatus ? 'ChatBot is enabled' : 'ChatBot is disabled'} </span>
                                    </label>
                                </div>
                                ${chatStatus ? chatUrl : ''}
                            </div>
                        </div>
                    </div>
                </div>`;
        }
    }
}

// Expose handleCollapseClick as a static method
buildFolderControls.handleCollapseClick = function(targetId, otherId) {
    const otherElement = document.getElementById(otherId);
    if (otherElement.classList.contains('show')) {
        bootstrap.Collapse.getInstance(otherElement).hide();
    }
}
function getIconForDocType(docext) {
    const iconMap = {
        'pdf': 'theme2/assets/img/icons/misc/rg_pdf.png',
        'xlsx': 'theme2/assets/img/icons/misc/rg_excel.png',
        'docx': 'theme2/assets/img/icons/misc/rg_word.png',
        'pptx': 'theme2/assets/img/icons/misc/rg_powerpoint.png',
        'txt': 'theme2/assets/img/icons/misc/rg_text.png',
        'json': 'theme2/assets/img/icons/misc/js.png',
        'sav': 'theme2/assets/img/icons/misc/spss.png'
    };
    return iconMap[docext] || '';
}
function buildDocumentItem(docs, icon, folder) {
    return `<div class="list-group-item pb-0 pt-0">
        <div class="row pt-2">
            <div class="col-md-11" style="white-space: nowrap"> 
                <span class="text-truncate-35 text-xs" id="${docs.docid}-span">
                    <input id="${docs.docid}" class="form-check-input me-1 doc-embeds fol-${folder}-end" type="checkbox" value="" onchange="ChangeSelectedFileColor('${docs.docid}')">
                    ${docs.docname}
                </span>
            </div>
            <div class="col-md-1 d-grid justify-content-end">
                <div class="btn-group">
                    <button type="button" class="btn-xs btn btn-icon rounded-pill dropdown-toggle hide-arrow" 
                            data-bs-toggle="collapse" data-bs-target="#collapse-${docs.docid}" 
                            aria-expanded="false" aria-controls="collapse-${docs.docid}">
                        <i class="bx bx-dots-vertical-rounded"></i>
                    </button>
                </div>
            </div>
        </div>
        ${buildDocumentControls(docs, icon)}
    </div>`;
}
function buildDocumentControls(docs, icon) {
    
    var ThemeButton = ``;
    if(docs.docext ==='xlsx'){
        ThemeButton = `<div class="btn-group" role="group">
                                <button id="btnGroupDrop1" type="button" class="btn btn-xs btn-outline-secondary dropdown-toggle" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                  Analytic
                                </button>
                                <div class="dropdown-menu" aria-labelledby="btnGroupDrop1" style="">
                                  <a class="dropdown-item text-xs" href="#" onclick="GetSentiment('${docs.docid}')">Sentiment Analysis</a>
                                  <hr class="dropdown-divider">
                                  <a class="dropdown-item text-xs" href="#" onclick="GenerateThemes('${docs.docid}')">Themes</a>
                                  <a class="dropdown-item text-xs" href="#" onclick="GetThematicData('${docs.docid}')">Thematic Analysis</a>
                                </div>
                              </div>`
    }
    
    var htm =``
    if((UserRoles.length===1 &&  UserRoles.includes('SUBUSER')|| (docs.ownership==='shared')) ){
        htm = `<div class="collapse" id="collapse-${docs.docid}">
        <div class="border mt-1 rounded-2 mb-2">
            <div class="d-grid p-2">
                <div class="btn-group" role="group" aria-label="Basic example">
                    <button onclick="archiveDocument('${docs.docid}')" type="button" class="btn btn-outline-secondary btn-xs">
                        Archive
                    </button>
                </div>
            </div>
            <div class="p-1">
                <div class="row align-items-center">
                    <div class="col-md-2">
                        <div>
                            <div>
                                <div class="avatar avatar-xs"><img src="${icon}" style="width: 20px;height: 20px;" class="mx-1 rounded-circle"></div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-10 px-0">
                       
                         ${docs.doctypes >= 1 ?
                            `<a href="#" onclick="GetMetaData('${docs.docid}','${docs.doctypes}')">
                            <span class="text-xs doc-description">${docs.docdescription}</span>
                         </a>` :
                            `<span class="text-xs doc-description">${docs.docdescription}</span>`
                        }
                    </div>
                </div>
            </div>
        </div>
    </div>`;
    }
    else {
        htm = `<div class="collapse" id="collapse-${docs.docid}">
        <div class="border mt-1 rounded-2 mb-2">
            <div class="d-grid p-2">
                <div class="btn-group" role="group" aria-label="Basic example">
                    <button onclick="renameDocument('${docs.docid}')" type="button" class="btn btn-outline-secondary btn-xs">
                        Rename
                    </button>
                    <button onclick="archiveDocument('${docs.docid}')" type="button" class="btn btn-outline-secondary btn-xs">
                        Archive
                    </button>
                    <button onclick="removeDocumentContent('${docs.docid}')" type="button" class="btn btn-outline-secondary btn-xs">
                        Delete
                    </button>
                     ${ThemeButton}
                </div>
            </div>
            <div class="p-1">
                <div class="row align-items-center">
                    <div class="col-md-2">
                        <div>
                            <div>
                                 <div class="avatar avatar-xs"><a href="#" onclick="EditDocumentContext('${docs.docid}')"><img src="${icon}" style="width: 20px;height: 20px;" class="mx-1 rounded-circle"></a></div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-10 px-0">
                         ${docs.doctypes >= 1 ?
                            `<a href="#" onclick="GetMetaData('${docs.docid}','${docs.doctypes}')">
                                            <span class="text-xs doc-description">${docs.docdescription}</span>
                                         </a>` :
                            `<span class="text-xs doc-description">${docs.docdescription}</span>`
                        }
                    </div>
                </div>
            </div>
        </div>
    </div>`
    }
    
    
    return htm;
}
function ChangeSelectedFileColor(fileid){
    var current = $('#' + fileid).prop('checked');
    if(current){
        $('#' + fileid + '-span').addClass('text-success');
    }
    else {
        $('#' + fileid + '-span').removeClass('text-success');
    }
    
    var selections = getSelectedCheckboxIds()
    if(selections.length == 0){
        $('#total-selected-doc-span').text('')
    }
    else {
        $('#total-selected-doc-span').text(`Deselect all ${selections.length} docs`)
    }
}

function selectAllProjectFiles(folderId){
    var csclass= `fol-${folderId}-end`

    // Select all checkboxes with the specified class and check them
    $(`.${csclass}`).prop('checked', true).each(function() {
        // Get the checkbox id and add green color to corresponding span
        var checkboxId = $(this).attr('id');
        $(`#${checkboxId}-span`).addClass('text-success');
    });

    // Update the total selected count (reusing existing functionality)
    var selections = getSelectedCheckboxIds();
    if(selections.length == 0) {
        $('#total-selected-doc-span').text('');
    } else {
        $('#total-selected-doc-span').text(`Deselect all ${selections.length} docs`);
    }
}

function EditDocumentContext(folderId){
    var data = getFileObject(folderId);
    updateDocDescription(data)
}

function updateDocDescription(docInfo) {
    // Remove existing modal if present
    let existingModal = document.getElementById('modalDocDescription');
    if (existingModal) {
        existingModal.remove();
    }

    // Create a new modal
    let modalDocDescription = document.createElement('div');
    modalDocDescription.id = 'modalDocDescription';
    modalDocDescription.innerHTML = `
        <div id="modalDocDescriptionBox" class="modal" tabindex="-1" aria-hidden="true" data-bs-backdrop="static">
            <div class="modal-dialog modal-lg modal-simple modal-dialog-centered">
                <div class="modal-content p-3 p-md-5">
                    <div class="modal-body">
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        <div class="text-center mb-4">
                            <h3>${docInfo.docname}</h3>
                            <p>Update document description</p>
                        </div>
                        <form id="descriptionForm" class="row g-3" onsubmit="return false">
                            <div class="col-12">
                                <label class="form-label w-100" for="descriptionValue">New description</label>
                                <div class="input-group input-group-merge">
                                    <textarea
                                        id="descriptionValue"
                                        name="descriptionValue"
                                        class="form-control"
                                        placeholder="Enter the description"
                                        aria-describedby="descriptionValue"
                                    >${docInfo.docdescription || ''}</textarea>
                                </div>
                            </div>
                            <div class="col-12 text-center">
                                <div class="d-flex justify-content-around">
                                    <button id="save-description-button" type="submit" class="btn btn-primary me-sm-3 me-1 mt-3">Submit</button>
                                    <button class="btn btn-primary me-sm-3 me-1 mt-3 hidesendbutton" type="button" disabled="" id="save-description-button-disabled">
                                        <span class="spinner-border me-1" role="status" aria-hidden="true"></span>
                                        Please wait...
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    `;

    document.body.appendChild(modalDocDescription);
    ShowPopupModal('modalDocDescriptionBox');

    function SaveDescription() {
        var description = $('#descriptionValue').val().trim();

        if(description) {
            $('#save-description-button').addClass('hidesendbutton');
            $('#save-description-button-disabled').removeClass('hidesendbutton');
            $('#save-description-button-disabled').addClass('showsendbutton');

            var form = new FormData();
            form.append('docid', docInfo.docid);
            form.append('description', description);

            var ep = `${applicationdomain}api/privaterag/updatedocdescription`;
            var jwt = GetStoredJwt();

            $.ajax({
                url: ep,
                type: 'POST',
                dataType: 'json',
                data: form,
                processData: false,
                contentType: false,
                headers: {
                    "Authorization": "Bearer " + jwt
                },
                success: function (Response) {
                    HideFooterStatus();
                    HidePopupModal('modalDocDescriptionBox');
                    if (Response) {
                        UserUsage(Response.usages);
                        PopulateUserDocumnet(Response.documents);
                        showNotificationToast('Document Context!', 'Document context updated successfully', 'success');
                    }
                },
                error: function (XMLHttpRequest, textStatus, errorThrown) {
                    HideFooterStatus();
                    HidePopupModal('modalDocDescriptionBox');
                    if (XMLHttpRequest.status === 401) {
                        LogoutUser();
                    }
                    else if (XMLHttpRequest.status === 400) {
                        var errorResponse = XMLHttpRequest.responseJSON;
                        ErrorMessage();
                    } else {
                        console.log("An error occurred:", errorThrown);
                    }
                }
            });
        }
    }

    $('#save-description-button').on('click', SaveDescription);
}
function filterDocs() {
    const searchInput = document.querySelector(".chat-search-input");
    const filterText = searchInput.value.toLowerCase().trim();

    // Get all folder list items
    const folderItems = document.querySelectorAll("#contact-list > li");

    folderItems.forEach(folderItem => {
        const accordion = folderItem.querySelector('.accordion');
        const folderName = folderItem.querySelector('.folder-name')?.textContent.toLowerCase() || '';
        const documents = folderItem.querySelectorAll('.list-group-item');
        let shouldShowFolder = false;

        // Check folder name match
        if (folderName.includes(filterText)) {
            shouldShowFolder = true;
            // Show all documents if folder name matches
            documents.forEach(doc => doc.style.removeProperty('display'));
        } else {
            // Check documents for matches
            documents.forEach(doc => {
                const docName = doc.querySelector('.text-truncate-35')?.textContent.toLowerCase().trim() || '';
                const docDesc = doc.querySelector('.doc-description')?.textContent.toLowerCase().trim() || '';

                if (docName.includes(filterText) || docDesc.includes(filterText)) {
                    shouldShowFolder = true;
                    doc.style.removeProperty('display');
                } else {
                    doc.style.setProperty('display', 'none', 'important');
                }
            });
        }

        // Show/hide the entire folder item
        if (shouldShowFolder) {
            folderItem.style.removeProperty('display');
            // Expand the accordion
            const collapse = accordion.querySelector('.accordion-collapse');
            if (collapse) collapse.classList.add('show');
            const button = accordion.querySelector('.accordion-button');
            if (button) {
                button.classList.remove('collapsed');
                button.setAttribute('aria-expanded', 'true');
            }
        } else {
            folderItem.style.setProperty('display', 'none', 'important');
        }
    });
}


function GetMetaData(docid,doctype){
    doctype = Number(doctype);
    if(doctype===1){
        GetSpssMetaData(docid)
    }
    else if(doctype===2){
        GetResumeData(docid)
    }
}

function GetResumeData(docid){

    ShowFooterStatus('Finding document')
    var form = new FormData();
    form.append('docid', docid);
    var ep = `${applicationdomain}api/privaterag/getresumedata`;
    var jwt = GetStoredJwt();
    $.ajax({
        url: ep,
        type: 'POST',
        dataType: 'json',
        data: form,
        processData: false,
        contentType: false,
        headers: {
            "Authorization": "Bearer " + jwt
        },
        success: function (Response) {
            HideFooterStatus();
            if (Response.success) {
                diplayResumePopup(Response.resumedata);
                
            }
            else {
                showNotificationToast('Resume!', 'Unable to find resume', 'danger');
            }
        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {
            HidePopupModal('modalDocDeletebox');
            if (XMLHttpRequest.status === 401) {
                LogoutUser()
            }
            else if (XMLHttpRequest.status === 400) {
                var errorResponse = XMLHttpRequest.responseJSON;
                ErrorMessage()
            } else {
                console.log("An error occurred:", errorThrown);
            }
        }
    });
}

function GetSpssMetaData(docid){
  
    ShowFooterStatus('Finding document')
    var form = new FormData();
    form.append('docid', docid);
    var ep = `${applicationdomain}api/privaterag/spssmetadata`;
    var jwt = GetStoredJwt();
    $.ajax({
        url: ep,
        type: 'POST',
        dataType: 'json',
        data: form,
        processData: false,
        contentType: false,
        headers: {
            "Authorization": "Bearer " + jwt
        },
        success: function (Response) {
            HideFooterStatus();
            if (Response) {
                ShowMetadataModal(Response)
            }
        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {
            HidePopupModal('modalDocDeletebox');
            if (XMLHttpRequest.status === 401) {
                LogoutUser()
            }
            else if (XMLHttpRequest.status === 400) {
                var errorResponse = XMLHttpRequest.responseJSON;
                ErrorMessage()
            } else {
                console.log("An error occurred:", errorThrown);
            }
        }
    });
}


function ShowMetadataModal(metadata) {
    // Check if modal exists
    var metadataModal = document.getElementById('metadataModal');
    if (!metadataModal) {
        metadataModal = document.createElement('div');
        metadataModal.id = 'metadataModal';
        document.body.appendChild(metadataModal);
    }

    // Add custom styles
    const styleElement = document.createElement('style');
    styleElement.textContent = `
        .metadata-modal .table {
            font-size: 0.85rem;
            margin-bottom: 0;
        }
        .metadata-modal .table th {
            font-size: 0.75rem;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            font-weight: 500;
            padding: 0.75rem 1rem;
            white-space: nowrap;
            background-color: #6b8aec;
            color: #ffffff;
        }
        .metadata-modal .table td {
            padding: 0.75rem 1rem;
            color: #697a8d;
            vertical-align: middle;
        }
        .metadata-modal .table-striped > tbody > tr:nth-of-type(odd) > * {
            background-color: rgba(67, 89, 113, 0.03);
        }
        .metadata-modal .precode-content {
            background: #f0f4ff;
            border-radius: 0.375rem;
            font-size: 0.85rem;
            border: 1px solid #dbe4ff;
        }
        .metadata-modal .precode-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
            gap: 0.75rem;
            padding: 0.75rem;
        }
        .metadata-modal .precode-item {
            background: rgba(255, 255, 255, 0.7);
            padding: 0.5rem 0.75rem;
            border-radius: 0.25rem;
            box-shadow: 0 2px 4px rgba(0,0,0,0.04);
            border: 1px solid #e5edff;
            transition: all 0.2s ease;
        }
        .metadata-modal .precode-item:hover {
            transform: translateY(-1px);
            box-shadow: 0 3px 6px rgba(0,0,0,0.08);
            background: rgba(255, 255, 255, 0.85);
        }
        .metadata-modal .btn-precode {
            padding: 0.25rem 0.75rem;
            font-size: 0.75rem;
            border-radius: 0.25rem;
            background-color: #6b8aec;
            color: white;
            border: 1px solid #5473e0;
            transition: all 0.2s;
        }
        .metadata-modal .btn-precode:hover {
            background-color: #5c7be5;
            border-color: #4864d6;
            box-shadow: 0 2px 4px rgba(92, 123, 229, 0.2);
        }
        .metadata-modal .search-box {
            border-radius: 0.375rem;
            box-shadow: 0 2px 4px rgba(0,0,0,0.05);
        }
        .metadata-modal .search-box .input-group-text {
            background-color: transparent;
            border-right: none;
        }
        .metadata-modal .search-box .form-control {
            border-left: none;
            padding-left: 0;
        }
        .metadata-modal .search-box .form-control:focus {
            box-shadow: none;
        }

        /* Custom scrollbar styles */
        .metadata-modal .table-container {
            scrollbar-width: thin;
            scrollbar-color: #6b8aec #f0f4ff;
        }
        .metadata-modal .table-container::-webkit-scrollbar {
            width: 8px;
            height: 8px;
        }
        .metadata-modal .table-container::-webkit-scrollbar-track {
            background: #f0f4ff;
            border-radius: 4px;
        }
        .metadata-modal .table-container::-webkit-scrollbar-thumb {
            background: #6b8aec;
            border-radius: 4px;
        }
        .metadata-modal .table-container::-webkit-scrollbar-thumb:hover {
            background: #5c7be5;
        }
    `;
    document.head.appendChild(styleElement);

    // Helper function to generate precode content
    const generatePrecodeContent = (precode) => {
        if (Object.keys(precode).length === 0) return '';

        const precodeEntries = Object.entries(precode)
            .map(([key, value]) => `
                <div class="precode-item">
                    <span class="fw-semibold" style="color: #566a7f">${key}:</span>
                    <span style="color: #697a8d">${value}</span>
                </div>
            `).join('');

        return precodeEntries;
    };

    // Generate metadata table rows
    const generateMetadataRows = (metadataList) =>
        metadataList.map(item => {
            const hasPrecode = Object.keys(item.precode).length > 0;
            const precodeButton = hasPrecode ?
                `<button class="btn-precode" onclick="togglePrecode('${item.name}')">
                    <i class="bx bx-chevron-down" id="icon-${item.name}"></i>
                    <span>Precodes</span>
                </button>` : '';

            return `
                <tr>
                    <td class="fw-semibold">${item.name}</td>
                    <td>${item.label}</td>
                    <td>${item.dateType}</td>
                    <td>${item.measurementType}</td>
                    <td>${precodeButton}</td>
                </tr>
                ${hasPrecode ? `
                <tr id="precode-${item.name}" style="display: none;">
                    <td colspan="5" class="p-0">
                        <div class="precode-content p-3 m-2">
                            <div class="d-flex justify-content-between align-items-center mb-2">
                                <span class="text-muted" style="font-size: 0.75rem;">Precodes for ${item.name}</span>
                            </div>
                            <div class="precode-grid">
                                ${generatePrecodeContent(item.precode)}
                            </div>
                        </div>
                    </td>
                </tr>` : ''}
            `;
        }).join('');

    // Search and toggle functions remain the same
    const filterMetadataTable = (searchValue) => {
        const table = document.getElementById('metadataTable');
        const rows = table.getElementsByTagName('tr');

        for (let i = 1; i < rows.length; i++) {
            const row = rows[i];
            if (row.id.startsWith('precode-')) continue;

            const text = row.textContent.toLowerCase();
            const precodeRow = document.getElementById('precode-' + row.cells[0].textContent);

            if (text.includes(searchValue.toLowerCase())) {
                row.style.display = '';
                if (precodeRow) {
                    precodeRow.style.display = precodeRow.dataset.expanded === 'true' ? '' : 'none';
                }
            } else {
                row.style.display = 'none';
                if (precodeRow) {
                    precodeRow.style.display = 'none';
                }
            }
        }
    };

    const togglePrecode = (name) => {
        const precodeRow = document.getElementById(`precode-${name}`);
        const icon = document.getElementById(`icon-${name}`);

        if (precodeRow.style.display === 'none') {
            precodeRow.style.display = '';
            precodeRow.dataset.expanded = 'true';
            icon.classList.remove('bx-chevron-down');
            icon.classList.add('bx-chevron-up');
        } else {
            precodeRow.style.display = 'none';
            precodeRow.dataset.expanded = 'false';
            icon.classList.remove('bx-chevron-up');
            icon.classList.add('bx-chevron-down');
        }
    };

    const copyMetaTableToClipboard = () => {
        const table = document.getElementById('metadataTable');
        const rows = Array.from(table.rows);

        const headers = Array.from(rows[0].cells).map(cell => cell.textContent.trim());
        const data = rows
            .slice(1)
            .filter(row => !row.id.startsWith('precode-'))
            .map(row => Array.from(row.cells).map(cell => {
                // For cells with a button, only get the text content before the button
                const buttonIndex = cell.innerHTML.indexOf('<button');
                if (buttonIndex !== -1) {
                    return cell.innerHTML.substring(0, buttonIndex).trim();
                }
                return cell.textContent.trim();
            }));

        const tsv = [headers, ...data].map(row => row.join('\t')).join('\n');

        navigator.clipboard.writeText(tsv).then(() => {
            const copyBtn = document.getElementById('copyButton');
            const originalText = copyBtn.innerHTML;
            copyBtn.innerHTML = '<i class="bx bx-check me-1"></i> Copied';
            setTimeout(() => {
                copyBtn.innerHTML = originalText;
            }, 2000);
        }).catch(err => {
            console.error('Failed to copy text: ', err);
            const copyBtn = document.getElementById('copyButton');
            copyBtn.innerHTML = '<i class="bx bx-x me-1"></i> Failed';
            setTimeout(() => {
                copyBtn.innerHTML = '<i class="bx bx-copy me-1"></i> Copy Table';
            }, 2000);
        });
    };

    // Populate the modal content
    metadataModal.innerHTML = `
    <div id="metadataModalBox" class="modal metadata-modal" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered modal-xxl">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Metadata Information</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body p-4">
                    <div class="d-flex justify-content-between align-items-center mb-4 gap-3">
                        <div class="input-group input-group-merge search-box flex-grow-1">
                            <span class="input-group-text border-end-0">
                                <i class="bx bx-search text-muted" style="font-size: 1.15rem;"></i>
                            </span>
                            <input type="text" class="form-control border-start-0" 
                                placeholder="Search metadata..." 
                                onkeyup="filterMetadataTable(this.value)">
                        </div>
                        <button id="copyButton" class="btn btn-primary btn-sm" style="white-space: nowrap;" onclick="copyMetaTableToClipboard()">
                            <i class="bx bx-copy me-1"></i> Copy Table
                        </button>
                    </div>

                    <div class="table-container" style="max-height: 600px; overflow: auto;">
                        <table class="table table-striped" id="metadataTable">
                            <thead>
                                <tr>
                                    <th>Name</th>
                                    <th>Label</th>
                                    <th>Date Type</th>
                                    <th>Measurement Type</th>
                                    <th>Precode</th>
                                </tr>
                            </thead>
                            <tbody>
                                ${generateMetadataRows(metadata)}
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>`;

    // Show the modal
    const modal = new bootstrap.Modal(document.getElementById('metadataModalBox'));
    modal.show();

    // Add functions to window scope
    window.filterMetadataTable = filterMetadataTable;
    window.copyMetaTableToClipboard = copyMetaTableToClipboard;
    window.togglePrecode = togglePrecode;
}

function diplayResumePopup(resumeData) {
    // const data = typeof container === 'string' ? JSON.parse(container) : container;
    // const resumeData = typeof data.content === 'string' ? JSON.parse(data.content) : data.content;

    // Format functions
    const formatDate = (dateStr, isCurrent) => {
        if (isCurrent) return 'Present';
        if (!dateStr) return 'N/A';
        const date = new Date(dateStr);
        return date.toLocaleDateString('en-US', { month: 'short', year: 'numeric' });
    };

    const formatExperience = (years) => {
        if (!years) return '';
        const wholeYears = Math.floor(years);
        const months = Math.round((years - wholeYears) * 12);
        return `${wholeYears} years${months ? ` ${months} months` : ''}`;
    };

    // Create or get the modal container
    let resumeModal = document.getElementById('resumeModal');
    if (!resumeModal) {
        resumeModal = document.createElement('div');
        resumeModal.id = 'resumeModal';
    }

    // Style initialization
    const styleId = 'resumeModalStyles';
    let styleElement = document.getElementById(styleId);
    if (!styleElement) {
        styleElement = document.createElement('style');
        styleElement.id = styleId;
        styleElement.textContent = `
            .resume-content {
                color: #cbcbe2;
            }
            
            .resume-header-title {
                color: #fff;
                font-size: 1.5rem;
                font-weight: 600;
                display: flex;
                align-items: center;
                gap: 10px;
            }
            
            .resume-container {
                max-height: 80vh;
                overflow-y: auto;
                padding-right: 15px;
            }
            
            .resume-container::-webkit-scrollbar {
                width: 6px;
            }
            
            .resume-container::-webkit-scrollbar-track {
                background: #383851;
                border-radius: 3px;
            }
            
            .resume-container::-webkit-scrollbar-thumb {
                background: #696cff;
                border-radius: 3px;
            }

            .resume-contact-info {
                display: flex;
                gap: 24px;
                flex-wrap: wrap;
                margin-bottom: 30px;
                background: rgba(105, 108, 255, 0.08);
                padding: 20px;
                border-radius: 10px;
            }

            .resume-contact-item {
                display: flex;
                align-items: center;
                gap: 10px;
                color: #cbcbe2;
                font-size: 0.95rem;
            }

            .resume-contact-item i {
                color: #696cff;
                font-size: 1.1rem;
            }

            .resume-total-experience {
                background: rgb(14 173 31 / 78%);
                padding: 10px 20px;
                border-radius: 6px;
                color: #fff;
                font-size: 0.9rem;
                display: inline-flex;
                align-items: center;
                gap: 8px;
            }

            .resume-summary {
                background: rgba(105, 108, 255, 0.05);
                padding: 20px;
                border-radius: 10px;
                margin: 20px 0;
                line-height: 1.6;
            }

            .resume-section-title {
                font-size: 1.25rem;
                font-weight: 600;
                color: #fff;
                margin: 35px 0 20px;
                display: flex;
                align-items: center;
                gap: 12px;
                border-bottom: 2px solid #444564;
                padding-bottom: 10px;
            }

            .resume-section-title i {
                color: #696cff;
            }

            .resume-exp-item {
                border-left: 2px solid #444564;
                padding-left: 25px;
                margin-bottom: 25px;
                position: relative;
                padding-bottom: 15px;
            }

            .resume-exp-item::before {
                content: '';
                position: absolute;
                left: -7px;
                top: 0;
                width: 12px;
                height: 12px;
                border-radius: 50%;
                background: #696cff;
                box-shadow: 0 0 0 3px rgba(105, 108, 255, 0.2);
            }

            .resume-job-title {
                font-weight: 600;
                color: #fff;
                margin-bottom: 8px;
                font-size: 1.1rem;
                display: flex;
                align-items: center;
                flex-wrap: wrap;
                gap: 10px;
            }

            .resume-current-badge {
                background: #28c76f1f;
                color: #28c76f;
                padding: 4px 12px;
                border-radius: 15px;
                font-size: 0.75rem;
                font-weight: 500;
                display: inline-flex;
                align-items: center;
                gap: 4px;
            }

            .resume-company-name {
                color: #cbcbe2;
                font-size: 1rem;
                display: flex;
                align-items: center;
                gap: 8px;
            }

            .resume-date-range {
                color: #7c7ca8;
                font-size: 0.9rem;
                margin: 8px 0 12px;
                display: flex;
                align-items: center;
                gap: 6px;
            }

            .resume-responsibilities {
                list-style-type: none;
                padding-left: 5px;
                color: #cbcbe2;
                font-size: 0.95rem;
                margin-top: 12px;
            }

            .resume-responsibilities li {
                margin-bottom: 8px;
                position: relative;
                padding-left: 20px;
                line-height: 1.5;
            }

            .resume-responsibilities li::before {
                content: '•';
                color: #696cff;
                position: absolute;
                left: 0;
                font-size: 1.2rem;
            }

            .resume-skills-section {
                background: rgba(105, 108, 255, 0.05);
                padding: 20px;
                border-radius: 10px;
                margin-top: 20px;
            }

            .resume-skills-container {
                display: flex;
                flex-wrap: wrap;
                gap: 12px;
                margin-top: 12px;
            }

            .resume-skill-category {
                margin-bottom: 25px;
                width: 100%;
            }

            .resume-skill-category h6 {
                color: #fff;
                font-size: 1.05rem;
                margin-bottom: 15px;
                display: flex;
                align-items: center;
                gap: 8px;
            }

            .resume-skill-tag {
                background: rgba(105, 108, 255, 0.15);
                color: #fff;
                padding: 12px 16px;
                border-radius: 10px;
                font-size: 0.9rem;
                transition: all 0.3s ease;
                border: 1px solid rgba(105, 108, 255, 0.2);
            }

            .resume-skill-description {
                color: #a5a5c5;
                font-size: 0.85rem;
                margin-top: 4px;
            }

            .resume-other-details {
                background: rgba(105, 108, 255, 0.05);
                padding: 20px;
                border-radius: 10px;
                margin-top: 20px;
                white-space: pre-line;
                line-height: 1.6;
            }

            .resume-languages-grid {
                display: grid;
                grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
                gap: 15px;
                margin-top: 20px;
            }

            .resume-language-item {
                background: rgba(105, 108, 255, 0.15);
                padding: 15px;
                border-radius: 10px;
                display: flex;
                align-items: center;
                justify-content: space-between;
                border: 1px solid rgba(105, 108, 255, 0.2);
            }

            .resume-keywords {
                display: flex;
                flex-wrap: wrap;
                gap: 8px;
                margin-top: 10px;
            }

            .resume-keyword-tag {
                background: rgba(105, 108, 255, 0.1);
                color: #fff;
                padding: 4px 12px;
                border-radius: 15px;
                font-size: 0.85rem;
            }

            .resume-personal-profiles {
                display: flex;
                flex-wrap: wrap;
                gap: 15px;
                margin-top: 15px;
            }

            .resume-profile-link {
                color: #696cff;
                text-decoration: none;
                display: flex;
                align-items: center;
                gap: 8px;
                font-size: 0.9rem;
            }

            .resume-profile-link:hover {
                text-decoration: underline;
            }
            
            .resume-other-details-list {
                display: flex;
                flex-direction: column;
                gap: 10px;
                margin-top: 15px;
            }

            .resume-other-detail-item {
                display: flex;
                align-items: center;
                padding: 8px 12px;
                background: rgba(105, 108, 255, 0.05);
                border-radius: 6px;
                font-size: 0.95rem;
                line-height: 1.5;
            }
        `;
        document.head.appendChild(styleElement);
    }

    const safeArray = (arr) => Array.isArray(arr) ? arr : [];

    resumeModal.innerHTML = `
    <div id="resumeModalBox" class="modal" tabindex="-1" aria-hidden="true" data-bs-backdrop="static">
        <div class="modal-dialog modal-dialog-centered modal-xxl">
            <div class="modal-content">
                <div class="modal-header">
                    <div>
                        <h5 class="modal-title resume-header-title">
                            <i class="fas fa-user-circle"></i>
                            ${resumeData?.personal_info?.full_name || 'N/A'}
                        </h5>
                    </div>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body resume-content">
                    <div class="resume-container">
                        <!-- Personal Information Section -->
                        <div class="resume-contact-info">
                            ${resumeData?.total_experience_years ? `
                                <div class="resume-total-experience">
                                    <i class="fas fa-business-time"></i>
                                    Total Experience: ${formatExperience(resumeData.total_experience_years)}
                                </div>
                            ` : ''}
                            ${resumeData?.personal_info?.email ? `
                                <div class="resume-contact-item">
                                    <i class="fas fa-envelope"></i>
                                    ${resumeData.personal_info.email}
                                </div>
                            ` : ''}
                            ${resumeData?.personal_info?.phone ? `
                                <div class="resume-contact-item">
                                    <i class="fas fa-phone"></i>
                                    ${resumeData.personal_info.phone}
                                </div>
                            ` : ''}
                            ${resumeData?.personal_info?.date_of_birth ? `
                                <div class="resume-contact-item">
                                    <i class="fas fa-birthday-cake"></i>
                                    ${new Date(resumeData.personal_info.date_of_birth).toLocaleDateString()}
                                </div>
                            ` : ''}
                            ${resumeData?.personal_info?.gender ? `
                                <div class="resume-contact-item">
                                    <i class="fas fa-user"></i>
                                    ${resumeData.personal_info.gender}
                                </div>
                            ` : ''}
                            ${resumeData?.personal_info?.marital_status ? `
                                <div class="resume-contact-item">
                                    <i class="fas fa-ring"></i>
                                    ${resumeData.personal_info.marital_status}
                                </div>
                            ` : ''}
                            ${resumeData?.personal_info?.current_location ? `
                                <div class="resume-contact-item">
                                    <i class="fas fa-map-marker-alt"></i>
                                    ${resumeData.personal_info.current_location?.city || ''}, 
                                    ${resumeData.personal_info.current_location?.state || ''}, 
                                    ${resumeData.personal_info.current_location?.country || ''}
                                </div>
                            ` : ''}
                            ${resumeData?.personal_info?.address ? `
                                <div class="resume-contact-item">
                                    <i class="fas fa-home"></i>
                                    ${resumeData.personal_info.address.street || ''}, 
                                    ${resumeData.personal_info.address.city || ''}, 
                                    ${resumeData.personal_info.address.state || ''} 
                                    ${resumeData.personal_info.address.zip_code || ''}
                                </div>
                            ` : ''}
                            ${resumeData?.personal_info?.website ? `
                                <div class="resume-contact-item">
                                    <i class="fas fa-globe"></i>
                                    <a href="${resumeData.personal_info.website}" target="_blank">${resumeData.personal_info.website}</a>
                                </div>
                            ` : ''}
                            ${resumeData?.personal_info?.linkedin ? `
                                <div class="resume-contact-item">
                                    <i class="fab fa-linkedin"></i>
                                    <a href="${resumeData.personal_info.linkedin}" target="_blank">LinkedIn Profile</a>
                                </div>
                            ` : ''}
                            ${resumeData?.personal_info?.other_profiles ? `
                                <div class="resume-contact-item">
                                    <i class="fas fa-link"></i>
                                    ${safeArray(resumeData.personal_info.other_profiles).join(', ')}
                                </div>
                            ` : ''}
                        </div>

                        <!-- Keywords Section -->
                        ${resumeData?.keywords ? `
                            <div class="resume-skills-section mt-3">
                                <div class="resume-skills-container">
                                    ${safeArray(resumeData.keywords).map(keyword => `
                                        <span class="resume-skill-tag">
                                            <i class="fas fa-tag"></i>
                                            ${keyword || ''}
                                        </span>
                                    `).join('')}
                                </div>
                            </div>
                        ` : ''}

                        <!-- Summary Section -->
                        ${resumeData?.summary ? `
                            <div class="resume-section-title">
                                <i class="fas fa-file-alt"></i>
                                Summary
                            </div>
                            <p>${resumeData.summary}</p>
                        ` : ''}

                        <!-- Experience Section -->
                        ${resumeData?.experience ? `
                            <div class="resume-section-title">
                                <i class="fas fa-briefcase"></i>
                                Professional Experience
                            </div>
                            ${safeArray(resumeData.experience).map(exp => `
                                <div class="resume-exp-item">
                                    <div class="resume-job-title">
                                        ${exp?.job_title || ''}
                                        ${exp?.is_current ? `
                                            <span class="resume-current-badge">
                                                <i class="fas fa-check-circle"></i>
                                                Current
                                            </span>
                                        ` : ''}
                                    </div>
                                    <div class="resume-company-name">
                                        <i class="fas fa-building" style="color: #696cff;"></i>
                                        ${exp?.company?.name || ''}
                                        ${exp?.company?.location ? ` • ${exp.company.location}` : ''}
                                    </div>
                                    <div class="resume-date-range">
                                        <i class="fas fa-calendar-alt"></i>
                                        ${formatDate(exp?.start_date)} - ${formatDate(exp?.end_date, exp?.is_current)}
                                    </div>
                                    <ul class="resume-responsibilities">
                                        ${safeArray(exp?.responsibilities).map(resp => `
                                            <li>${resp || ''}</li>
                                        `).join('')}
                                        ${exp?.achievements ? safeArray(exp.achievements).map(achievement => `
                                            <li class="achievement">
                                                <i class="fas fa-trophy" style="color: #ffd700;"></i> ${achievement || ''}
                                            </li>
                                        `).join('') : ''}
                                    </ul>
                                </div>
                            `).join('')}
                        ` : ''}

                        <!-- Education Section -->
                        ${resumeData?.education ? `
                            <div class="resume-section-title">
                                <i class="fas fa-graduation-cap"></i>
                                Education
                            </div>
                            ${safeArray(resumeData.education).map(edu => `
                                <div class="resume-exp-item">
                                    <div class="resume-job-title">
                                        ${edu?.degree || ''}${edu?.field_of_study ? ` in ${edu.field_of_study}` : ''}
                                        ${edu?.is_current ? `
                                            <span class="resume-current-badge">
                                                <i class="fas fa-check-circle"></i>
                                                Current
                                            </span>
                                        ` : ''}
                                    </div>
                                    <div class="resume-company-name">
                                        <i class="fas fa-university" style="color: #696cff;"></i>
                                        ${edu?.school?.name || ''}
                                        ${edu?.school?.location ? ` • ${edu.school.location}` : ''}
                                    </div>
                                    ${edu?.start_date ? `
                                        <div class="resume-date-range">
                                            <i class="fas fa-calendar-alt"></i>
                                            ${formatDate(edu.start_date)} - ${formatDate(edu.end_date, edu.is_current)}
                                        </div>
                                    ` : ''}
                                    ${edu?.achievements ? `
                                        <ul class="resume-responsibilities">
                                            ${safeArray(edu.achievements).map(achievement => `
                                                <li class="achievement">
                                                    <i class="fas fa-award" style="color: #ffd700;"></i> ${achievement || ''}
                                                </li>
                                            `).join('')}
                                        </ul>
                                    ` : ''}
                                </div>
                            `).join('')}
                        ` : ''}

                        <!-- Skills Section -->
                        ${resumeData?.skills ? `
                            <div class="resume-section-title">
                                <i class="fas fa-star"></i>
                                Skills
                            </div>
                            <div class="resume-skills-section">
                                ${safeArray(resumeData.skills).map(skillCategory => `
                                    <div class="resume-skill-category">
                                        <h6>
                                            <i class="fas fa-check-circle" style="color: #696cff;"></i>
                                            ${skillCategory?.category || ''}
                                        </h6>
                                        <div class="resume-skills-container">
                                            ${safeArray(skillCategory?.skills_list).map(skill => `
                                                <div class="resume-skill-tag" title="${skill?.description || ''}">
                                                    <span>${skill?.skill_name || ''}</span>
                                                    ${skill?.description ? `
                                                        <span class="resume-skill-description">- ${skill.description}</span>
                                                    ` : ''}
                                                </div>
                                            `).join('')}
                                        </div>
                                    </div>
                                `).join('')}
                            </div>
                        ` : ''}

                        <!-- Certifications Section -->
                        ${resumeData?.certifications ? `
                            <div class="resume-section-title">
                                <i class="fas fa-certificate"></i>
                                Certifications
                            </div>
                            ${safeArray(resumeData.certifications).map(cert => `
                                <div class="resume-exp-item">
                                    <div class="resume-job-title">
                                        ${cert?.name || ''}
                                    </div>
                                    <div class="resume-company-name">
                                        <i class="fas fa-award" style="color: #696cff;"></i>
                                        ${cert?.issuing_organization || ''}
                                    </div>
                                    <div class="resume-date-range">
                                        <i class="fas fa-calendar-alt"></i>
                                        Issued: ${formatDate(cert?.issue_date)}
                                        ${cert?.expiration_date ? ` - Expires: ${formatDate(cert.expiration_date)}` : ''}
                                    </div>
                                </div>
                            `).join('')}
                        ` : ''}

                        <!-- Projects Section -->
                        ${resumeData?.projects ? `
                            <div class="resume-section-title">
                                <i class="fas fa-project-diagram"></i>
                                Projects
                            </div>
                            ${safeArray(resumeData.projects).map(project => `
                                <div class="resume-exp-item">
                                    <div class="resume-job-title">
                                        ${project?.name || ''}
                                        ${project?.is_current ? `
                                            <span class="resume-current-badge">
                                                <i class="fas fa-check-circle"></i>
                                                Current
                                            </span>
                                        ` : ''}
                                    </div>
                                    ${project?.role ? `
                                        <div class="resume-company-name">
                                            <i class="fas fa-user-tag" style="color: #696cff;"></i>
                                            Role: ${project.role}
                                        </div>
                                    ` : ''}
                                    <div class="resume-date-range">
                                        <i class="fas fa-calendar-alt"></i>
                                        ${formatDate(project?.start_date)} - ${formatDate(project?.end_date, project?.is_current)}
                                    </div>
                                    ${project?.description ? `<p>${project.description}</p>` : ''}
                                    ${project?.technologies_used ? `
                                        <div class="resume-skills-container">
                                            ${safeArray(project.technologies_used).map(tech => `
                                                <span class="resume-skill-tag">
                                                    <i class="fas fa-code"></i>
                                                    ${tech || ''}
                                                </span>
                                            `).join('')}
                                        </div>
                                    ` : ''}
                                </div>
                            `).join('')}
                        ` : ''}

                        <!-- Languages Section -->
                        ${resumeData?.languages ? `
                            <div class="resume-section-title">
                                <i class="fas fa-language"></i>
                                Languages
                            </div>
                            <div class="resume-skills-section">
                                <div class="resume-skills-container">
                                    ${safeArray(resumeData.languages).map(lang => `
                                        <span class="resume-skill-tag">
                                            <i class="fas fa-comment"></i>
                                            ${lang?.language || ''} - ${lang?.proficiency || ''}
                                        </span>
                                    `).join('')}
                                </div>
                            </div>
                        ` : ''}

                        <!-- Publications Section -->
                        ${resumeData?.publications ? `
                            <div class="resume-section-title">
                                <i class="fas fa-book"></i>
                                Publications
                            </div>
                            ${safeArray(resumeData.publications).map(pub => `
                                <div class="resume-exp-item">
                                    <div class="resume-job-title">${pub?.title || ''}</div>
                                    <div class="resume-company-name">
                                        <i class="fas fa-newspaper" style="color: #696cff;"></i>
                                        ${pub?.publication_name || ''}
                                    </div>
                                    <div class="resume-date-range">
                                        <i class="fas fa-calendar-alt"></i>
                                        ${formatDate(pub?.date)}
                                    </div>
                                    ${pub?.url ? `
                                        <a href="${pub.url}" target="_blank" class="resume-skill-tag">
                                            <i class="fas fa-external-link-alt"></i>
                                            View Publication
                                        </a>
                                    ` : ''}
                                </div>
                            `).join('')}
                        ` : ''}

                        <!-- Volunteer Experience Section -->
                        ${resumeData?.volunteer_experience ? `
                            <div class="resume-section-title">
                                <i class="fas fa-hands-helping"></i>
                                Volunteer Experience
                            </div>
                            ${safeArray(resumeData.volunteer_experience).map(vol => `
                                <div class="resume-exp-item">
                                    <div class="resume-job-title">
                                        ${vol?.role || ''}
                                        ${vol?.is_current ? `
                                            <span class="resume-current-badge">
                                                <i class="fas fa-check-circle"></i>
                                                Current
                                            </span>
                                        ` : ''}
                                    </div>
                                    <div class="resume-company-name">
                                        <i class="fas fa-building" style="color: #696cff;"></i>
                                        ${vol?.organization?.name || ''}
                                        ${vol?.organization?.location ? ` • ${vol.organization.location}` : ''}
                                    </div>
                                    <div class="resume-date-range">
                                        <i class="fas fa-calendar-alt"></i>
                                        ${formatDate(vol?.start_date)} - ${formatDate(vol?.end_date, vol?.is_current)}
                                    </div>
                                    ${vol?.description ? `<p>${vol.description}</p>` : ''}
                                </div>
                            `).join('')}
                        ` : ''}

                        <!-- References Section -->
                        ${resumeData?.references ? `
                            <div class="resume-section-title">
                                <i class="fas fa-user-friends"></i>
                                References
                            </div>
                            <div class="resume-skills-section">
                                ${safeArray(resumeData.references).map(ref => `
                                    <div class="resume-exp-item">
                                        <div class="resume-job-title">${ref?.name || ''}</div>
                                        <div class="resume-company-name">
                                            <i class="fas fa-user-tie" style="color: #696cff;"></i>
                                            ${ref?.relationship || ''}
                                        </div>
                                        ${ref?.contact_info ? `
                                            <div class="resume-contact-item mt-2">
                                                ${ref.contact_info.email ? `
                                                    <div class="mb-1">
                                                        <i class="fas fa-envelope"></i> ${ref.contact_info.email}
                                                    </div>
                                                ` : ''}
                                                ${ref.contact_info.phone ? `
                                                    <div>
                                                        <i class="fas fa-phone"></i> ${ref.contact_info.phone}
                                                    </div>
                                                ` : ''}
                                            </div>
                                        ` : ''}
                                    </div>
                                `).join('')}
                            </div>
                        ` : ''}

                        <!-- Interests Section -->
                        ${resumeData?.interests ? `
                            <div class="resume-section-title">
                                <i class="fas fa-heart"></i>
                                Interests
                            </div>
                            <div class="resume-skills-section">
                                <div class="resume-skills-container">
                                    ${safeArray(resumeData.interests).map(interest => `
                                        <span class="resume-skill-tag">
                                            <i class="fas fa-star"></i>
                                            ${interest || ''}
                                        </span>
                                    `).join('')}
                                </div>
                            </div>
                        ` : ''}

                        <!-- Additional Information Section -->
                        ${resumeData?.additional_info ? `
                            <div class="resume-section-title">
                                <i class="fas fa-info-circle"></i>
                                Additional Information
                            </div>
                            <div class="resume-skills-section">
                                ${resumeData.additional_info?.hobbies ? `
                                    <div class="resume-skill-category">
                                        <h6>
                                            <i class="fas fa-heart" style="color: #696cff;"></i>
                                            Hobbies
                                        </h6>
                                        <div class="resume-skills-container">
                                            ${safeArray(resumeData.additional_info.hobbies).map(hobby => `
                                                <span class="resume-skill-tag">
                                                    <i class="fas fa-star"></i>
                                                    ${hobby || ''}
                                                </span>
                                            `).join('')}
                                        </div>
                                    </div>
                                ` : ''}
                                
                                ${resumeData.additional_info?.extracurricular_activities ? `
                                    <div class="resume-skill-category">
                                        <h6>
                                            <i class="fas fa-running" style="color: #696cff;"></i>
                                            Extracurricular Activities
                                        </h6>
                                        <div class="resume-skills-container">
                                            ${safeArray(resumeData.additional_info.extracurricular_activities).map(activity => `
                                                <span class="resume-skill-tag">
                                                    <i class="fas fa-check"></i>
                                                    ${activity || ''}
                                                </span>
                                            `).join('')}
                                        </div>
                                    </div>
                                ` : ''}
                                
                                ${resumeData.additional_info?.awards ? `
                                    <div class="resume-skill-category">
                                        <h6>
                                            <i class="fas fa-trophy" style="color: #696cff;"></i>
                                            Awards
                                        </h6>
                                        ${safeArray(resumeData.additional_info.awards).map(award => `
                                            <div class="resume-exp-item">
                                                <div class="resume-job-title">${award?.title || ''}</div>
                                                <div class="resume-company-name">
                                                    <i class="fas fa-award" style="color: #696cff;"></i>
                                                    ${award?.issuer || ''}
                                                </div>
                                                <div class="resume-date-range">
                                                    <i class="fas fa-calendar-alt"></i>
                                                    ${formatDate(award?.date)}
                                                </div>
                                                ${award?.description ? `<p>${award.description}</p>` : ''}
                                            </div>
                                        `).join('')}
                                    </div>
                                ` : ''}

                                ${resumeData.additional_info?.other_details ? `
                                    <div class="resume-skill-category">
                                        <h6>
                                            <i class="fas fa-plus-circle" style="color: #696cff;"></i>
                                            Other Details
                                        </h6>
                                        <div class="resume-other-details-list">
                                            ${resumeData.additional_info.other_details.split('\n').map(detail => `
                                                <div class="resume-other-detail-item">
                                                    <i class="fas fa-circle" style="color: #696cff; font-size: 8px; margin-right: 10px;"></i>
                                                    ${detail.trim()}
                                                </div>
                                            `).join('')}
                                        </div>
                                    </div>
                                ` : ''}
                            </div>
                        ` : ''}
                    </div>
                </div>
            </div>
        </div>
    </div>
`;

    // Append modal to body if it doesn't exist
    if (!document.getElementById('resumeModal')) {
        document.body.appendChild(resumeModal);
    }

    // Initialize and show Bootstrap modal
    const modalElement = document.getElementById('resumeModalBox');
    const bsModal = new bootstrap.Modal(modalElement);
    bsModal.show();

    // Cleanup on close
    modalElement.addEventListener('hidden.bs.modal', function () {
        if (styleElement) {
            styleElement.remove();
        }
        resumeModal.remove();
    });
}
